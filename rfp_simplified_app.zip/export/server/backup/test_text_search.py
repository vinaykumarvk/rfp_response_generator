#!/usr/bin/env python3
"""
Test script for PostgreSQL text search only
"""
import json
from pg_vector_search import find_requirements_by_text

def test_text_search():
    """Test direct text search functionality"""
    sample_text = "security"
    
    print("=" * 50)
    print(f"Testing text search with term: '{sample_text}'")
    print("=" * 50)
    
    # Test text search
    results = find_requirements_by_text(sample_text, limit=3, use_fuzzy_match=True)
    
    # Log results
    print(f"Found {len(results)} text search results")
    
    # Print the results in formatted JSON
    print("Text search results:")
    print(json.dumps(results, indent=2))
    
    return len(results) > 0

if __name__ == "__main__":
    test_text_search()