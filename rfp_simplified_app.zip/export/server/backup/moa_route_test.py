#!/usr/bin/env python3
"""
MOA Route Handler Test
This script tests the MOA route handler with a simple requirement
"""

import sys
import json
from io import StringIO
from moa_route_handler import handle_moa_request

def test_moa_route_handler():
    """
    Test the MOA route handler with a simple requirement
    """
    # Sample request data
    request_data = {
        "requirement": "What features does your wealth management platform provide for document management?",
        "category": "Wealth Management Software"
    }
    
    # Save original stdin and stdout
    orig_stdin = sys.stdin
    orig_stdout = sys.stdout
    
    try:
        # Set up our test environment
        test_stdin = StringIO(json.dumps(request_data))
        test_stdout = StringIO()
        
        sys.stdin = test_stdin
        sys.stdout = test_stdout
        
        # Call the handler
        print("Running MOA route handler test...")
        handle_moa_request()
        
        # Get the result
        output = test_stdout.getvalue()
        print(f"Output: {output[:100]}...")
        
        # Try to parse the JSON
        result = json.loads(output)
        
        # Print key fields for verification
        print("\nMOA Route Handler Test Results:")
        print(f"Status: {result.get('status', 'unknown')}")
        print(f"Models succeeded: {result.get('metrics', {}).get('models_succeeded', 'unknown')}")
        print(f"Total time: {result.get('metrics', {}).get('total_time', 'unknown')}")
        
        # Verify crucial fields
        model_responses = result.get('model_responses', {})
        print("\nModel Response Sizes:")
        print(f"OpenAI: {len(model_responses.get('openai_response', '')) if model_responses.get('openai_response') else 'Not present'}")
        print(f"Anthropic: {len(model_responses.get('anthropic_response', '')) if model_responses.get('anthropic_response') else 'Not present'}")
        print(f"DeepSeek: {len(model_responses.get('deepseek_response', '')) if model_responses.get('deepseek_response') else 'Not present'}")
        print(f"MOA: {len(model_responses.get('moa_response', '')) if model_responses.get('moa_response') else 'Not present'}")
        
        print("\nVerification Complete!")
        
    finally:
        # Restore stdin and stdout
        sys.stdin = orig_stdin
        sys.stdout = orig_stdout

if __name__ == "__main__":
    test_moa_route_handler()