#!/usr/bin/env python3
"""
Direct test for generate_moa_response function from moa_final.py
This script directly tests the MOA functionality without any other dependencies
"""

import sys
import json
import time
import traceback

# Import the function directly
try:
    from moa_final import generate_moa_response
except ImportError as e:
    print(json.dumps({
        "status": "error",
        "message": f"Could not import generate_moa_response: {str(e)}"
    }))
    sys.exit(1)

def test_generate_moa_response(requirement_text):
    """
    Test the generate_moa_response function directly
    """
    start_time = time.time()
    
    try:
        # Set up sample previous responses
        previous_responses = """1. Our wealth management platform provides real-time dashboards for advisors to monitor client portfolios with interactive charts and performance metrics.
        
2. The system features a comprehensive dashboard that allows wealth managers to track all client portfolios in real time, with customizable views and automated alerts."""
        
        # Call the function directly
        print(f"Processing requirement with MOA...")
        response = generate_moa_response(
            requirement=requirement_text, 
            category="Wealth Management Software",
            previous_responses=previous_responses
        )
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # Add execution time info
        if isinstance(response, dict):
            response["execution_time"] = execution_time
        else:
            response = {
                "status": "success",
                "raw_response": response,
                "execution_time": execution_time
            }
        
        # Return the response
        print(json.dumps(response, indent=2))
        return response
        
    except Exception as e:
        print(f"Error: {str(e)}")
        print(traceback.format_exc())
        error_response = {
            "status": "error",
            "message": f"Error calling generate_moa_response: {str(e)}",
            "traceback": traceback.format_exc(),
            "execution_time": time.time() - start_time
        }
        print(json.dumps(error_response, indent=2))
        return error_response

if __name__ == "__main__":
    # Get command line arguments
    if len(sys.argv) < 2:
        print("Usage: python test_moa_direct.py <requirement_text>")
        sys.exit(1)
    
    requirement_text = sys.argv[1]
    
    # Test the MOA response generation
    test_generate_moa_response(requirement_text)