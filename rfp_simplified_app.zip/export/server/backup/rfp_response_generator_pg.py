import os
import sys
import json
import time
import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from psycopg2.extensions import register_adapter
import numpy as np

# Import our custom modules
try:
    from text_search import find_requirements_by_text, CustomJsonEncoder
    sys.stderr.write("Successfully imported text_search module\n")
except ImportError as e:
    sys.stderr.write(f"Failed to import text_search module: {str(e)}\n")
    # Define a fallback function if import fails
    def find_requirements_by_text(query_text, limit=5, use_fuzzy_match=True):
        """Fallback text search function"""
        sys.stderr.write("Using fallback text search function\n")
        return []
    
    # Define fallback JSON encoder
    class CustomJsonEncoder(json.JSONEncoder):
        def default(self, obj):
            if hasattr(obj, 'decimal') and isinstance(obj, obj.decimal):
                return float(obj)
            return super(CustomJsonEncoder, self).default(obj)

# Define hardcoded paths and database URL
EXCEL_PATH = "server/temp_files/rfp_responses.xlsx"
DATABASE_URL = os.environ.get("DATABASE_URL")

# We'll hardcode the API keys in the prompt_gpt function itself for reliable deployment
# Leaving these variables as None since we'll override them in the function
OPENAI_API_KEY = None
ANTHROPIC_API_KEY = None 
DEEPSEEK_API_KEY = None

# Set a sensible timeout for API responses
DEFAULT_TIMEOUT = 30  # 30 seconds

def create_rfp_prompt(new_question, category, previous_responses):
    """
    Create an optimized prompt for RFP response generation.

    Args:
        new_question: The current RFP requirement to address.
        category: Functional category of the requirement.
        previous_responses: List of previous responses with their similarity scores.
    """
    # Create a structured system message
    system_message = f"""You are an expert in wealth management and financial technology solutions, specializing in crafting precise, professional responses to RFP requirements. 
Your task is to generate a comprehensive, accurate response to the given requirement that demonstrates expertise in {category}.

Guidelines for response:
1. Be specific and detailed in your response, highlighting key capabilities
2. Include relevant technical details where appropriate
3. The tone should be professional, authoritative, and confident
4. Structure your response clearly with proper paragraphing
5. Keep your response focused on addressing the exact requirement
6. Avoid generic or vague statements
7. Incorporate relevant domain terminology that demonstrates expertise
8. Do not invent specific product names or company names
9. Aim for a response length of 100-250 words"""

    # Create a structured user message
    user_message = f"""Please generate a detailed, professional response to the following RFP requirement in the {category} domain:

REQUIREMENT: "{new_question}"

I'm providing previous similar responses for reference (sorted by relevance):

{previous_responses}

Based on these examples and your expertise, craft a comprehensive response that directly addresses this specific requirement. Ensure the response demonstrates deep understanding of {category} products and services."""

    # Return in the OpenAI message format
    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

def create_synthesized_response_prompt(requirement, responses):
    """
    Generate a prompt to synthesize multiple RFP responses into a cohesive, impactful response.

    Args:
        requirement: The specific RFP requirement to address.
        responses: List of individual responses to evaluate and synthesize.

    Returns:
        List of messages for the LLM.
    """
    system_message = """You are an expert AI Synthesizer specialized in creating optimal RFP (Request for Proposal) responses.
Your task is to analyze multiple AI-generated responses to the same RFP requirement, critically evaluate the strengths and weaknesses of each,
and then synthesize them into a single, cohesive, high-quality response.

Focus on:
1. Extracting the most accurate, relevant, and specific content from each response
2. Ensuring technical accuracy and domain-appropriate terminology
3. Maintaining a professional, confident tone
4. Creating a coherent flow with proper transitions
5. Providing specific details rather than generic statements
6. Addressing all aspects of the requirement comprehensively
7. Structuring the response in clear, readable paragraphs

The final response should demonstrate deep expertise in the relevant domain, directly address the requirement,
and be optimized for persuasiveness and clarity."""

    openai_response = responses.get("openai", "No response available from OpenAI model.")
    anthropic_response = responses.get("anthropic", "No response available from Anthropic model.")
    deepseek_response = responses.get("deepseek", "No response available from DeepSeek model.")

    user_message = f"""I need you to synthesize the best possible RFP response by analyzing and combining elements from these three AI-generated responses to the following requirement:

REQUIREMENT: {requirement}

RESPONSE FROM MODEL 1:
{openai_response}

RESPONSE FROM MODEL 2:
{anthropic_response}

RESPONSE FROM MODEL 3:
{deepseek_response}

First, briefly analyze the strengths and weaknesses of each response. Then, create a single synthesized response that incorporates the best elements from all three, addresses any gaps or inaccuracies, and forms a comprehensive answer to the requirement. The synthesized response should stand alone as a complete, professional RFP response."""

    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

def convert_promt_to_claude(prompt):
    """
    Convert a prompt formatted for OpenAI to one compatible with Claude.
    
    Args:
        prompt: List of message dictionaries formatted for OpenAI
        
    Returns:
        Dict with 'messages' (list of message dictionaries) and 'system' (system message)
    """
    claude_messages = []
    system_message = ""

    # Extract system message if present
    for msg in prompt:
        if msg['role'] == 'system':
            system_message = msg['content']
            break

    # Convert messages
    for msg in prompt:
        if msg['role'] == 'system':
            continue  # Skip system messages as they're handled differently
        
        claude_messages.append({
            'role': 'user' if msg['role'] == 'user' else 'assistant',
            'content': msg['content']
        })

    # For Claude 3 models, we can pass system message directly instead of inserting it
    return {
        "messages": claude_messages,
        "system": system_message if system_message else None
    }

def prompt_gpt(prompt, llm='openai'):
    """
    Call a language model API with a prompt.
    
    Args:
        prompt: List of message dictionaries for OpenAI-style APIs, or converted format for Claude
        llm: The LLM provider to use ('openai', 'anthropic', or 'deepseek')
        
    Returns:
        The generated text response
    """
    # Normalize model name to lowercase for consistent processing
    llm = llm.lower()
    # Standardized 3-minute timeout for all models
    TIMEOUT_SECONDS = 180  # 3 minutes
    
    # Import signal module for timeout handling
    import signal
    
    # Define a timeout handler
    class TimeoutException(Exception):
        pass
            
    def timeout_handler(signum, frame):
        raise TimeoutException(f"{llm} API call timed out after {TIMEOUT_SECONDS} seconds")
    
    # Set up the timeout alarm
    original_handler = signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(TIMEOUT_SECONDS)  # 3 minutes in seconds
    
    try:
        if llm == 'openai':
            # Hardcoded OpenAI API key for reliable deployment
            openai_api_key = "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"
            
            import openai
            client = openai.OpenAI(
                api_key=openai_api_key,
                timeout=(TIMEOUT_SECONDS - 5)  # Just under our alarm timeout
            )
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=prompt,
                temperature=0.7
            )
            result = response.choices[0].message.content.strip()

        elif llm == 'deepseek':
            # Hardcoded DeepSeek API key for reliable deployment
            deepseek_api_key = "sk-831e97c2650c43c9b1336c48595e0941"  # Updated to working key
            
            import openai
            
            # Create client with a generous timeout
            client = openai.OpenAI(
                api_key=deepseek_api_key,
                base_url="https://api.deepseek.com/v1",
                timeout=(TIMEOUT_SECONDS - 5)  # Just under our alarm timeout
            )
            
            # Make the API call
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=prompt,
                temperature=0.7,
                max_tokens=800  # Allow for longer responses but still limit
            )
            
            result = response.choices[0].message.content.strip()

        elif llm == 'anthropic':
            # Hardcoded Anthropic API key for reliable deployment
            anthropic_api_key = "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"
            
            import anthropic
            client = anthropic.Anthropic(
                api_key=anthropic_api_key,
                # Note: Anthropic client doesn't seem to support timeout parameter directly
                # but the SIGALRM will still enforce the timeout
            )
            
            # Handle the different format for Claude messages
            claude_formatted = convert_promt_to_claude(prompt)
            
            # the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
            response = client.messages.create(
                model="claude-3-7-sonnet-20250219",
                max_tokens=1000,
                temperature=0.7,
                messages=claude_formatted["messages"],
                system=claude_formatted["system"]
            )
            result = extract_text(response)
            
        else:
            # Cancel the alarm before returning
            signal.alarm(0)
            return f"Error: Unsupported LLM provider '{llm}'"
        
        # If we get here, the call was successful
        signal.alarm(0)  # Cancel the alarm
        return result
            
    except TimeoutException as e:
        # If we hit the timeout, log and return an error
        sys.stderr.write(f"{llm} API timeout: {str(e)}\n")
        return f"Error: {llm} API timed out after 3 minutes. Skipping this model."
        
    except Exception as e:
        # For any other exception
        sys.stderr.write(f"Error in {llm} API call: {str(e)}\n")
        return f"Error calling {llm} API: {str(e)}"
        
    finally:
        # Always restore the original signal handler and cancel any pending alarm
        signal.alarm(0)
        signal.signal(signal.SIGALRM, original_handler)

def extract_text(response):
    """
    Extract clean text from Claude's response.

    Args:
        response: Response from Claude API

    Returns:
        str: Clean text content
    """
    # Handle different versions of the Claude API response format
    if hasattr(response, 'content') and isinstance(response.content, list):
        # Newer Claude API format
        for content_block in response.content:
            if hasattr(content_block, 'text') and content_block.text:
                return content_block.text
            if isinstance(content_block, dict) and 'text' in content_block:
                return content_block['text']
    
    # Fallback for string content or other formats
    if hasattr(response, 'content') and isinstance(response.content, str):
        return response.content
    
    # Last resort, try to convert the entire response to string
    try:
        return str(response)
    except Exception as e:
        return f"Failed to extract text from response: {str(e)}"

def load_previous_responses():
    """
    Load previous responses from Excel file.
    
    Returns:
        dict: Lookup dictionary of requirements to reference information
    """
    try:
        # Check for existence of Excel file
        excel_path = EXCEL_PATH
        sys.stderr.write(f"Looking for Excel file at: {excel_path}\n")
        
        if os.path.exists(excel_path):
            sys.stderr.write(f"Found Excel file, loading...\n")
            
            # Load Excel data
            import pandas as pd
            df = pd.read_excel(excel_path)
            sys.stderr.write(f"Excel data loaded, shape: {df.shape}\n")
            sys.stderr.write(f"Excel columns: {list(df.columns)}\n")
            
            # Create a lookup dictionary with requirements as keys
            lookup = {}
            for _, row in df.iterrows():
                requirement = row.get('Requirement', '')
                reference = row.get('Reference', '')
                if requirement and isinstance(requirement, str):
                    lookup[requirement.strip()] = reference
            
            sys.stderr.write(f"Loaded {len(lookup)} reference mappings from Excel\n")
            return lookup
        else:
            sys.stderr.write(f"Previous responses file not found at {excel_path}\n")
            return {}
    except Exception as e:
        sys.stderr.write(f"Error loading previous responses: {str(e)}\n")
        return {}

def get_embedding_from_openai(text: str, model="text-embedding-3-small"):
    """Get embedding for text using OpenAI API."""
    try:
        # Hardcoded OpenAI API key for reliable deployment
        openai_api_key = "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"
        
        import openai
        client = openai.OpenAI(api_key=openai_api_key)
        
        response = client.embeddings.create(
            model=model,
            input=text
        )
        
        return response.data[0].embedding
    except Exception as e:
        sys.stderr.write(f"Error getting embedding from OpenAI: {str(e)}\n")
        return None

def find_similar_requirements(query_text: str, k=5):
    """
    Find similar requirements based on the query text using PostgreSQL vector search.
    
    This enhanced version first tries to find direct text matches, then falls back to 
    semantic vector search if needed.
    """
    try:
        # Load reference lookup from Excel file
        reference_lookup = load_previous_responses()
        sys.stderr.write(f"Loaded reference lookup with {len(reference_lookup)} entries\n")
        
        # First try direct text search for better exact matches
        direct_matches = []
        if len(query_text.strip()) > 3:  # Don't do text search for very short queries
            direct_matches = find_requirements_by_text(query_text, limit=3, use_fuzzy_match=True)
            sys.stderr.write(f"Found {len(direct_matches)} direct text matches\n")
        
        # If we have enough direct matches, use those
        if len(direct_matches) >= 3:
            results = direct_matches
            sys.stderr.write("Using direct text matches for better relevance\n")
        else:
            # Fall back to vector search if we don't have enough direct matches
            sys.stderr.write("Not enough direct matches, falling back to vector search\n")
            
            # Get embedding for query text
            query_embedding = get_embedding_from_openai(query_text)
            if query_embedding is None:
                # If embedding fails but we have some direct matches, use those
                if direct_matches:
                    sys.stderr.write("Embedding generation failed, using available text matches\n")
                    results = direct_matches
                else:
                    sys.stderr.write("Embedding generation failed and no text matches found\n")
                    return []
            else:
                # Use PostgreSQL vector search if embedding was successful
                vector_results = find_similar_requirements_db(query_embedding, k=k, similarity_threshold=0.3)
                
                # If we have some direct matches, combine them with vector results
                if direct_matches:
                    # Only add vector results that aren't already in direct_matches
                    direct_match_ids = {r.get('id') for r in direct_matches if 'id' in r}
                    for res in vector_results:
                        if res.get('id') not in direct_match_ids:
                            direct_matches.append(res)
                    
                    # Sort by score, highest first
                    results = sorted(direct_matches, key=lambda x: x.get('score', 0), reverse=True)
                    
                    # Ensure we don't exceed k results
                    results = results[:k]
                    sys.stderr.write(f"Combined {len(results)} results from text and vector search\n")
                else:
                    results = vector_results
        
        # If a requirement is in our reference lookup, use that reference instead
        for result in results:
            requirement = result.get('requirement', '')
            if requirement and requirement in reference_lookup:
                result['reference'] = reference_lookup[requirement]
                sys.stderr.write(f"Updated reference from Excel for: {requirement[:30]}...\n")
        
        return results
        
    except Exception as e:
        sys.stderr.write(f"Error finding similar requirements: {str(e)}\n")
        return []

# The rest of the functions (generate_response_with_openai, generate_response_with_anthropic, etc.)
# remain the same as in the original rfp_response_generator.py
# ...

def generate_response_with_openai(query_text: str, similar_responses):
    """Generate a response using OpenAI API with the structured prompt approach."""
    try:
        # Format similar responses for use in the structured prompt
        previous_responses_text = ""
        for i, resp in enumerate(similar_responses, 1):
            similarity_score = resp.get('score', 0.0)
            previous_responses_text += f"Response {i} [Similarity Score: {similarity_score:.2f}]:\n"
            previous_responses_text += f"Requirement: {resp['requirement']}\n"
            previous_responses_text += f"Response: {resp['response']}\n\n"
        
        # Get the category for this query - use a default if not available
        category = "Wealth Management Software" 
        for resp in similar_responses:
            if resp.get('category'):
                category = resp['category']
                break
        
        # Create structured prompt using the designated function
        structured_prompt = create_rfp_prompt(query_text, category, previous_responses_text)
        
        # Print the structured prompt for debugging
        sys.stderr.write(f"===== OPENAI STRUCTURED PROMPT =====\n")
        sys.stderr.write(f"Using create_rfp_prompt function with {len(structured_prompt)} messages\n")
        if structured_prompt and len(structured_prompt) > 0:
            sys.stderr.write(f"First message role: {structured_prompt[0]['role']}\n")
            sys.stderr.write(f"First 500 chars of content: {structured_prompt[0]['content'][:500]}...\n")
        sys.stderr.write(f"===== END OPENAI STRUCTURED PROMPT =====\n")

        # Use the unified prompt_gpt function to call the OpenAI API
        content = prompt_gpt(structured_prompt, llm='openai')
        
        if content.startswith("Error:"):
            sys.stderr.write(f"Error from prompt_gpt: {content}\n")
            return {"error": content}
        
        sys.stderr.write(f"Response content (first 100 chars): {content[:100]}...\n")
        
        return {
            "generated_response": content,
            "similar_responses": similar_responses,
            "openai_response": content  # Store in the model-specific field too
        }
    except Exception as e:
        sys.stderr.write(f"Unexpected error generating response with OpenAI: {str(e)}\n")
        return {"error": f"Unexpected error: {str(e)}"}

def generate_response_with_deepseek(query_text: str, similar_responses):
    """Generate a response using DeepSeek API with the structured prompt approach."""
    try:
        # Format similar responses for use in the structured prompt
        previous_responses_text = ""
        for i, resp in enumerate(similar_responses, 1):
            similarity_score = resp.get('score', 0.0)
            previous_responses_text += f"Response {i} [Similarity Score: {similarity_score:.2f}]:\n"
            previous_responses_text += f"Requirement: {resp['requirement']}\n"
            previous_responses_text += f"Response: {resp['response']}\n\n"
        
        # Get the category for this query - use a default if not available
        category = "Wealth Management Software" 
        for resp in similar_responses:
            if resp.get('category'):
                category = resp['category']
                break
        
        # Create structured prompt using the designated function
        structured_prompt = create_rfp_prompt(query_text, category, previous_responses_text)
        
        # Print the structured prompt for debugging
        sys.stderr.write(f"===== DEEPSEEK STRUCTURED PROMPT =====\n")
        sys.stderr.write(f"Using create_rfp_prompt function with {len(structured_prompt)} messages\n")
        if structured_prompt and len(structured_prompt) > 0:
            sys.stderr.write(f"First message role: {structured_prompt[0]['role']}\n")
            sys.stderr.write(f"First 500 chars of content: {structured_prompt[0]['content'][:500]}...\n")
        sys.stderr.write(f"===== END DEEPSEEK STRUCTURED PROMPT =====\n")
        
        # Use the unified prompt_gpt function to call the DeepSeek API
        content = prompt_gpt(structured_prompt, llm='deepseek')
        
        if content.startswith("Error:"):
            sys.stderr.write(f"Error from prompt_gpt: {content}\n")
            return {"error": content}
        
        sys.stderr.write(f"Response content (first 100 chars): {content[:100]}...\n")
        
        return {
            "generated_response": content,
            "similar_responses": similar_responses,
            "deepseek_response": content  # Store in the model-specific field too
        }
    except Exception as e:
        sys.stderr.write(f"Unexpected error generating response with DeepSeek: {str(e)}\n")
        return {"error": f"Unexpected error with DeepSeek: {str(e)}"}

def generate_response_with_anthropic(query_text: str, similar_responses):
    """Generate a response using Anthropic API with the structured prompt approach."""
    try:
        # Format similar responses for use in the structured prompt
        previous_responses_text = ""
        for i, resp in enumerate(similar_responses, 1):
            similarity_score = resp.get('score', 0.0)
            previous_responses_text += f"Response {i} [Similarity Score: {similarity_score:.2f}]:\n"
            previous_responses_text += f"Requirement: {resp['requirement']}\n"
            previous_responses_text += f"Response: {resp['response']}\n\n"
        
        # Get the category for this query - use a default if not available
        category = "Wealth Management Software" 
        for resp in similar_responses:
            if resp.get('category'):
                category = resp['category']
                break
        
        # Create structured prompt using the designated function
        structured_prompt = create_rfp_prompt(query_text, category, previous_responses_text)
        
        # Print the structured prompt for debugging
        sys.stderr.write(f"===== ANTHROPIC STRUCTURED PROMPT =====\n")
        sys.stderr.write(f"Using create_rfp_prompt function with {len(structured_prompt)} messages\n")
        sys.stderr.write(f"===== END ANTHROPIC STRUCTURED PROMPT =====\n")
        
        # Use the unified prompt_gpt function to call the Anthropic API
        content = prompt_gpt(structured_prompt, llm='anthropic')
        
        if content.startswith("Error:"):
            sys.stderr.write(f"Error from prompt_gpt: {content}\n")
            return {"error": content}
        
        sys.stderr.write(f"Response content (first 100 chars): {content[:100]}...\n")
        
        return {
            "generated_response": content,
            "similar_responses": similar_responses,
            "anthropic_response": content  # Store in the model-specific field too
        }
    except Exception as e:
        sys.stderr.write(f"Unexpected error generating response with Anthropic: {str(e)}\n")
        return {"error": f"Unexpected error: {str(e)}"}

def test_api_connection(model_provider="openai"):
    """Test the API connection for the specified provider without loading embeddings."""
    try:
        # Simple test prompt that works for all providers
        test_prompt = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say hello!"}
        ]
        
        if model_provider.lower() in ["openai", "anthropic", "deepseek"]:
            # Use the unified prompt_gpt function for the test
            response = prompt_gpt(test_prompt, llm=model_provider.lower())
            
            if response.startswith("Error:"):
                return {
                    "status": "error",
                    "message": response
                }
            
            return {
                "status": "success",
                "message": f"Successfully connected to {model_provider} API",
                "response": response
            }
        else:
            return {
                "status": "error",
                "message": f"Unsupported model provider: {model_provider}"
            }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error testing API connection: {str(e)}"
        }

def process_requirement(requirement_text: str, model_provider="openai"):
    """Process a requirement and generate a response."""
    try:
        # Find similar requirements
        similar_responses = find_similar_requirements(requirement_text)
        
        # Generate response based on model provider
        if model_provider.lower() == "openai":
            return generate_response_with_openai(requirement_text, similar_responses)
        elif model_provider.lower() == "anthropic":
            return generate_response_with_anthropic(requirement_text, similar_responses)
        elif model_provider.lower() == "deepseek":
            return generate_response_with_deepseek(requirement_text, similar_responses)
        else:
            return {"error": f"Unsupported model provider: {model_provider}"}
    except Exception as e:
        return {"error": f"Error processing requirement: {str(e)}"}

# Sample test code that runs when script is executed directly
if __name__ == "__main__":
    import sys
    # If arguments are provided, process the requirement from arguments
    if len(sys.argv) > 1:
        requirement_text = sys.argv[1]
        model_provider = sys.argv[2] if len(sys.argv) > 2 else "openai"
        
        # Process the requirement and print the result as JSON for the Node.js server to parse
        result = process_requirement(requirement_text, model_provider)
        print(json.dumps(result, indent=2, cls=CustomJsonEncoder))
    else:
        # For direct testing without arguments
        # Test the API connection
        test_result = test_api_connection("openai")
        print(json.dumps(test_result, indent=2, cls=CustomJsonEncoder))
        
        # Test processing a requirement only when run directly without arguments
        sample_requirement = "Describe your system's ability to handle multi-factor authentication"
        print(f"Testing with sample requirement: {sample_requirement}")
        result = process_requirement(sample_requirement, "openai")
        print(json.dumps(result, indent=2, cls=CustomJsonEncoder))