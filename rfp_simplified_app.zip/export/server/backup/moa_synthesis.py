#!/usr/bin/env python3
"""
MOA Synthesis Script
Demonstrates the Mixture of Agents approach for RFP response generation
"""

import sys
import time
import json
from rfp_response_generator_pg import prompt_gpt, create_rfp_prompt

def synthesize_responses(requirement, model_responses):
    """
    Synthesize responses from multiple models
    
    Args:
        requirement: The RFP requirement text
        model_responses: Dictionary containing model responses
        
    Returns:
        Synthesized response
    """
    # Create synthesis prompt
    synthesis_prompt = create_synthesis_prompt(requirement, model_responses)
    
    # Use OpenAI for synthesis
    print("Using OpenAI for response synthesis...")
    
    try:
        synthesized = prompt_gpt(synthesis_prompt, llm='openAI')
        return synthesized
    except Exception as e:
        print(f"Error in synthesis: {str(e)}")
        # Fallback to best available response
        if model_responses.get("openai"):
            return model_responses["openai"]
        elif model_responses.get("anthropic"):
            return model_responses["anthropic"]
        elif model_responses.get("deepseek"):
            return model_responses["deepseek"]
        else:
            return "Failed to synthesize a response."

def create_synthesis_prompt(requirement, responses):
    """
    Generate a prompt to synthesize multiple RFP responses into a cohesive, impactful response.

    Args:
        requirement: The specific RFP requirement to address.
        responses: Dictionary of model responses.

    Returns:
        List of messages for the LLM.
    """
    system_message = """You are an expert AI Synthesizer specialized in creating optimal RFP (Request for Proposal) responses.
Your task is to analyze multiple AI-generated responses to the same RFP requirement, critically evaluate the strengths and weaknesses of each,
and then synthesize them into a single, cohesive, high-quality response.

Focus on:
1. Extracting the most accurate, relevant, and specific content from each response
2. Ensuring technical accuracy and domain-appropriate terminology
3. Maintaining a professional, confident tone
4. Creating a coherent flow with proper transitions
5. Providing specific details rather than generic statements
6. Addressing all aspects of the requirement comprehensively
7. Structuring the response in clear, readable paragraphs

The final response should demonstrate deep expertise in the relevant domain, directly address the requirement,
and be optimized for persuasiveness and clarity."""

    # Format model responses for the prompt
    openai_response = responses.get("openai", "No response available from OpenAI model.")
    anthropic_response = responses.get("anthropic", "No response available from Anthropic model.")
    deepseek_response = responses.get("deepseek", "No response available from DeepSeek model.")

    user_message = f"""I need you to synthesize the best possible RFP response by analyzing and combining elements from these AI-generated responses to the following requirement:

REQUIREMENT: {requirement}

RESPONSE FROM MODEL 1 (OPENAI):
{openai_response}

RESPONSE FROM MODEL 2 (ANTHROPIC):
{anthropic_response}

RESPONSE FROM MODEL 3 (DEEPSEEK):
{deepseek_response}

First, briefly analyze the strengths and weaknesses of each response. Then, create a single synthesized response that incorporates the best elements from all responses, addresses any gaps or inaccuracies, and forms a comprehensive answer to the requirement. The synthesized response should stand alone as a complete, professional RFP response."""

    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

def generate_model_response(requirement, model_name, category="Wealth Management Software", previous_responses=""):
    """
    Generate a response from a specific model
    
    Args:
        requirement: The RFP requirement text
        model_name: Name of the model to use ('openAI', 'anthropic', or 'deepseek')
        category: The category of the requirement
        previous_responses: Previous similar responses for context
        
    Returns:
        Response text
    """
    try:
        # Create structured prompt
        prompt = create_rfp_prompt(requirement, category, previous_responses)
        
        # Get response with timeout handling
        print(f"Requesting response from {model_name}...")
        start_time = time.time()
        
        response = prompt_gpt(prompt, llm=model_name)
        
        elapsed_time = time.time() - start_time
        print(f"✅ {model_name} response received in {elapsed_time:.2f}s")
        
        return response
    except Exception as e:
        print(f"❌ {model_name} error: {str(e)}")
        return f"Error from {model_name}: {str(e)}"

def generate_moa_response(requirement, category="Wealth Management Software", previous_responses=""):
    """
    Generate a response using the MOA (Mixture of Agents) approach
    
    This is the main function that coordinates the process.
    
    Args:
        requirement: The RFP requirement text
        category: The category of the requirement
        previous_responses: Previous similar responses for context
        
    Returns:
        Dictionary with results
    """
    print(f"\n{'='*80}\nGENERATING MOA RESPONSE FOR: {requirement}\n{'='*80}")
    
    start_time = time.time()
    
    # Phase 1: Get responses from individual models
    print("\n--- PHASE 1: GENERATING INDIVIDUAL MODEL RESPONSES ---")
    
    model_responses = {}
    
    # We'll try all three models but handle failures gracefully
    models_to_try = ['openAI', 'anthropic', 'deepseek']
    successfully_completed = []
    
    for model in models_to_try:
        try:
            response = generate_model_response(requirement, model, category, previous_responses)
            
            # Only add successful, non-error responses
            if not response.startswith("Error"):
                model_responses[model.lower()] = response
                successfully_completed.append(model)
        except Exception as e:
            print(f"Failed to get response from {model}: {str(e)}")
    
    # Check if we have enough responses to proceed
    if len(successfully_completed) == 0:
        print("No model responses were successfully generated")
        return {
            "status": "error",
            "message": "All models failed to generate responses",
            "elapsed_time": time.time() - start_time
        }
    
    print(f"\nSuccessfully generated responses from {len(successfully_completed)} models: {', '.join(successfully_completed)}")
    
    # Phase 2: Synthesize responses
    print("\n--- PHASE 2: SYNTHESIZING RESPONSES ---")
    
    # If we only have one response, just use that
    if len(successfully_completed) == 1:
        print(f"Only one model ({successfully_completed[0]}) succeeded, using its response directly")
        final_response = model_responses[successfully_completed[0].lower()]
    else:
        # Otherwise, synthesize responses
        print(f"Synthesizing responses from {len(successfully_completed)} models...")
        final_response = synthesize_responses(requirement, model_responses)
    
    total_time = time.time() - start_time
    print(f"\nMOA process completed in {total_time:.2f}s")
    
    # Return all the information
    return {
        "status": "success",
        "final_response": final_response,
        "model_responses": model_responses,
        "models_succeeded": successfully_completed,
        "total_models_attempted": len(models_to_try),
        "elapsed_time": total_time
    }

# Simple standalone test
if __name__ == "__main__":
    # Sample requirement for testing
    test_requirement = "Describe the document management capabilities of your wealth management platform."
    
    # Run MOA process
    result = generate_moa_response(test_requirement)
    
    # Print the final response
    print(f"\n{'='*80}\nFINAL MOA RESPONSE\n{'='*80}\n")
    print(result["final_response"])
    
    # Print stats
    print(f"\n{'='*80}\nPERFORMANCE METRICS\n{'='*80}")
    print(f"Total time: {result['elapsed_time']:.2f}s")
    print(f"Models succeeded: {len(result['models_succeeded'])} of {result['total_models_attempted']}")
    print(f"Models: {', '.join(result['models_succeeded'])}")
    
    # Write results to file for inspection
    with open("moa_test_results.json", "w") as f:
        json.dump({
            "requirement": test_requirement,
            "final_response": result["final_response"],
            "individual_responses": result["model_responses"],
            "metrics": {
                "elapsed_time": result["elapsed_time"],
                "models_succeeded": result["models_succeeded"],
                "total_models_attempted": result["total_models_attempted"]
            }
        }, f, indent=2)
    
    print(f"\nResults saved to moa_test_results.json")