#!/usr/bin/env python3
"""
Test script for PostgreSQL vector search
This script tests the vector search functionality directly and logs the output
"""
import sys
import json
import os
from pg_vector_search import find_similar_requirements_db, find_requirements_by_text
from rfp_response_generator_pg import get_embedding_from_openai

# Enable detailed debugging
os.environ['DEBUG_MODE'] = 'true'

def test_vector_search_with_real_text():
    """Test vector search with a real sample text"""
    sample_text = "Please describe your solution's security capabilities including multi-factor authentication and data encryption."
    
    print("=" * 50)
    print(f"Testing vector search with text: '{sample_text}'")
    print("=" * 50)
    
    # Get embedding for the query text
    print("Generating embedding from OpenAI...")
    query_embedding = get_embedding_from_openai(sample_text)
    
    if query_embedding is None:
        print("Failed to generate embedding for test")
        return False
    
    print(f"Embedding generated successfully: {len(query_embedding)} dimensions")
    
    # Test vector search
    print("Executing vector search...")
    results = find_similar_requirements_db(query_embedding, k=5, similarity_threshold=0.1)
    
    # Log results
    print(f"Found {len(results)} results")
    
    # Print the results in formatted JSON
    print("Vector search results (detailed):")
    print(json.dumps(results, indent=2))
    
    # Check if results are in expected format
    print("\nVerifying result format...")
    
    if not results:
        print("WARNING: No results found. Cannot verify format.")
        return False
    
    expected_fields = ['text', 'score', 'category', 'requirement', 'response', 'reference']
    missing_fields = []
    
    for field in expected_fields:
        if field not in results[0]:
            missing_fields.append(field)
    
    if missing_fields:
        print(f"WARNING: Results missing expected fields: {', '.join(missing_fields)}")
        return False
    else:
        print("SUCCESS: Results contain all expected fields!")
    
    return True

def test_text_search():
    """Test direct text search functionality"""
    sample_text = "security"
    
    print("=" * 50)
    print(f"Testing text search with term: '{sample_text}'")
    print("=" * 50)
    
    # Test text search
    results = find_requirements_by_text(sample_text, limit=3, use_fuzzy_match=True)
    
    # Log results
    print(f"Found {len(results)} text search results")
    
    # Print the results in formatted JSON
    print("Text search results:")
    print(json.dumps(results, indent=2))
    
    return len(results) > 0

if __name__ == "__main__":
    # Run both tests
    vector_search_success = test_vector_search_with_real_text()
    text_search_success = test_text_search()
    
    # Print overall status
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    print(f"Vector search test: {'PASSED' if vector_search_success else 'FAILED'}")
    print(f"Text search test: {'PASSED' if text_search_success else 'FAILED'}")
    
    # Set exit code based on success
    sys.exit(0 if vector_search_success and text_search_success else 1)