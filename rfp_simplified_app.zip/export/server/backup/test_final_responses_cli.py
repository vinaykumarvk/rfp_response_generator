#!/usr/bin/env python3
"""
Command-line test script for get_final_responses
This script allows testing the get_final_responses function from the command line
"""

import sys
import json
import time
from test_get_final_responses import get_final_responses

def main():
    """Main function when script is run directly"""
    # Check if we have a requirement from command-line
    if len(sys.argv) != 2:
        print("Usage: python test_final_responses_cli.py \"Your requirement text\"")
        sys.exit(1)
    
    # Get the requirement from command-line
    requirement = sys.argv[1]
    
    # Get the final responses
    print(f"Processing requirement: {requirement}")
    start_time = time.time()
    
    result = get_final_responses(requirement)
    
    # Print the result
    print(f"\nFinal response ({time.time() - start_time:.2f}s):")
    print("="*80)
    print(result["final_response"])
    print("="*80)
    
    # Print metrics
    print(f"\nMetrics:")
    print(f"- Total time: {result['metrics']['total_time']:.2f}s")
    print(f"- Models succeeded: {result['metrics']['models_succeeded']} of {result['metrics']['models_attempted']}")
    
    # Output JSON for the server response
    print("\nJSON response:")
    print(json.dumps(result))

if __name__ == "__main__":
    main()