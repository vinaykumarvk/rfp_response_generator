#!/usr/bin/env python3
"""
Test script to verify the complete flow:
1. PostgreSQL vector search
2. Prompt creation
3. OpenAI API call

This script tests the integration of PostgreSQL vector search with OpenAI response generation.
"""
import os
import sys
import json
import time
from datetime import datetime
import psycopg2
import openai

# Constants
DEFAULT_TEST_QUERY = "Describe your system's capabilities for multi-factor authentication"
MAX_EXAMPLES = 3
VERBOSE = True

def get_database_connection():
    """Get a connection to the PostgreSQL database."""
    try:
        # Get connection string from environment variable
        db_url = os.environ.get('DATABASE_URL')
        if not db_url:
            sys.stderr.write("DATABASE_URL environment variable not set\n")
            sys.exit(1)
        
        # Connect to the database
        conn = psycopg2.connect(db_url)
        if VERBOSE:
            print("Successfully connected to PostgreSQL database")
        return conn
    except Exception as e:
        sys.stderr.write(f"Error connecting to database: {str(e)}\n")
        sys.exit(1)

def get_openai_client():
    """Get the OpenAI client."""
    try:
        # Get API key from environment variable
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            sys.stderr.write("OPENAI_API_KEY environment variable not set\n")
            sys.exit(1)
        
        # Create OpenAI client
        client = openai.OpenAI(api_key=api_key)
        if VERBOSE:
            print(f"Successfully created OpenAI client (API key starts with {api_key[:5]}...)")
        return client
    except Exception as e:
        sys.stderr.write(f"Error creating OpenAI client: {str(e)}\n")
        sys.exit(1)

def normalize_vector(vector):
    """Normalize a vector to unit length."""
    import numpy as np
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm

def get_embedding_from_openai(text, model="text-embedding-3-small"):
    """Get embedding for text using OpenAI API."""
    try:
        client = get_openai_client()
        response = client.embeddings.create(
            input=text,
            model=model
        )
        embedding = response.data[0].embedding
        if VERBOSE:
            print(f"Successfully obtained embedding from OpenAI (dimension: {len(embedding)})")
        return embedding
    except Exception as e:
        sys.stderr.write(f"Error getting embedding from OpenAI: {str(e)}\n")
        sys.exit(1)

def find_similar_requirements_db(query_embedding, k=5, similarity_threshold=0.01):
    """
    Find similar requirements in PostgreSQL database using vector similarity search.
    
    Args:
        query_embedding: The embedding vector to search for
        k: Number of results to return
        similarity_threshold: Minimum similarity score (0-1)
        
    Returns:
        List of dictionary objects with similar requirements
    """
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Normalize the query vector for better results
        query_embedding = normalize_vector(query_embedding)
        if VERBOSE:
            print("Query vector normalized successfully")
        
        # Convert embedding to string format for PostgreSQL
        vector_str = f"[{','.join(str(x) for x in query_embedding)}]"
        
        # Execute vector search using cosine similarity
        if VERBOSE:
            print(f"Searching with similarity threshold: {similarity_threshold}")
        
        cursor.execute("""
        SELECT 
            id, category, requirement, response, reference, 
            embedding <=> %s::vector AS similarity
        FROM 
            embeddings
        WHERE 
            embedding <=> %s::vector <= 2.0
        ORDER BY 
            similarity ASC
        LIMIT %s;
        """, (vector_str, vector_str, k))
        
        results = cursor.fetchall()
        if VERBOSE:
            print(f"Query returned {len(results)} results")
        
        if not results:
            print("No similar requirements found")
            return []
        
        # Calculate actual similarity (1 - distance) for better interpretability
        # PostgreSQL returns distance, not similarity
        top_similarity = 1 - results[0][5]
        lowest_similarity = 1 - results[-1][5]
        
        if VERBOSE:
            print(f"Top similarity score: {top_similarity}")
            print(f"Lowest similarity score: {lowest_similarity}")
        
        # Convert to list of dictionaries
        similar_requirements = []
        for row in results:
            id, category, requirement, response, reference, distance = row
            similarity = 1 - distance  # Convert distance to similarity
            
            # Only include results above the similarity threshold
            if similarity >= similarity_threshold:
                similar_requirements.append({
                    'id': id,
                    'category': category,
                    'requirement': requirement,
                    'response': response,
                    'reference': reference,
                    'similarity': similarity
                })
        
        if VERBOSE:
            print(f"Returning {len(similar_requirements)} results")
        
        cursor.close()
        conn.close()
        return similar_requirements
    
    except Exception as e:
        sys.stderr.write(f"Error in vector search: {str(e)}\n")
        sys.exit(1)

def create_rfp_prompt(new_question, category, previous_responses):
    """
    Create an optimized prompt for RFP response generation.

    Args:
        new_question: The current RFP requirement to address.
        category: Functional category of the requirement.
        previous_responses: List of previous responses with their similarity scores.
    """
    system_message = """You are an expert RFP response assistant. Your task is to generate a comprehensive response to the following requirement:"""
    
    # Build examples section
    examples_text = ""
    if previous_responses:
        examples_text = "\n\nHere are some examples of similar requirements and their responses that you can use as reference:\n\n"
        
        for i, resp in enumerate(previous_responses, 1):
            req = resp.get('requirement', '')
            response = resp.get('response', '')
            similarity = resp.get('similarity', 0)
            
            if req and response:
                examples_text += f"\nExample {i}:\n- Requirement: {req}\n- Response: {response}\n"
                if VERBOSE:
                    print(f"Example {i}: similarity={similarity:.3f}")
    
    # Build guideline section
    guideline_text = """\n
Guidelines for your response:
1. Be comprehensive and detailed, addressing all aspects of the requirement.
2. Use a structured format with clear headings.
3. Highlight any unique or innovative features.
4. Be factual and avoid exaggerated claims.
5. Keep the language professional but accessible.
6. Focus on benefits and value, not just features.
"""
    
    # Combine all parts into the final prompt
    prompt = f"{system_message}\n\nRequirement: {new_question}{examples_text}{guideline_text}"
    
    if VERBOSE:
        print("\n===== PROMPT =====")
        print(prompt[:500] + "..." if len(prompt) > 500 else prompt)
        print("=====  END PROMPT =====\n")
    
    return prompt

def generate_response_with_openai(prompt, model="gpt-4o"):
    """Generate a response using OpenAI API."""
    try:
        client = get_openai_client()
        
        if VERBOSE:
            print(f"Calling OpenAI API with {model} model...")
        
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are an expert in generating RFP responses."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000,
            timeout=30  # 30 second timeout
        )
        
        response_text = response.choices[0].message.content
        
        if VERBOSE:
            print(f"Response received from OpenAI (length: {len(response_text)} chars)")
            print("\n===== RESPONSE PREVIEW =====")
            print(response_text[:300] + "..." if len(response_text) > 300 else response_text)
            print("=====  END PREVIEW =====\n")
        
        return response_text
    
    except Exception as e:
        sys.stderr.write(f"Error generating response with OpenAI: {str(e)}\n")
        sys.exit(1)

def process_requirement(query_text):
    """Process a requirement and generate a response using OpenAI."""
    start_time = time.time()
    
    # Get embedding for the query
    query_embedding = get_embedding_from_openai(query_text)
    
    # Find similar requirements
    similar_requirements = find_similar_requirements_db(
        query_embedding,
        k=MAX_EXAMPLES,
        similarity_threshold=0.01
    )
    
    # Print similar requirements
    if VERBOSE:
        print("\nSimilar requirements found:")
        for i, req in enumerate(similar_requirements, 1):
            print(f"{i}. {req['requirement'][:50]}... (similarity: {req['similarity']:.3f})")
    
    # Determine category (use most common category from similar requirements)
    category = None
    if similar_requirements:
        categories = {}
        for req in similar_requirements:
            cat = req.get('category')
            if cat:
                categories[cat] = categories.get(cat, 0) + 1
        
        if categories:
            category = max(categories.items(), key=lambda x: x[1])[0]
    
    # Create prompt
    prompt = create_rfp_prompt(query_text, category, similar_requirements)
    
    # Generate response
    response = generate_response_with_openai(prompt)
    
    # Calculate total time
    end_time = time.time()
    total_time = end_time - start_time
    
    if VERBOSE:
        print(f"\nTotal processing time: {total_time:.2f} seconds")
    
    return {
        'query': query_text,
        'category': category,
        'similar_count': len(similar_requirements),
        'response': response,
        'processing_time': total_time
    }

def main(query_text=None):
    """Run the test."""
    print("=" * 60)
    print(f"PostgreSQL + OpenAI Integration Test")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("=" * 60)
    
    # Use the provided query or the default
    if not query_text:
        query_text = DEFAULT_TEST_QUERY
    
    print(f"\nProcessing requirement: {query_text}\n")
    
    # Process the requirement
    result = process_requirement(query_text)
    
    # Print the summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print(f"Query: {result['query']}")
    print(f"Determined Category: {result['category']}")
    print(f"Similar Requirements Found: {result['similar_count']}")
    print(f"Response Length: {len(result['response'])} characters")
    print(f"Total Processing Time: {result['processing_time']:.2f} seconds")
    print("=" * 60)
    
    print("\nComplete Response:")
    print("-" * 60)
    print(result['response'])
    print("-" * 60)
    
    print("\nTest completed successfully!")

if __name__ == "__main__":
    # Accept a query from command line arguments if provided
    query = None
    if len(sys.argv) > 1:
        query = sys.argv[1]
    
    main(query)