#!/usr/bin/env python3
"""
Test script to generate responses to a sample RFP requirement
Shows the exact prompt used and the detailed response from each model
"""

import sys
import json
from rfp_response_generator_pg import create_rfp_prompt, prompt_gpt

def test_with_sample_requirement():
    """Test each model with a sample requirement and show prompts and responses"""
    print("\n" + "="*80)
    print("TESTING WITH SAMPLE RFP REQUIREMENT - DETAILED OUTPUTS")
    print("="*80)
    
    # Sample RFP requirement
    sample_requirement = "Describe your platform's document management capabilities and how they support compliance requirements in wealth management."
    
    # Sample previous responses for context
    previous_responses = """
Response 1 [Similarity Score: 0.95]:
Requirement: Explain how your system handles document storage and retrieval for regulatory purposes.
Response: Our wealth management platform features a comprehensive document management system with advanced storage, indexing, and retrieval capabilities. Documents are stored in a secure, encrypted repository with hierarchical organization by client, account, and document type. The system maintains version control and complete audit trails of all document access and modifications. For regulatory purposes, our platform implements automatic retention policies based on document types, ensuring documents are preserved for the required regulatory periods. The search functionality allows for rapid document retrieval using multiple criteria including metadata, content, date ranges, and document types. Additionally, our system supports automated regulatory reporting by easily identifying and compiling required documentation for examinations or audits.

Response 2 [Similarity Score: 0.87]:
Requirement: Detail your platform's approach to document retention policies.
Response: Our platform implements a sophisticated document retention framework designed specifically for wealth management firms. The system allows for configurable retention policies based on document type, regulatory requirements, and firm-specific policies. Documents are automatically flagged for retention based on their classification and relevant regulations (SEC, FINRA, etc.), with appropriate retention periods enforced. The platform prevents premature deletion of documents under retention and provides automated notifications when documents reach the end of their required retention period. For documents subject to legal holds, the system offers special handling to override normal retention periods until the hold is released. All retention activities are fully logged with appropriate metadata to demonstrate compliance during regulatory examinations. Administrators can generate comprehensive reports showing retention policy compliance across the entire document repository.

Response 3 [Similarity Score: 0.82]:
Requirement: How does your system ensure documents are securely shared with clients?
Response: Our wealth management platform employs multiple layers of security to ensure documents are securely shared with clients. All client-facing document sharing is conducted through our encrypted client portal, which requires multi-factor authentication for access. Documents shared through the portal never leave our secure environment, as clients view documents through a secure viewer rather than downloading local copies, unless specifically permitted by advisor controls. When external sharing is necessary, the system applies automatic encryption and password protection, with passwords delivered through separate communication channels. The platform maintains comprehensive audit trails of all document sharing activities, recording who shared what document, when, and with whom. Document access can be time-limited and revoked remotely if needed. Additionally, watermarking can be automatically applied to sensitive documents to deter unauthorized distribution. All of these security measures are designed to maintain compliance with regulations while providing a seamless client experience.
"""
    
    # Create the structured prompt for the requirement
    structured_prompt = create_rfp_prompt(sample_requirement, "Wealth Management Software", previous_responses)
    
    # Test with each model
    models = ["openAI", "anthropic", "deepseek"]
    
    for model in models:
        print(f"\n{'='*40}")
        print(f"TESTING WITH {model.upper()}")
        print(f"{'='*40}")
        
        # Print the prompt structure
        print("\nPROMPT STRUCTURE:")
        print(f"Number of messages: {len(structured_prompt)}")
        
        for i, msg in enumerate(structured_prompt):
            print(f"\nMessage {i+1} [Role: {msg['role']}]")
            print(f"First 200 chars: {msg['content'][:200]}...")
            print(f"Last 200 chars: ...{msg['content'][-200:] if len(msg['content']) > 200 else msg['content']}")
        
        # Send the prompt to the model
        print(f"\nSending prompt to {model}...")
        
        try:
            response = prompt_gpt(structured_prompt, llm=model)
            
            print(f"\nRESPONSE FROM {model.upper()}:")
            print("-"*80)
            print(response)
            print("-"*80)
            
        except Exception as e:
            print(f"ERROR: {str(e)}")
    
if __name__ == "__main__":
    test_with_sample_requirement()