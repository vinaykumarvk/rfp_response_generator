#!/usr/bin/env python3
"""
Final MOA Test
This script tests the final MOA implementation with a specific requirement
"""

import json
import sys
import time
from moa_final import generate_moa_response

def test_moa_with_requirement(requirement):
    """Test the MOA implementation with a specific requirement"""
    print(f"\n{'='*80}")
    print(f"TESTING MOA WITH REQUIREMENT: {requirement}")
    print(f"{'='*80}")
    
    try:
        # Start timer
        start_time = time.time()
        
        # Generate the MOA response
        result = generate_moa_response(requirement)
        
        # Calculate total time
        total_time = time.time() - start_time
        
        # Print metrics
        print(f"\n{'='*80}")
        print(f"MOA TEST RESULTS")
        print(f"{'='*80}")
        print(f"Status: {result['status']}")
        print(f"Total time: {total_time:.2f}s")
        print(f"Models succeeded: {result['metrics']['models_succeeded']} of {result['metrics']['models_attempted']}")
        
        # Print final response
        print(f"\n{'='*80}")
        print(f"FINAL MOA RESPONSE")
        print(f"{'='*80}")
        print(result['final_response'])
        
        # Save results to file
        filename = f"moa_test_result_{int(time.time())}.json"
        with open(filename, "w") as f:
            json.dump({
                "requirement": requirement,
                "result": result
            }, f, indent=2)
            
        print(f"\nResults saved to {filename}")
    
    except Exception as e:
        print(f"\nError testing MOA: {str(e)}")

if __name__ == "__main__":
    # Use a specific requirement for testing
    requirement = "Describe the document management capabilities of your wealth management platform and how they support regulatory compliance."
    
    test_moa_with_requirement(requirement)