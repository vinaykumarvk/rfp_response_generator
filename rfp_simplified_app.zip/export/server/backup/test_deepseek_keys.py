#!/usr/bin/env python3
"""Test script specifically for testing DeepSeek API keys"""

import os
import sys
import json
import time
import openai

def test_deepseek_key(api_key):
    """Test a DeepSeek API key for validity"""
    print(f"Testing DeepSeek API key: {api_key[:5]}...{api_key[-4:]}")
    
    try:
        # Setup client with the provided key
        client = openai.OpenAI(
            api_key=api_key,
            base_url="https://api.deepseek.com/v1"
        )
        
        # Simple test prompt
        test_prompt = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say hello briefly."}
        ]
        
        # Make the API call
        start_time = time.time()
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=test_prompt,
            temperature=0.7,
            timeout=30
        )
        elapsed_time = time.time() - start_time
        
        # Extract response
        content = response.choices[0].message.content.strip()
        
        print(f"✅ SUCCESS - Response received in {elapsed_time:.2f}s")
        print(f"Response: {content[:100]}...")
        return True, content, elapsed_time
        
    except Exception as e:
        print(f"❌ FAILED - Error: {str(e)}")
        return False, str(e), 0

# Test both keys
if __name__ == "__main__":
    keys = [
        "Sk-95d5e11be4274313ba8c676659ad5ecb",
        "sk-831e97c2650c43c9b1336c48595e0941"
    ]
    
    print("\n" + "="*50)
    print("TESTING DEEPSEEK API KEYS")
    print("="*50)
    
    working_key = None
    
    for i, key in enumerate(keys, 1):
        print(f"\nKey #{i}:")
        success, response, time_taken = test_deepseek_key(key)
        if success:
            working_key = key
            print(f"Key #{i} is valid and working!")
    
    print("\n" + "="*50)
    print("RESULTS SUMMARY")
    print("="*50)
    
    if working_key:
        print(f"Found working DeepSeek API key: {working_key[:5]}...{working_key[-4:]}")
        print("You should use this key in the rfp_response_generator_pg.py file.")
    else:
        print("No working DeepSeek API keys found.")