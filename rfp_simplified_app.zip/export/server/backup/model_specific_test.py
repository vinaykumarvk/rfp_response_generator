#!/usr/bin/env python3
"""
Model-specific test script for the Express server.
This script tests different models (OpenAI, Anthropic, DeepSeek, MOA) and returns JSON output.
"""

import sys
import json
import time
from rfp_response_generator_pg import prompt_gpt, create_rfp_prompt
from moa_final import generate_moa_response

def test_specific_model(provider, requirement_text):
    """
    Test a specific AI model with a requirement text.
    
    Args:
        provider: Model provider name ('openai', 'anthropic', 'deepseek', or 'moa')
        requirement_text: The requirement text to generate a response for
        
    Returns:
        JSON-serializable dict with results
    """
    start_time = time.time()
    
    try:
        provider = provider.lower()
        
        # Check if we're using the MOA approach
        if provider == "moa":
            # Run the MOA implementation
            result = generate_moa_response(requirement_text)
            
            if result["status"] != "success":
                return {
                    "success": False,
                    "error": result.get("message", "Unknown error in MOA process")
                }
            
            # Extract responses from the result
            output = {
                "success": True,
                "provider": "moa",
                "generated_response": result["final_response"],
                "moa_response": result["final_response"],
                "openai_response": result["model_responses"]["openai_response"],
                "anthropic_response": result["model_responses"]["anthropic_response"],
                "deepseek_response": result["model_responses"]["deepseek_response"],
                "processing_time": time.time() - start_time,
                "metrics": result["metrics"]
            }
            
            return output
            
        # For individual models (OpenAI, Anthropic, DeepSeek)
        elif provider in ["openai", "anthropic", "deepseek"]:
            # Map our provider names to rfp_response_generator's format
            if provider == "openai":
                model_name = "openAI"
            elif provider == "anthropic":
                model_name = "anthropic"
            elif provider == "deepseek":
                model_name = "deepseek"
            else:
                return {
                    "success": False,
                    "error": f"Unknown provider: {provider}"
                }
            
            # Create prompt with category and empty previous_responses
            prompt = create_rfp_prompt(requirement_text, "Wealth Management Software", "")
            
            # Call the model
            response = prompt_gpt(prompt, llm=model_name)
            
            if response.startswith("Error:"):
                return {
                    "success": False,
                    "error": response
                }
            
            # Return successful response
            result = {
                "success": True,
                "provider": provider,
                "generated_response": response,
                "processing_time": time.time() - start_time
            }
            
            # Add provider-specific response field
            if provider == "openai":
                result["openai_response"] = response
            elif provider == "anthropic":
                result["anthropic_response"] = response
            elif provider == "deepseek":
                result["deepseek_response"] = response
                
            return result
        
        else:
            return {
                "success": False,
                "error": f"Unsupported provider: {provider}. Use 'openai', 'anthropic', 'deepseek', or 'moa'."
            }
            
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "traceback": str(sys.exc_info())
        }

if __name__ == "__main__":
    # Get command line arguments
    if len(sys.argv) < 3:
        print(json.dumps({
            "success": False,
            "error": "Usage: python model_specific_test.py <provider> <requirement_text>"
        }))
        sys.exit(1)
    
    provider = sys.argv[1]
    requirement_text = sys.argv[2]
    
    # Run the test and output JSON result
    result = test_specific_model(provider, requirement_text)
    print(json.dumps(result))