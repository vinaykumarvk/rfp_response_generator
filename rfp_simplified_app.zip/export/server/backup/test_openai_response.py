#!/usr/bin/env python3
"""
Test script to generate a response to a sample RFP requirement using OpenAI
"""

import sys
from rfp_response_generator_pg import create_rfp_prompt, prompt_gpt

def test_openai_response():
    """Test OpenAI with a sample requirement and show prompt and response"""
    print("\n" + "="*80)
    print("TESTING WITH OPENAI - DETAILED OUTPUT")
    print("="*80)
    
    # Sample RFP requirement
    sample_requirement = "Describe your platform's document management capabilities and how they support compliance requirements in wealth management."
    
    # Sample previous responses for context (abbreviated)
    previous_responses = """
Response 1 [Similarity Score: 0.95]:
Requirement: Explain how your system handles document storage and retrieval for regulatory purposes.
Response: Our wealth management platform features a comprehensive document management system with advanced storage, indexing, and retrieval capabilities. Documents are stored in a secure, encrypted repository with hierarchical organization by client, account, and document type. The system maintains version control and complete audit trails of all document access and modifications.
"""
    
    # Create the structured prompt for the requirement
    structured_prompt = create_rfp_prompt(sample_requirement, "Wealth Management Software", previous_responses)
    
    # Print the prompt structure
    print("\nPROMPT STRUCTURE:")
    print(f"Number of messages: {len(structured_prompt)}")
    
    for i, msg in enumerate(structured_prompt):
        print(f"\nMessage {i+1} [Role: {msg['role']}]")
        print("Content start:")
        print("-"*40)
        print(msg['content'][:300] + "..." if len(msg['content']) > 300 else msg['content'])
        print("-"*40)
    
    # Send the prompt to OpenAI
    print("\nSending prompt to OpenAI...")
    
    try:
        response = prompt_gpt(structured_prompt, llm='openAI')
        
        print("\nRESPONSE FROM OPENAI:")
        print("-"*80)
        print(response)
        print("-"*80)
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
    
if __name__ == "__main__":
    test_openai_response()