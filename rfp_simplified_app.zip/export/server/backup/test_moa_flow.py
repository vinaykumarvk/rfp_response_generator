#!/usr/bin/env python3
"""
Test script for the complete MOA (Mixture of Agents) pipeline
Tests generating responses from all three models and synthesizing them
"""

import os
import sys
import json
import time
from rfp_response_generator_pg import prompt_gpt

def create_synthesized_response_prompt(requirement: str, responses: dict):
    """
    Generate a prompt to synthesize multiple RFP responses into a cohesive, impactful response.

    Args:
        requirement: The specific RFP requirement to address.
        responses: Dictionary with model responses.

    Returns:
        List of messages for the LLM.
    """
    system_message = """You are an expert AI Synthesizer specialized in creating optimal RFP (Request for Proposal) responses.
Your task is to analyze multiple AI-generated responses to the same RFP requirement, critically evaluate the strengths and weaknesses of each,
and then synthesize them into a single, cohesive, high-quality response.

Focus on:
1. Extracting the most accurate, relevant, and specific content from each response
2. Ensuring technical accuracy and domain-appropriate terminology
3. Maintaining a professional, confident tone
4. Creating a coherent flow with proper transitions
5. Providing specific details rather than generic statements
6. Addressing all aspects of the requirement comprehensively
7. Structuring the response in clear, readable paragraphs

The final response should demonstrate deep expertise in the relevant domain, directly address the requirement,
and be optimized for persuasiveness and clarity."""

    openai_response = responses.get("openai", "No response available from OpenAI model.")
    anthropic_response = responses.get("anthropic", "No response available from Anthropic model.")
    deepseek_response = responses.get("deepseek", "No response available from DeepSeek model.")

    user_message = f"""I need you to synthesize the best possible RFP response by analyzing and combining elements from these three AI-generated responses to the following requirement:

REQUIREMENT: {requirement}

RESPONSE FROM MODEL 1:
{openai_response}

RESPONSE FROM MODEL 2:
{anthropic_response}

RESPONSE FROM MODEL 3:
{deepseek_response}

First, briefly analyze the strengths and weaknesses of each response. Then, create a single synthesized response that incorporates the best elements from all three, addresses any gaps or inaccuracies, and forms a comprehensive answer to the requirement. The synthesized response should stand alone as a complete, professional RFP response."""

    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

def test_moa_pipeline():
    """Test the complete MOA pipeline with a sample requirement."""
    print("\n" + "="*80)
    print("TESTING COMPLETE MOA (MIXTURE OF AGENTS) PIPELINE")
    print("="*80)
    
    # Sample RFP requirement for testing
    requirement = "Describe your system's approach to multi-factor authentication and how it enhances security for wealth management applications."
    
    # Store individual model responses
    model_responses = {}
    
    # Test prompt for all models
    test_prompt = [
        {"role": "system", "content": "You are an expert in wealth management and financial technology solutions, specializing in crafting precise, professional responses to RFP requirements."},
        {"role": "user", "content": f"Please generate a detailed, professional response to the following RFP requirement:\n\n{requirement}\n\nEnsure the response demonstrates deep understanding of wealth management products and services, is specific and detailed, and has a professional, authoritative tone."}
    ]
    
    print(f"\nRFP Requirement: {requirement}")
    print("-"*80)
    
    # Phase 1: Get responses from each individual model
    print("\n--- PHASE 1: INDIVIDUAL MODEL RESPONSES ---")
    
    models = ["openAI", "anthropic", "deepseek"]
    for model in models:
        print(f"\nGenerating response from {model}...")
        
        try:
            start_time = time.time()
            response = prompt_gpt(test_prompt, llm=model)
            elapsed_time = time.time() - start_time
            
            if response.startswith("Error"):
                print(f"❌ ERROR with {model}: {response}")
                model_responses[model.lower()] = f"Error: Failed to get response from {model}"
            else:
                print(f"✅ SUCCESS - Response received in {elapsed_time:.2f}s")
                print(f"First 100 chars: {response[:100]}...")
                model_responses[model.lower()] = response
                
        except Exception as e:
            print(f"❌ EXCEPTION with {model}: {str(e)}")
            model_responses[model.lower()] = f"Error: Exception occurred - {str(e)}"
    
    # Check if we have enough valid responses to proceed
    valid_responses = sum(1 for resp in model_responses.values() if not resp.startswith("Error"))
    
    if valid_responses < 2:
        print("\n❌ FAILED: Not enough valid model responses to proceed with synthesis")
        return False
    
    # Phase 2: Synthesize the responses using OpenAI
    print("\n--- PHASE 2: SYNTHESIZING RESPONSES ---")
    
    try:
        # Create synthesis prompt
        synthesis_prompt = create_synthesized_response_prompt(requirement, {
            "openai": model_responses.get("openai", "No response available"),
            "anthropic": model_responses.get("anthropic", "No response available"),
            "deepseek": model_responses.get("deepseek", "No response available")
        })
        
        # Generate synthesized response using OpenAI
        print("\nSynthesizing responses using OpenAI...")
        start_time = time.time()
        synthesized_response = prompt_gpt(synthesis_prompt, llm='openAI')
        elapsed_time = time.time() - start_time
        
        if synthesized_response.startswith("Error"):
            print(f"❌ SYNTHESIS FAILED: {synthesized_response}")
            return False
        
        print(f"✅ SYNTHESIS COMPLETED in {elapsed_time:.2f}s")
        print("\nFinal Synthesized Response:")
        print("-"*80)
        print(synthesized_response)
        print("-"*80)
        
        # Test successful
        print("\n✅ MOA PIPELINE TEST SUCCESSFUL")
        return True
        
    except Exception as e:
        print(f"\n❌ SYNTHESIS EXCEPTION: {str(e)}")
        return False
        
if __name__ == "__main__":
    test_moa_pipeline()