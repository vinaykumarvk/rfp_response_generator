#!/usr/bin/env python3
"""
Focused test script for PostgreSQL vector search without making actual API calls.
This script tests the vector similarity search and prompt creation while avoiding timeouts.
"""
import os
import sys
import json
import time
from datetime import datetime
import psycopg2
import numpy as np

# Constants
DEFAULT_TEST_QUERY = "Describe your system's capabilities for multi-factor authentication"
MAX_EXAMPLES = 3
VERBOSE = True

def get_database_connection():
    """Get a connection to the PostgreSQL database."""
    try:
        # Get connection string from environment variable
        db_url = os.environ.get('DATABASE_URL')
        if not db_url:
            sys.stderr.write("DATABASE_URL environment variable not set\n")
            sys.exit(1)
        
        # Connect to the database
        conn = psycopg2.connect(db_url)
        if VERBOSE:
            print("Successfully connected to PostgreSQL database")
        return conn
    except Exception as e:
        sys.stderr.write(f"Error connecting to database: {str(e)}\n")
        sys.exit(1)

def normalize_vector(vector):
    """Normalize a vector to unit length."""
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm

def get_random_embedding():
    """Generate a random embedding for testing (simulating OpenAI embedding)."""
    # Generate a random vector of 1536 dimensions
    random_vector = np.random.randn(1536)
    # Normalize the vector
    normalized_vector = normalize_vector(random_vector)
    if VERBOSE:
        print("Generated random normalized vector for testing")
    return normalized_vector.tolist()

def find_similar_requirements_db(query_embedding, k=5, similarity_threshold=0.01):
    """
    Find similar requirements in PostgreSQL database using vector similarity search.
    
    Args:
        query_embedding: The embedding vector to search for
        k: Number of results to return
        similarity_threshold: Minimum similarity score (0-1)
        
    Returns:
        List of dictionary objects with similar requirements
    """
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Convert embedding to string format for PostgreSQL
        vector_str = f"[{','.join(str(x) for x in query_embedding)}]"
        
        # Execute vector search using cosine similarity
        if VERBOSE:
            print(f"Searching with similarity threshold: {similarity_threshold}")
        
        cursor.execute("""
        SELECT 
            id, category, requirement, response, reference, 
            embedding <=> %s::vector AS similarity
        FROM 
            embeddings
        WHERE 
            embedding <=> %s::vector <= 2.0
        ORDER BY 
            similarity ASC
        LIMIT %s;
        """, (vector_str, vector_str, k))
        
        results = cursor.fetchall()
        if VERBOSE:
            print(f"Query returned {len(results)} results")
        
        if not results:
            print("No similar requirements found")
            return []
        
        # Calculate actual similarity (1 - distance) for better interpretability
        # PostgreSQL returns distance, not similarity
        top_similarity = 1 - results[0][5]
        lowest_similarity = 1 - results[-1][5]
        
        if VERBOSE:
            print(f"Top similarity score: {top_similarity}")
            print(f"Lowest similarity score: {lowest_similarity}")
        
        # Convert to list of dictionaries
        similar_requirements = []
        for row in results:
            id, category, requirement, response, reference, distance = row
            similarity = 1 - distance  # Convert distance to similarity
            
            # Only include results above the similarity threshold
            if similarity >= similarity_threshold:
                similar_requirements.append({
                    'id': id,
                    'category': category,
                    'requirement': requirement,
                    'response': response,
                    'reference': reference,
                    'similarity': similarity
                })
        
        if VERBOSE:
            print(f"Returning {len(similar_requirements)} results")
        
        cursor.close()
        conn.close()
        return similar_requirements
    
    except Exception as e:
        sys.stderr.write(f"Error in vector search: {str(e)}\n")
        sys.exit(1)

def create_rfp_prompt(new_question, category, previous_responses):
    """
    Create an optimized prompt for RFP response generation.

    Args:
        new_question: The current RFP requirement to address.
        category: Functional category of the requirement.
        previous_responses: List of previous responses with their similarity scores.
    """
    system_message = """You are an expert RFP response assistant. Your task is to generate a comprehensive response to the following requirement:"""
    
    # Build examples section
    examples_text = ""
    if previous_responses:
        examples_text = "\n\nHere are some examples of similar requirements and their responses that you can use as reference:\n\n"
        
        for i, resp in enumerate(previous_responses, 1):
            req = resp.get('requirement', '')
            response = resp.get('response', '')
            similarity = resp.get('similarity', 0)
            
            if req and response:
                examples_text += f"\nExample {i}:\n- Requirement: {req}\n- Response: {response}\n"
                if VERBOSE:
                    print(f"Example {i}: similarity={similarity:.3f}")
    
    # Build guideline section
    guideline_text = """\n
Guidelines for your response:
1. Be comprehensive and detailed, addressing all aspects of the requirement.
2. Use a structured format with clear headings.
3. Highlight any unique or innovative features.
4. Be factual and avoid exaggerated claims.
5. Keep the language professional but accessible.
6. Focus on benefits and value, not just features.
"""
    
    # Combine all parts into the final prompt
    prompt = f"{system_message}\n\nRequirement: {new_question}{examples_text}{guideline_text}"
    
    if VERBOSE:
        print("\n===== PROMPT PREVIEW =====")
        print(prompt[:500] + "..." if len(prompt) > 500 else prompt)
        print("=====  END PROMPT PREVIEW =====\n")
    
    return prompt

def simulate_openai_response(prompt):
    """Simulate a response from OpenAI to avoid timeouts."""
    # Return a simulated response
    print("Simulating OpenAI response generation (no actual API call)")
    
    # Return a generic acknowledgment that we would generate a response here
    simulated_response = "This is a simulated response. In the actual application, this would be replaced by a real response from OpenAI."
    
    return simulated_response

def test_search_with_keywords(keywords):
    """Test the vector search using text search with specific keywords."""
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        
        # Use a direct text search to find requirements
        search_term = f"%{keywords}%"
        
        cursor.execute("""
        SELECT 
            id, category, requirement, response, reference
        FROM 
            embeddings
        WHERE 
            requirement ILIKE %s
        LIMIT 3;
        """, (search_term,))
        
        results = cursor.fetchall()
        print(f"\n--- Testing text search for '{keywords}' ---")
        
        if not results:
            print(f"No requirements found matching '{keywords}'")
            return
        
        print(f"Found {len(results)} requirements matching '{keywords}':")
        for i, row in enumerate(results, 1):
            id, category, requirement, response, reference = row
            print(f"{i}. {requirement[:50]}...")
            if reference:
                print(f"   Reference: {reference[:50]}...")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        sys.stderr.write(f"Error in text search: {str(e)}\n")

def process_requirement(query_text):
    """Process a requirement and demonstrate the search + prompt creation flow."""
    start_time = time.time()
    
    # For testing, we'll use a random embedding instead of calling OpenAI
    query_embedding = get_random_embedding()
    
    # Find similar requirements
    similar_requirements = find_similar_requirements_db(
        query_embedding,
        k=MAX_EXAMPLES,
        similarity_threshold=0.01
    )
    
    # Print similar requirements
    if VERBOSE:
        print("\nSimilar requirements found:")
        for i, req in enumerate(similar_requirements, 1):
            print(f"{i}. {req['requirement'][:50]}... (similarity: {req['similarity']:.3f})")
    
    # Determine category (use most common category from similar requirements)
    category = None
    if similar_requirements:
        categories = {}
        for req in similar_requirements:
            cat = req.get('category')
            if cat:
                categories[cat] = categories.get(cat, 0) + 1
        
        if categories:
            category = max(categories.items(), key=lambda x: x[1])[0]
    
    # Create prompt
    prompt = create_rfp_prompt(query_text, category, similar_requirements)
    
    # Simulate response generation
    simulated_response = simulate_openai_response(prompt)
    
    # Calculate total time
    end_time = time.time()
    total_time = end_time - start_time
    
    if VERBOSE:
        print(f"\nTotal processing time: {total_time:.2f} seconds")
    
    return {
        'query': query_text,
        'category': category,
        'similar_count': len(similar_requirements),
        'prompt_length': len(prompt),
        'processing_time': total_time
    }

def main(query_text=None):
    """Run the test."""
    print("=" * 60)
    print(f"PostgreSQL Vector Search Test")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("=" * 60)
    
    # Use the provided query or the default
    if not query_text:
        query_text = DEFAULT_TEST_QUERY
    
    print(f"\nProcessing requirement: {query_text}\n")
    
    # First, try a direct text search for key terms
    keywords = query_text.split()[:2]  # Use first two words as keywords
    test_search_with_keywords(' '.join(keywords))
    
    # Process the requirement with vector search
    result = process_requirement(query_text)
    
    # Print the summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print(f"Query: {result['query']}")
    print(f"Determined Category: {result['category']}")
    print(f"Similar Requirements Found: {result['similar_count']}")
    print(f"Generated Prompt Length: {result['prompt_length']} characters")
    print(f"Total Processing Time: {result['processing_time']:.2f} seconds")
    print("=" * 60)
    
    print("\nTest completed successfully!")

if __name__ == "__main__":
    # Accept a query from command line arguments if provided
    query = None
    if len(sys.argv) > 1:
        query = sys.argv[1]
    
    main(query)