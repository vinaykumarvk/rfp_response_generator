#!/usr/bin/env python3
"""
Test script for vector search functionality
This script tests the vector_search.py module to ensure it can find similar requirements
"""

import sys
from vector_search import find_similar_requirements

def test_vector_search():
    """Test the vector search functionality with various queries."""
    test_queries = [
        "Describe your platform's document management capabilities",
        "What security features does your system provide for data protection?",
        "How does your system handle reporting and analytics?",
        "Explain your portfolio management capabilities",
        "What integration options do you offer with third-party systems?"
    ]
    
    success = True
    for query in test_queries:
        print(f"\n===== Testing query: {query} =====")
        
        try:
            # Find similar requirements
            results = find_similar_requirements(
                query_text=query,
                k=3,  # Only return top 3 matches
                similarity_threshold=0.3
            )
            
            # Print results
            if results:
                print(f"Found {len(results)} similar requirements:")
                for i, result in enumerate(results, 1):
                    print(f"\n-- Result {i} --")
                    print(f"Category: {result.get('category', 'N/A')}")
                    print(f"Similarity: {result.get('similarity', 0):.4f}")
                    print(f"Requirement: {result.get('requirement', 'N/A')[:100]}...")
                    
                    if result.get('response'):
                        print(f"Response: {result.get('response', '')[:100]}...")
                    else:
                        print("No response available")
            else:
                print("No similar requirements found")
                success = False
                
        except Exception as e:
            print(f"Error testing vector search: {e}")
            success = False
    
    return success

if __name__ == "__main__":
    print("Testing vector search functionality...")
    success = test_vector_search()
    
    if success:
        print("\nVector search test completed successfully!")
        sys.exit(0)
    else:
        print("\nVector search test failed!")
        sys.exit(1)