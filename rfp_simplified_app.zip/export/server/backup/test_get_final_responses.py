#!/usr/bin/env python3
"""
Test script for get_final_responses function
This tests the adapted version of the original function from the RFP Response Generator
"""

import os
import sys
import json
import time
from typing import Dict, List, Any, Optional
from openai import OpenAI
from anthropic import Anthropic

# Global constants
llm_set = ['openai', 'anthropic', 'deepseek']  # Note: using lowercase model names

def apply_mask(response: str, mask_list: Dict[str, str]) -> str:
    """Mask proprietary terms in text"""
    if not mask_list or not response:
        return response
    
    # Apply each mask
    masked_response = response
    for original, mask in mask_list.items():
        masked_response = masked_response.replace(original, mask)
    
    return masked_response

def apply_unmask(response: str, mask_list: Dict[str, str]) -> str:
    """Unmask proprietary terms in text"""
    if not mask_list or not response:
        return response
    
    # Apply each unmask (reverse the mask_list)
    unmasked_response = response
    for original, mask in mask_list.items():
        unmasked_response = unmasked_response.replace(mask, original)
    
    return unmasked_response

def create_rfp_prompt(requirement_text: str, category: str = "Wealth Management Software", previous_responses: str = "") -> List[Dict[str, str]]:
    """
    Create an optimized prompt for RFP response generation.
    
    Args:
        requirement_text: The RFP requirement to address
        category: Functional category of the requirement
        previous_responses: Previous responses with similarity scores
        
    Returns:
        Dict with prompt messages
    """
    system_message = {
        "role": "system",
        "content": f"""You are a senior RFP specialist at a leading financial technology company with expertise in {category}.
Your task is to draft a professional, concise RFP response that:
1. Is under 200 words
2. Has a neutral, professional tone
3. Provides specific, factual information without vague claims
4. Clearly differentiates your solution from competitors
5. Mentions capabilities your platform actually has

Format: Directly address the requirement with relevant facts, features, and benefits.
Avoid: Introductory phrases like "Our solution provides...", meta-language, and excessive claims.
"""
    }
    
    # Process previous responses if provided
    similar_content = ""
    if previous_responses:
        try:
            similar_items = json.loads(previous_responses)
            if similar_items and len(similar_items) > 0:
                similar_content = "**Similar Requirements and Responses**:\n\n"
                for i, item in enumerate(similar_items, 1):
                    req = item.get('requirement', '')
                    resp = item.get('response', '')
                    similarity = item.get('similarity', 0)
                    if req and resp:
                        similar_content += f"SIMILAR REQUIREMENT {i} (Score: {similarity:.2f}):\n"
                        similar_content += f"Question: {req}\n"
                        similar_content += f"Response: {resp}\n\n"
        except Exception as e:
            sys.stderr.write(f"Error processing previous responses: {str(e)}\n")
            similar_content = f"Original previous responses: {previous_responses}\n"
    
    user_message = {
        "role": "user",
        "content": f"""Please provide a comprehensive response to this RFP requirement:

**REQUIREMENT**: {requirement_text}

{similar_content}

**Instructions**:
1. Analyze any similar requirements and responses, prioritizing those with higher scores for relevance.
2. Draft a response that meets all guidelines and rules outlined in the system message.
3. Be specific and detailed, addressing exactly what the requirement is asking for.
4. Include concrete technical capabilities and features.
5. Be formatted professionally and concisely.
6. Avoid generic marketing language.
7. Do not exceed 250 words.
"""
    }
    
    return [system_message, user_message]

def create_synthesized_response_prompt(requirement: str, responses: List[str]) -> List[Dict[str, str]]:
    """
    Generate a prompt to synthesize multiple RFP responses.
    
    Args:
        requirement: The RFP requirement to address
        responses: List of individual responses to evaluate and synthesize
        
    Returns:
        Dict with prompt messages
    """
    system_message = {
        "role": "system",
        "content": f"""You are a senior RFP specialist at a leading financial technology company with 15+ years of experience in winning complex RFPs in the wealth management domain.

OBJECTIVE:
Synthesize multiple response versions into one optimal response that directly addresses the requirement: {requirement}

EVALUATION CRITERIA:
1. **Relevance & Impact**:
   - Direct alignment with the requirement.
   - Clear and compelling value proposition.
2. **Precision & Clarity**:
   - Clear, specific technical details without vagueness.
   - Free of redundancy or padding.
3. **Professionalism**:
   - Business-appropriate tone.
   - No marketing language, platitudes, or excessive claims.
4. **Differentiation**:
   - Highlights unique capabilities and competitive advantages.

OUTPUT FORMAT:
- Maximum 200 words.
- No introductory phrases like "Our solution provides..." 
- Begin directly with the most relevant capabilities.
- Paragraphs should be logical and focused on distinct points.
- Include specific metrics/examples where available.
"""
    }
    
    # Format individual responses for the user message
    formatted_responses = ""
    for i, response in enumerate(responses, 1):
        formatted_responses += f"RESPONSE {i}:\n{response}\n\n"
    
    user_message = {
        "role": "user",
        "content": f"""I need to provide an optimal response to the following RFP requirement:

REQUIREMENT: {requirement}

Here are different response versions to synthesize:

{formatted_responses}

Create one unified response that:
1. Takes the best elements from each response
2. Resolves any contradictions between them
3. Emphasizes our strongest capabilities relevant to the requirement
4. Excludes any weak, vague, or overly promotional content
5. Provides a coherent, direct, and powerful answer limited to 200 words

The final response should appear as though it was drafted by a single expert, not a combination of different inputs.
"""
    }
    
    return [system_message, user_message]

def prompt_gpt(prompt: List[Dict[str, str]], llm: str = 'openai') -> str:
    """
    Send a prompt to the specified LLM and get a response.
    
    Args:
        prompt: The prompt to send (list of message dicts)
        llm: The LLM to use: 'openai', 'anthropic', or 'deepseek'
        
    Returns:
        The response text
    """
    llm = llm.lower()  # Normalize to lowercase
    
    try:
        if llm == 'openai':
            # The newest OpenAI model is "gpt-4o" which was released May 13, 2024
            client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=prompt,
                temperature=0.7,
            )
            return response.choices[0].message.content
            
        elif llm == 'anthropic':
            # The newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
            client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
            
            # Extract system message and user messages
            system_content = None
            user_messages = []
            
            for msg in prompt:
                if msg["role"] == "system":
                    system_content = msg["content"]
                else:
                    user_messages.append(msg)
            
            # Create the API call with system parameter
            response = client.messages.create(
                model="claude-3-7-sonnet-20250219",
                max_tokens=1000,
                system=system_content,  # Pass system message separately
                messages=user_messages,  # Pass only user/assistant messages
                temperature=0.7,
            )
            return response.content[0].text
            
        elif llm == 'deepseek':
            # Since we don't have direct DeepSeek integration, return a placeholder error
            return "Error: DeepSeek API not integrated in test script"
            
        else:
            return f"Error: Unsupported model provider: {llm}"
            
    except Exception as e:
        return f"Error: {str(e)}"

def get_final_responses(requirement_text: str, category: str = "Wealth Management Software", previous_responses: str = ""):
    """
    Generate responses from multiple LLMs and synthesize them into a final response.
    Adapted from the original RFP Response Generator implementation.
    
    Args:
        requirement_text: The requirement to address
        category: The category of the requirement
        previous_responses: Previous similar responses for context
        
    Returns:
        Dict with the final response and individual model responses
    """
    # Use stderr for logs since stdout is reserved for JSON response
    sys.stderr.write(f"Processing requirement: {requirement_text}\n")
    sys.stderr.flush()
    start_time = time.time()
    
    # Create the initial prompt
    prompt = create_rfp_prompt(requirement_text, category, previous_responses)
    
    # Dict to store individual model responses
    model_responses = {}
    llm_responses = []  # List for synthesis
    
    # Get responses from each model
    for llm in llm_set:
        sys.stderr.write(f"Requesting response from {llm}...\n")
        sys.stderr.flush()
        model_start_time = time.time()
        
        try:
            response = prompt_gpt(prompt, llm)
            model_elapsed = time.time() - model_start_time
            
            if response.startswith("Error:"):
                sys.stderr.write(f"❌ {llm} error: {response}\n")
                sys.stderr.flush()
                model_responses[f"{llm}_response"] = f"Error: {response}"
            else:
                sys.stderr.write(f"✅ {llm} response received in {model_elapsed:.2f}s\n")
                sys.stderr.flush()
                model_responses[f"{llm}_response"] = response
                llm_responses.append(response)
                
        except Exception as e:
            model_elapsed = time.time() - model_start_time
            error_message = str(e)
            sys.stderr.write(f"❌ {llm} exception: {error_message}\n")
            sys.stderr.flush()
            model_responses[f"{llm}_response"] = f"Error: {error_message}"
    
    # Create synthesis prompt from successful responses
    if llm_responses:
        sys.stderr.write("Creating synthesis prompt...\n")
        sys.stderr.flush()
        synthesis_prompt = create_synthesized_response_prompt(requirement_text, llm_responses)
        
        # Generate final synthesized response using OpenAI
        sys.stderr.write("Generating final synthesized response...\n")
        sys.stderr.flush()
        final_response = prompt_gpt(synthesis_prompt, 'openai')
        
        if final_response.startswith("Error:"):
            sys.stderr.write(f"❌ Synthesis failed: {final_response}\n")
            sys.stderr.flush()
            # Fallback to first successful response
            for llm in llm_set:
                response_key = f"{llm}_response"
                if response_key in model_responses and not model_responses[response_key].startswith("Error:"):
                    final_response = model_responses[response_key]
                    sys.stderr.write(f"Using {llm} response as fallback\n")
                    sys.stderr.flush()
                    break
        else:
            sys.stderr.write("✅ Synthesis complete\n")
            sys.stderr.flush()
    else:
        final_response = "Failed to generate any model responses."
        sys.stderr.write("❌ No successful model responses to synthesize\n")
        sys.stderr.flush()
    
    # Store final response and metadata
    model_responses["moa_response"] = final_response
    total_time = time.time() - start_time
    
    sys.stderr.write(f"Processing completed in {total_time:.2f}s\n")
    sys.stderr.flush()
    
    return {
        "status": "success",
        "final_response": final_response,
        "model_responses": model_responses,
        "metrics": {
            "total_time": total_time,
            "models_succeeded": sum(1 for r in model_responses.values() if not str(r).startswith("Error:")),
            "models_attempted": len(llm_set)
        }
    }

# Test function
if __name__ == "__main__":
    # Sample requirement for testing
    test_requirement = "Describe your platform's document management capabilities and how they enhance advisor efficiency."
    
    # When running as main script, we can use stdout for output
    print(f"\n{'='*80}\nTESTING get_final_responses FUNCTION\n{'='*80}")
    print(f"\nRequirement: {test_requirement}")
    
    result = get_final_responses(test_requirement)
    
    print(f"\n{'='*80}\nFINAL RESPONSE\n{'='*80}")
    print(result["final_response"])
    
    print(f"\n{'='*80}\nPERFORMANCE METRICS\n{'='*80}")
    print(f"Total time: {result['metrics']['total_time']:.2f}s")
    print(f"Models succeeded: {result['metrics']['models_succeeded']} of {result['metrics']['models_attempted']}")
    
    # Save results to file
    with open("get_final_responses_test_results.json", "w") as f:
        json.dump({
            "requirement": test_requirement,
            "final_response": result["final_response"],
            "metrics": result["metrics"],
            "model_responses": result["model_responses"]
        }, f, indent=2)
    
    print(f"\nResults saved to get_final_responses_test_results.json")