#!/usr/bin/env python3
"""
Test script for the full flow - finding similar requirements and generating a response
This script tests whether the vector search results are correctly used in response generation
"""
import json
import sys

# Import the functions we need to test
from rfp_response_generator_pg import find_similar_requirements, generate_response_with_openai

def test_full_flow():
    """Test the full flow from finding similar requirements to generating a response"""
    # Sample requirement text
    sample_text = "Please describe your solution's security capabilities including multi-factor authentication and data encryption."
    
    print("=" * 50)
    print(f"Testing full flow with requirement: '{sample_text}'")
    print("=" * 50)
    
    # Step 1: Find similar requirements
    print("Step 1: Finding similar requirements...")
    similar_requirements = find_similar_requirements(sample_text, k=5)
    
    # Log the results
    print(f"Found {len(similar_requirements)} similar requirements")
    print("Similar requirements (first 2 shown):")
    for i, req in enumerate(similar_requirements[:2], 1):
        print(f"Requirement {i}:")
        print(f"  Category: {req.get('category', 'N/A')}")
        print(f"  Requirement: {req.get('requirement', 'N/A')[:100]}...")
        print(f"  Score: {req.get('score', 0)}")
        print()
    
    # Check if we have enough similar requirements
    if len(similar_requirements) < 2:
        print("WARNING: Not enough similar requirements found for a good response")
        return False
    
    # Step 2: Generate a response with OpenAI
    print("Step 2: Generating response based on similar requirements...")
    response_data = generate_response_with_openai(sample_text, similar_requirements)
    
    # Check if response generation was successful
    if 'error' in response_data:
        print(f"ERROR: Response generation failed: {response_data['error']}")
        return False
    
    # Log the generated response
    print("Response generated successfully!")
    print("Generated response (first 500 chars):")
    response_text = response_data.get('generated_response', '')
    print(response_text[:500] + "..." if len(response_text) > 500 else response_text)
    
    # Check response structure
    expected_fields = ['generated_response', 'similar_responses', 'openai_response']
    missing_fields = [field for field in expected_fields if field not in response_data]
    
    if missing_fields:
        print(f"WARNING: Response data missing expected fields: {', '.join(missing_fields)}")
        return False
    
    print("\nResponse data fields:")
    for key in response_data.keys():
        value = response_data[key]
        if isinstance(value, str):
            print(f"- {key}: String of length {len(value)}")
        elif isinstance(value, list):
            print(f"- {key}: List with {len(value)} items")
        else:
            print(f"- {key}: {type(value)}")
    
    return True

if __name__ == "__main__":
    # Run the test
    success = test_full_flow()
    
    # Print overall status
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    print(f"Full flow test: {'PASSED' if success else 'FAILED'}")
    
    # Set exit code based on success
    sys.exit(0 if success else 1)