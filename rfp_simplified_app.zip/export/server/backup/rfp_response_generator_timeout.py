#!/usr/bin/env python3
"""
Modified version of rfp_response_generator_pg.py with consistent 3-minute timeouts for all models
"""

import os
import sys
import json
import signal
from typing import List, Dict, Optional, Any, Union

def prompt_gpt(prompt, llm='openAI'):
    """
    Call a language model API with a prompt.
    
    Args:
        prompt: List of message dictionaries for OpenAI-style APIs, or converted format for Claude
        llm: The LLM provider to use ('openAI', 'anthropic', or 'deepseek')
        
    Returns:
        The generated text response
    """
    # Standardized 3-minute timeout for all models
    TIMEOUT_SECONDS = 180  # 3 minutes
    
    # Define a timeout handler for all models
    class TimeoutException(Exception):
        pass
            
    def timeout_handler(signum, frame):
        raise TimeoutException(f"{llm} API call timed out after {TIMEOUT_SECONDS} seconds")
    
    # Set up the timeout alarm
    original_handler = signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(TIMEOUT_SECONDS)  # 3 minutes in seconds
    
    try:
        if llm == 'openAI':
            # Hardcoded OpenAI API key for reliable deployment
            openai_api_key = "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"
            
            import openai
            client = openai.OpenAI(
                api_key=openai_api_key,
                timeout=(TIMEOUT_SECONDS - 5)  # Just under our alarm timeout
            )
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=prompt,
                temperature=0.7
            )
            result = response.choices[0].message.content.strip()

        elif llm == 'deepseek':
            # Hardcoded DeepSeek API key for reliable deployment
            deepseek_api_key = "sk-831e97c2650c43c9b1336c48595e0941"  # Updated to working key
            
            import openai
            
            # Create client with a generous timeout
            client = openai.OpenAI(
                api_key=deepseek_api_key,
                base_url="https://api.deepseek.com/v1",
                timeout=(TIMEOUT_SECONDS - 5)  # Just under our alarm timeout
            )
            
            # Make the API call
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=prompt,
                temperature=0.7,
                max_tokens=800  # Allow for longer responses but still limit
            )
            
            result = response.choices[0].message.content.strip()

        elif llm == 'anthropic':
            # Hardcoded Anthropic API key for reliable deployment
            anthropic_api_key = "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"
            
            import anthropic
            client = anthropic.Anthropic(
                api_key=anthropic_api_key,
                # Note: Anthropic client doesn't seem to support timeout parameter directly
                # but the SIGALRM will still enforce the timeout
            )
            
            # Handle the different format for Claude messages
            claude_formatted = convert_promt_to_claude(prompt)
            
            # the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
            response = client.messages.create(
                model="claude-3-7-sonnet-20250219",
                max_tokens=1000,
                temperature=0.7,
                messages=claude_formatted["messages"],
                system=claude_formatted["system"]
            )
            result = extract_text(response)
            
        else:
            # Cancel the alarm before returning
            signal.alarm(0)
            return f"Error: Unsupported LLM provider '{llm}'"
        
        # If we get here, the call was successful
        signal.alarm(0)  # Cancel the alarm
        return result
            
    except TimeoutException as e:
        # If we hit the timeout, log and return an error
        sys.stderr.write(f"{llm} API timeout: {str(e)}\n")
        return f"Error: {llm} API timed out after 3 minutes. Skipping this model."
        
    except Exception as e:
        # For any other exception
        sys.stderr.write(f"Error in {llm} API call: {str(e)}\n")
        return f"Error calling {llm} API: {str(e)}"
        
    finally:
        # Always restore the original signal handler and cancel any pending alarm
        signal.alarm(0)
        signal.signal(signal.SIGALRM, original_handler)

# Import the convert_promt_to_claude and extract_text functions to be used
def convert_promt_to_claude(prompt):
    """
    Convert a prompt formatted for OpenAI to one compatible with Claude.
    
    Args:
        prompt: List of message dictionaries formatted for OpenAI
        
    Returns:
        Dict with 'messages' (list of message dictionaries) and 'system' (system message)
    """
    # Initialize result structure
    result = {
        "messages": [],
        "system": ""
    }
    
    # Extract system message if present
    for message in prompt:
        if message["role"] == "system":
            result["system"] = message["content"]
        elif message["role"] == "user" or message["role"] == "assistant":
            # Map 'user' to 'user' and 'assistant' to 'assistant'
            result["messages"].append({
                "role": message["role"],
                "content": message["content"]
            })
    
    return result

def extract_text(response):
    """
    Extract clean text from Claude's response.

    Args:
        response: Response from Claude API

    Returns:
        str: Clean text content
    """
    # Handle different versions of the Claude API response format
    if hasattr(response, 'content') and isinstance(response.content, list):
        # Newer Claude API format
        for content_block in response.content:
            if hasattr(content_block, 'text') and content_block.text:
                return content_block.text
            if isinstance(content_block, dict) and 'text' in content_block:
                return content_block['text']
    
    # Fallback for string content or other formats
    if hasattr(response, 'content') and isinstance(response.content, str):
        return response.content
    
    # Last resort, try to convert the entire response to string
    try:
        return str(response)
    except Exception as e:
        return f"Failed to extract text from response: {str(e)}"

# Test the prompt_gpt function directly
if __name__ == "__main__":
    # Simple test for each model
    test_prompt = [
        {"role": "system", "content": "You are an expert in wealth management software."},
        {"role": "user", "content": "What are 3 key features of document management in wealth management platforms?"}
    ]
    
    for model in ["openAI", "anthropic", "deepseek"]:
        print(f"\n{'='*80}\nTESTING {model} WITH 3-MINUTE TIMEOUT\n{'='*80}")
        
        try:
            response = prompt_gpt(test_prompt, llm=model)
            print(f"\nRESPONSE FROM {model}:")
            print("-"*80)
            print(response)
            print("-"*80)
        except Exception as e:
            print(f"ERROR with {model}: {str(e)}")