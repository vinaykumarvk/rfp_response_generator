"""
Simple test script for generating model-specific responses.
This bypasses the real API calls for testing purposes.
"""

import sys
import json
import time
from datetime import datetime

def generate_test_response(provider="openai"):
    """Generate a test response with the appropriate fields set."""
    
    # Create timestamp for uniqueness
    timestamp = datetime.now().isoformat()
    
    # Base content
    base_content = f"""## Test Response for {provider.upper()}

This is a test response generated at {timestamp} to validate that model-specific fields are properly saved to the database.

### Features:
- Generated for testing only
- Provider: {provider}
- Timestamp: {timestamp}
- No actual API call was made

### Status:
This is NOT a real response from the AI model, just test data for debugging.
"""
    
    # Create response with appropriate fields based on provider
    if provider == "openai":
        return {
            "success": True,
            "provider": "openai",
            "openai_response": base_content,
            "generated_response": base_content
        }
    elif provider == "anthropic":
        return {
            "success": True,
            "provider": "anthropic",
            "anthropic_response": base_content,
            "generated_response": base_content
        }
    elif provider == "deepseek":
        return {
            "success": True,
            "provider": "deepseek",
            "deepseek_response": base_content,
            "generated_response": base_content
        }
    elif provider == "moa":
        # For MOA, create slightly different responses for each model
        openai_content = base_content + "\n\n**This is the OpenAI part of the MOA response.**"
        anthropic_content = base_content + "\n\n**This is the Anthropic part of the MOA response.**"
        moa_content = f"""## MOA Combined Response

### OpenAI Response:
{openai_content}

### Anthropic Response:
{anthropic_content}

---
*Generated using Mixture of Agents (MOA) approach combining multiple models*
"""
        return {
            "success": True,
            "provider": "moa",
            "openai_response": openai_content,
            "anthropic_response": anthropic_content,
            "moa_response": moa_content,
            "generated_response": moa_content
        }
    else:
        return {
            "success": False,
            "error": f"Unsupported provider: {provider}"
        }

if __name__ == "__main__":
    # Get provider from command line arguments
    provider = "openai"
    
    if len(sys.argv) > 1:
        provider = sys.argv[1]
    
    # Generate response and print as JSON
    result = generate_test_response(provider)
    print(json.dumps(result, indent=2))