#!/usr/bin/env python3
"""
Test script for MOA route handler using a minimal example
"""

import json
import requests
import time

def test_moa_route():
    """Test the MOA route handler with a specific simple requirement"""
    
    print("\n=== TESTING MOA ROUTE HANDLER ===")
    
    # Define the endpoint URL (assuming running on localhost port 5000)
    url = "http://localhost:5000/api/simple-model-test"
    
    # Use a simple requirement for faster testing
    requirement = "List 3 document management features. Keep it brief."
    
    # Data payload with the MOA provider
    payload = {
        "provider": "moa",
        "requirementId": 59  # Using the test requirement ID we just created
    }
    
    print(f"\nSending request to {url}...")
    print(f"Requirement: {requirement}")
    
    # Record start time for timing
    start_time = time.time()
    
    try:
        # Send the request
        response = requests.post(url, json=payload, timeout=120)  # 2-minute timeout
        
        # Calculate elapsed time
        elapsed_time = time.time() - start_time
        
        if response.status_code == 200:
            try:
                result = response.json()
                print(f"✅ Request succeeded in {elapsed_time:.2f}s")
                
                # Check response fields
                if "success" in result and result["success"]:
                    print(f"\nResponse fields present:")
                    for field in ["generated_response", "openai_response", "anthropic_response", 
                                 "deepseek_response", "moa_response", "metrics"]:
                        if field in result:
                            field_value = result[field]
                            if isinstance(field_value, str):
                                print(f"- {field}: {len(field_value)} chars")
                            else:
                                print(f"- {field}: present")
                        else:
                            print(f"- {field}: missing")
                    
                    # Print a snippet of the response
                    response_text = result.get("generated_response", "")
                    if response_text:
                        print(f"\nResponse snippet:")
                        print(f"{response_text[:200]}...")
                    
                    # Print metrics if available
                    if "metrics" in result:
                        metrics = result["metrics"]
                        print(f"\nMetrics:")
                        for key, value in metrics.items():
                            print(f"- {key}: {value}")
                else:
                    print(f"❌ Request returned success=false: {result.get('error', 'No error message')}")
            except ValueError:
                print(f"❌ Invalid JSON response")
                print(f"Response: {response.text[:200]}...")
        else:
            print(f"❌ Request failed with status code {response.status_code}")
            print(f"Response: {response.text[:200]}...")
    
    except requests.exceptions.Timeout:
        print(f"❌ Request timed out after {time.time() - start_time:.2f}s")
    except requests.exceptions.RequestException as e:
        print(f"❌ Request error: {str(e)}")
    
    print("\n=== MOA ROUTE HANDLER TEST COMPLETE ===")

if __name__ == "__main__":
    test_moa_route()