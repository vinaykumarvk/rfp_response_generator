#!/usr/bin/env python3
"""
Simplified test script for DeepSeek API with shorter prompt
"""

import sys
import time
import openai

def test_deepseek_simple():
    """Test DeepSeek API with a simpler prompt for faster response"""
    print("\n" + "="*80)
    print("TESTING DEEPSEEK WITH SIMPLIFIED PROMPT")
    print("="*80)
    
    # Hardcoded DeepSeek API key for reliable deployment
    deepseek_api_key = "sk-831e97c2650c43c9b1336c48595e0941"  # Updated to working key
    
    # Sample requirement (shorter)
    sample_requirement = "Describe document management features for wealth management platforms"
    
    # Simple prompt
    messages = [
        {"role": "system", "content": "You are an expert in wealth management software."},
        {"role": "user", "content": f"Briefly describe document management capabilities for wealth management in 100-150 words: {sample_requirement}"}
    ]
    
    print(f"\nPrompt: {messages[1]['content']}")
    print("\nSending to DeepSeek API...")
    
    try:
        start_time = time.time()
        
        client = openai.OpenAI(
            api_key=deepseek_api_key,
            base_url="https://api.deepseek.com/v1"
        )
        
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=messages,
            temperature=0.7,
            timeout=30  # 30 second timeout
        )
        
        elapsed_time = time.time() - start_time
        content = response.choices[0].message.content.strip()
        
        print(f"\nResponse received in {elapsed_time:.2f} seconds")
        print("\nRESPONSE FROM DEEPSEEK:")
        print("-"*80)
        print(content)
        print("-"*80)
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
    
if __name__ == "__main__":
    test_deepseek_simple()