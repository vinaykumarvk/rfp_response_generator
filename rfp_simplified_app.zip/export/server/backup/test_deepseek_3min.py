#!/usr/bin/env python3
"""
Test script specifically for testing DeepSeek with the 3-minute timeout
"""

import sys
import time
import signal
from rfp_response_generator_pg import prompt_gpt

# The 3-minute timeout we've implemented
TIMEOUT_SECONDS = 180

def test_deepseek_three_minute_timeout():
    """Test if DeepSeek responds within the 3-minute timeout"""
    print("\n" + "="*80)
    print("TESTING DEEPSEEK WITH 3-MINUTE TIMEOUT")
    print("="*80)
    
    # Very simple prompt to maximize chances of a quick response
    prompt = [
        {"role": "system", "content": "You are an expert in wealth management software."},
        {"role": "user", "content": "List 3 key document management features for wealth management platforms. Keep it brief."}
    ]
    
    print(f"\nPrompt: {prompt[1]['content']}")
    print("\nSending to DeepSeek API...")
    print(f"Timeout set to: {TIMEOUT_SECONDS} seconds")
    
    # Set up a manual timer to track elapsed time
    start_time = time.time()
    
    try:
        # Call DeepSeek with timeout handling built into prompt_gpt
        response = prompt_gpt(prompt, llm='deepseek')
        elapsed_time = time.time() - start_time
        
        print(f"\nOperation completed in {elapsed_time:.2f} seconds")
        
        if response.startswith("Error:"):
            print(f"\nDeepSeek API error: {response}")
            if "timeout" in response.lower():
                print("\nRESULT: DeepSeek timed out")
            else:
                print("\nRESULT: DeepSeek failed with error")
        else:
            print("\nRESULT: DeepSeek responded successfully within timeout")
            print("\nDEEPSEEK RESPONSE:")
            print("-"*80)
            print(response)
            print("-"*80)
            
    except Exception as e:
        elapsed_time = time.time() - start_time
        print(f"\nException after {elapsed_time:.2f} seconds: {str(e)}")
        print("\nRESULT: DeepSeek test failed with exception")

# Main execution
if __name__ == "__main__":
    test_deepseek_three_minute_timeout()