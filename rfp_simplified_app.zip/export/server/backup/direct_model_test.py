#!/usr/bin/env python3
"""
Direct model testing script for OpenAI, Anthropic, DeepSeek and MOA
This script allows testing models directly without database or API endpoint dependencies
"""

import sys
import json
import time
from moa_final import generate_moa_response

def test_openai(requirement_text):
    """Test OpenAI with a specific requirement"""
    from rfp_response_generator_pg import prompt_gpt
    
    # Create a simple test prompt
    prompt = [
        {"role": "system", "content": "You are an AI assistant for RFP responses."},
        {"role": "user", "content": f"Generate a brief response to this requirement: {requirement_text}"}
    ]
    
    # Get start time
    start_time = time.time()
    
    # Get response
    try:
        response = prompt_gpt(prompt, llm='openAI')
        elapsed_time = time.time() - start_time
        
        return {
            "success": True,
            "generated_response": response,
            "processing_time": elapsed_time
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def test_anthropic(requirement_text):
    """Test Anthropic with a specific requirement"""
    from rfp_response_generator_pg import prompt_gpt
    
    # Create a simple test prompt
    prompt = [
        {"role": "system", "content": "You are an AI assistant for RFP responses."},
        {"role": "user", "content": f"Generate a brief response to this requirement: {requirement_text}"}
    ]
    
    # Get start time
    start_time = time.time()
    
    # Get response
    try:
        response = prompt_gpt(prompt, llm='anthropic')
        elapsed_time = time.time() - start_time
        
        return {
            "success": True,
            "generated_response": response,
            "processing_time": elapsed_time
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def test_deepseek(requirement_text):
    """Test DeepSeek with a specific requirement"""
    from rfp_response_generator_pg import prompt_gpt
    
    # Create a simple test prompt
    prompt = [
        {"role": "system", "content": "You are an AI assistant for RFP responses."},
        {"role": "user", "content": f"Generate a brief response to this requirement: {requirement_text}"}
    ]
    
    # Get start time
    start_time = time.time()
    
    # Get response
    try:
        response = prompt_gpt(prompt, llm='deepseek')
        elapsed_time = time.time() - start_time
        
        return {
            "success": True,
            "generated_response": response,
            "processing_time": elapsed_time
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def test_moa(requirement_text):
    """Test MOA with a specific requirement"""
    # Get start time
    start_time = time.time()
    
    # Get response
    try:
        result = generate_moa_response(requirement_text)
        elapsed_time = time.time() - start_time
        
        if result["status"] == "success":
            return {
                "success": True,
                "generated_response": result["final_response"],
                "openai_response": result["model_responses"]["openai_response"],
                "anthropic_response": result["model_responses"]["anthropic_response"],
                "deepseek_response": result["model_responses"]["deepseek_response"],
                "moa_response": result["model_responses"]["moa_response"],
                "metrics": result["metrics"],
                "processing_time": elapsed_time
            }
        else:
            return {
                "success": False,
                "error": result.get("message", "Unknown error")
            }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def test_specific_model(provider, requirement_text):
    """Run a test for a specific model provider"""
    providers = {
        "openai": test_openai,
        "anthropic": test_anthropic,
        "deepseek": test_deepseek,
        "moa": test_moa
    }
    
    if provider not in providers:
        return {
            "success": False,
            "error": f"Invalid provider: {provider}. Must be one of: {', '.join(providers.keys())}"
        }
    
    return providers[provider](requirement_text)

def main():
    """Main function when script is run directly"""
    if len(sys.argv) < 3:
        print(json.dumps({
            "success": False,
            "error": "Usage: python direct_model_test.py <provider> <requirement_text>"
        }))
        sys.exit(1)
    
    provider = sys.argv[1]
    requirement_text = sys.argv[2]
    
    print(f"\n=== TESTING DIRECT MODEL ACCESS ===")
    print(f"Provider: {provider}")
    print(f"Requirement: {requirement_text}")
    
    result = test_specific_model(provider, requirement_text)
    
    if result["success"]:
        print(f"✅ Test successful")
        
        if "processing_time" in result:
            print(f"Processing time: {result['processing_time']:.2f}s")
            
        if "metrics" in result:
            metrics = result["metrics"]
            print(f"Models succeeded: {metrics.get('models_succeeded', 'N/A')} of {metrics.get('models_attempted', 'N/A')}")
            print(f"Total time: {metrics.get('total_time', 'N/A'):.2f}s")
        
        response = result.get("generated_response", "No response")
        if response:
            print(f"\nResponse snippet: {response[:150]}...")
    else:
        print(f"❌ Test failed: {result.get('error', 'Unknown error')}")
    
    print(f"\n=== DIRECT MODEL TEST COMPLETE ===")
    
    # Output JSON result for programmatic usage
    print(json.dumps(result))

if __name__ == "__main__":
    main()