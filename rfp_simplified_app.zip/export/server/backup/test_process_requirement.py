#!/usr/bin/env python3
"""
Direct test for process_requirement function from rfp_response_generator_pg.py
This script tests the function with different model providers including MOA
"""

import sys
import json
import time
import os

# Import the function directly
try:
    from rfp_response_generator_pg import process_requirement
except ImportError as e:
    print(json.dumps({
        "status": "error",
        "message": f"Could not import process_requirement: {str(e)}"
    }))
    sys.exit(1)

def test_process_requirement(requirement_text, model_provider="moa"):
    """
    Test the process_requirement function directly
    """
    start_time = time.time()
    
    try:
        # Call the function directly
        print(f"Processing requirement with {model_provider}...")
        response = process_requirement(requirement_text, model_provider=model_provider)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # Add execution time info
        if isinstance(response, dict):
            response["execution_time"] = execution_time
        else:
            response = {
                "status": "success",
                "raw_response": response,
                "execution_time": execution_time
            }
        
        # Return the response
        print(json.dumps(response, indent=2))
        return response
        
    except Exception as e:
        error_response = {
            "status": "error",
            "message": f"Error calling process_requirement: {str(e)}",
            "execution_time": time.time() - start_time
        }
        print(json.dumps(error_response, indent=2))
        return error_response

if __name__ == "__main__":
    # Get command line arguments
    if len(sys.argv) < 2:
        print("Usage: python test_process_requirement.py <requirement_text> [model_provider]")
        sys.exit(1)
    
    requirement_text = sys.argv[1]
    model_provider = "moa"  # Default to MOA
    
    if len(sys.argv) >= 3:
        model_provider = sys.argv[2]
    
    # Test with the specified model provider
    test_process_requirement(requirement_text, model_provider)