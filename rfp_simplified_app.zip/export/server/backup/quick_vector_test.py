#!/usr/bin/env python3
"""
Quick test for vector search functionality
This script tests the vector_search.py module with a single query
"""

import sys
from vector_search import find_similar_requirements

def test_vector_search_single_query():
    """Test the vector search functionality with a single query."""
    query = "Describe your platform's document management capabilities"
    
    print(f"\n===== Testing query: {query} =====")
    
    try:
        # Find similar requirements
        results = find_similar_requirements(
            query_text=query,
            k=3,  # Only return top 3 matches
            similarity_threshold=0.3
        )
        
        # Print results
        if results:
            print(f"Found {len(results)} similar requirements:")
            for i, result in enumerate(results, 1):
                print(f"\n-- Result {i} --")
                print(f"Category: {result.get('category', 'N/A')}")
                print(f"Similarity: {result.get('similarity', 0):.4f}")
                print(f"Requirement: {result.get('requirement', 'N/A')}")
                
                if result.get('response'):
                    print(f"Response: {result.get('response', '')[:150]}...")
                else:
                    print("No response available")
            return True
        else:
            print("No similar requirements found")
            return False
                
    except Exception as e:
        print(f"Error testing vector search: {e}")
        return False

if __name__ == "__main__":
    print("Testing vector search functionality...")
    success = test_vector_search_single_query()
    
    if success:
        print("\nVector search test completed successfully!")
        sys.exit(0)
    else:
        print("\nVector search test failed!")
        sys.exit(1)