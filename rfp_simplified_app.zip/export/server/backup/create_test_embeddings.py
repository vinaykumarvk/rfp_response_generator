#!/usr/bin/env python3
"""
Script to create test embeddings for vector search
This populates the database with a few sample embeddings for testing purposes
"""

import os
import sys
import json
import psycopg2
from openai import OpenAI

def get_database_connection():
    """Get a connection to the PostgreSQL database."""
    try:
        # Get connection string from environment variable
        db_url = os.environ.get('DATABASE_URL')
        if not db_url:
            print("DATABASE_URL environment variable not set")
            sys.exit(1)
        
        # Connect to the database
        conn = psycopg2.connect(db_url)
        print("Successfully connected to PostgreSQL database")
        return conn
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        sys.exit(1)

def get_embedding(text):
    """Generate an embedding vector for the provided text."""
    try:
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        embedding = response.data[0].embedding
        print(f"Generated embedding with {len(embedding)} dimensions")
        return embedding
    except Exception as e:
        print(f"Error generating embedding: {str(e)}")
        sys.exit(1)

def create_test_embeddings():
    """Create test embeddings for vector search."""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    # Check if we already have test embeddings
    cursor.execute("SELECT COUNT(*) FROM embeddings;")
    count = cursor.fetchone()[0]
    
    if count > 0:
        print(f"Database already has {count} embeddings - no need to create test embeddings")
        return
    
    # Sample test data
    test_data = [
        {
            "category": "Security",
            "requirement": "Describe your solution's security capabilities including multi-factor authentication and data encryption.",
            "response": "Our platform implements enterprise-grade security with multi-layered protection. Multi-factor authentication is standard across all access points, supporting SMS, email, authenticator apps, and biometric verification. Data is encrypted both in transit (TLS 1.3) and at rest (AES-256), with unique encryption keys per client. Role-based access controls allow precise permission setting, while continuous security monitoring detects and blocks threats in real-time. Regular penetration testing and SOC 2 Type II compliance ensure our security measures meet industry standards, protecting sensitive financial information against emerging threats."
        },
        {
            "category": "Reporting",
            "requirement": "Outline the reporting capabilities of your system and how they can be customized by advisors.",
            "response": "Our reporting system combines depth with flexibility through a comprehensive library of 75+ pre-built reports alongside customizable reporting tools. Advisors can easily configure dashboards with drag-and-drop widgets showing key metrics, performance analytics, and client insights. Reports can be personalized with white-labeling options, custom logos, and branding elements. The system supports scheduled distribution via multiple channels (email, client portal, or print) with automated delivery. For advanced needs, advisors can create custom templates using our report builder, selecting specific data points, visualizations, and narrative sections. All reports comply with regulatory requirements while maintaining clear visualization of complex data."
        },
        {
            "category": "Document Management",
            "requirement": "Describe your platform's document management capabilities and how they enhance advisor efficiency.",
            "response": "Our document management system streamlines advisor workflows through intelligent organization and automation. The platform provides secure cloud storage with version control, maintaining complete audit trails for compliance. Documents are automatically tagged and categorized using AI, making retrieval intuitive through advanced search functionality that supports filters, metadata, and content searches. Client collaboration is enhanced through secure document sharing with electronic signature integration (DocuSign, Adobe Sign). Automated document processing extracts key data from uploaded forms, populating fields across the system to eliminate manual entry. Integration with CRM ensures documents attach to relevant client records, while automated retention policies enforce compliant document lifecycle management."
        },
        {
            "category": "Portfolio Management",
            "requirement": "Explain how your solution supports complex portfolio management across multiple asset classes.",
            "response": "Our portfolio management platform handles multi-asset investment strategies through a unified architecture that provides consistent valuation, risk assessment, and performance measurement across all asset classes. The system supports traditional securities, alternatives, options, futures, private equity, and digital assets with real-time position tracking and comprehensive analytics. Rebalancing tools optimize portfolios against targets with tax-efficiency controls, supporting household-level management for multi-account relationships. Risk modeling capabilities include stress testing, scenario analysis, and Monte Carlo simulations to evaluate portfolios under various market conditions. For sophisticated clients, the platform offers custom asset allocation models and strategy overlays that can incorporate proprietary methodologies while maintaining scalable operations through automation."
        },
        {
            "category": "Integration",
            "requirement": "Detail your system's integration capabilities with third-party applications and data sources.",
            "response": "Our platform delivers comprehensive integration capabilities through multiple connection methods including a fully documented REST API, webhook system, and native connectors to major financial systems. Pre-built integrations exist for over 50 financial services applications including major custodians, CRMs, financial planning tools, and market data providers. The open architecture supports custom integration development through our developer portal, complete with SDKs for multiple programming languages. Data synchronization occurs in real-time or scheduled intervals depending on business requirements, with a unified data model that normalizes information across systems. All integrations maintain enterprise-grade security with OAuth 2.0 authentication, API key management, and granular permission controls to protect sensitive financial information."
        }
    ]
    
    try:
        for item in test_data:
            # Generate embedding for combined category and requirement
            text = f"{item['category']} - {item['requirement']}"
            embedding = get_embedding(text)
            
            # Create payload with metadata
            payload = {
                "source": "test_data",
                "created_by": "system",
                "version": "1.0"
            }
            
            # Insert into database
            cursor.execute("""
            INSERT INTO embeddings 
                (category, requirement, response, reference, payload, embedding) 
            VALUES 
                (%s, %s, %s, %s, %s, %s)
            """, (
                item['category'],
                item['requirement'],
                item['response'],
                f"Sample {item['category']} reference",
                json.dumps(payload),
                embedding
            ))
            
            print(f"Created test embedding for: {item['category']} - {item['requirement'][:30]}...")
        
        # Commit the changes
        conn.commit()
        print(f"Successfully created {len(test_data)} test embeddings")
        
        # Verify the count
        cursor.execute("SELECT COUNT(*) FROM embeddings;")
        new_count = cursor.fetchone()[0]
        print(f"Total embeddings in database: {new_count}")
        
    except Exception as e:
        conn.rollback()
        print(f"Error creating test embeddings: {str(e)}")
        sys.exit(1)
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    print("Creating test embeddings for vector search...")
    create_test_embeddings()
    print("Script completed successfully")