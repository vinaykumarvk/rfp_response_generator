#!/usr/bin/env python3
"""
Script to insert test embeddings into the database for testing reference responses.
This will create several sample embeddings with random vectors to simulate actual embeddings.
"""
import os
import sys
import json
import numpy as np
import psycopg2
from psycopg2.extras import execute_values

# Configuration
VECTOR_DIM = 1536  # OpenAI's embedding dimension
DATABASE_URL = os.environ.get('DATABASE_URL')

# Test data samples with meaningful patterns
TEST_SAMPLES = [
    {
        'category': 'Wealth Management Software',
        'requirement': 'Describe the reporting capabilities for investment performance',
        'response': 'Our wealth management software offers comprehensive reporting capabilities for investment performance including real-time dashboards, customizable reports, and portfolio analytics. The platform supports performance measurement against various benchmarks, risk analysis, and historical trend visualization.',
        'reference': 'Sample Reference 1',
        'payload': json.dumps({'source': 'test', 'score': 0.95})
    },
    {
        'category': 'Wealth Management Software',
        'requirement': 'Explain your solution\'s investment performance reporting features',
        'response': 'Our solution provides detailed investment performance reporting features including customizable dashboards, performance attribution analysis, and benchmark comparisons. Users can generate reports showing time-weighted returns, risk-adjusted metrics, and portfolio allocation impacts.',
        'reference': 'Sample Reference 2',
        'payload': json.dumps({'source': 'test', 'score': 0.92})
    },
    {
        'category': 'Wealth Management Software',
        'requirement': 'What reporting tools does your platform offer for portfolio analysis?',
        'response': 'Our platform includes advanced reporting tools for portfolio analysis such as performance heat maps, correlation matrices, and scenario modeling. Reports can be scheduled, exported in multiple formats, and securely shared with clients.',
        'reference': 'Sample Reference 3',
        'payload': json.dumps({'source': 'test', 'score': 0.88})
    },
    {
        'category': 'Security',
        'requirement': 'Detail your solution\'s data backup and recovery process',
        'response': 'Our solution implements a robust data backup and recovery process with automatic daily backups, point-in-time recovery capabilities, and geo-redundant storage across multiple data centers. All backup data is encrypted and regularly tested for integrity.',
        'reference': 'Sample Reference 4',
        'payload': json.dumps({'source': 'test', 'score': 0.90})
    },
    {
        'category': 'Security',
        'requirement': 'How does your platform handle backup and disaster recovery?',
        'response': 'Our platform handles backup and disaster recovery through a comprehensive system including real-time replication, incremental backups, and full system snapshots. We maintain multiple recovery sites with automated failover capabilities and regular recovery testing.',
        'reference': 'Sample Reference 5',
        'payload': json.dumps({'source': 'test', 'score': 0.87})
    },
    {
        'category': 'Compliance',
        'requirement': 'Explain how your system handles tax reporting for multiple jurisdictions',
        'response': 'Our system supports tax reporting across multiple jurisdictions with built-in tax rule engines, automated tax document generation, and compliance tracking. The platform maintains up-to-date tax regulations and can produce jurisdiction-specific reports for different tax authorities.',
        'reference': 'Sample Reference 6',
        'payload': json.dumps({'source': 'test', 'score': 0.93})
    },
    {
        'category': 'Compliance',
        'requirement': 'How does your platform manage tax reporting requirements across different countries?',
        'response': 'Our platform manages cross-country tax reporting requirements through a configurable tax rule system, automated withholding calculations, and jurisdiction-specific report templates. The system is regularly updated with regulatory changes and supports global tax compliance.',
        'reference': 'Sample Reference 7',
        'payload': json.dumps({'source': 'test', 'score': 0.89})
    }
]

def generate_embedding_vector():
    """Generate a random normalized embedding vector of the correct dimension."""
    # Create a random vector
    vector = np.random.normal(0, 1, VECTOR_DIM)
    # Normalize to unit length (cosine similarity requires normalized vectors)
    vector = vector / np.linalg.norm(vector)
    return vector.tolist()

def insert_test_embeddings():
    """Insert test embeddings into the database."""
    if not DATABASE_URL:
        print("ERROR: DATABASE_URL environment variable is not set")
        return False
    
    try:
        print(f"Connecting to database...")
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        
        # First create necessary extension if it doesn't exist
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        
        # Ensure the embedding column exists
        cursor.execute("""
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT FROM information_schema.columns 
                WHERE table_name = 'embeddings' AND column_name = 'embedding'
            ) THEN
                ALTER TABLE embeddings ADD COLUMN embedding vector(1536);
            END IF;
        END
        $$;
        """)
        
        # Insert or update test data
        for sample in TEST_SAMPLES:
            # Generate a consistent embedding vector for similar content
            vector = generate_embedding_vector()
            
            # Convert vector to PostgreSQL format
            vector_str = f"[{','.join(str(x) for x in vector)}]"
            
            # Check if similar record exists
            cursor.execute(
                "SELECT id FROM embeddings WHERE requirement ILIKE %s LIMIT 1",
                (f"%{sample['requirement']}%",)
            )
            existing_id = cursor.fetchone()
            
            if existing_id:
                # Update existing record
                cursor.execute(
                    """
                    UPDATE embeddings SET 
                        category = %s,
                        requirement = %s,
                        response = %s,
                        reference = %s,
                        payload = %s,
                        embedding = %s::vector
                    WHERE id = %s
                    """,
                    (
                        sample['category'],
                        sample['requirement'],
                        sample['response'],
                        sample['reference'],
                        sample['payload'],
                        vector_str,
                        existing_id[0]
                    )
                )
                print(f"Updated existing embedding record with ID {existing_id[0]}")
            else:
                # Insert new record
                cursor.execute(
                    """
                    INSERT INTO embeddings 
                        (category, requirement, response, reference, payload, embedding)
                    VALUES (%s, %s, %s, %s, %s, %s::vector)
                    RETURNING id
                    """,
                    (
                        sample['category'],
                        sample['requirement'],
                        sample['response'],
                        sample['reference'],
                        sample['payload'],
                        vector_str
                    )
                )
                new_id = cursor.fetchone()[0]
                print(f"Inserted new embedding record with ID {new_id}")
        
        # Create simpler index for vector similarity search that uses less memory
        try:
            cursor.execute("""
            CREATE INDEX IF NOT EXISTS embeddings_embedding_idx ON embeddings USING hnsw (embedding vector_cosine_ops)
            WITH (m = 8, ef_construction = 32);
            """)
        except Exception as e:
            print(f"Warning: Could not create HNSW index: {str(e)}")
            # Fall back to L2 distance for compatibility
            try:
                cursor.execute("""
                CREATE INDEX IF NOT EXISTS embeddings_embedding_idx_l2 ON embeddings USING btree ((embedding <-> '[0]'::vector));
                """)
                print("Created fallback L2 distance index instead")
            except Exception as e:
                print(f"Warning: Could not create fallback index: {str(e)}")
                print("Continuing without vector index - search will be slower but still functional")
        
        conn.commit()
        print("Successfully inserted test embeddings into the database")
        
        # Show count of embeddings in database
        cursor.execute("SELECT COUNT(*) FROM embeddings")
        count = cursor.fetchone()[0]
        print(f"Total embeddings in database: {count}")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"ERROR: Failed to insert test embeddings: {str(e)}")
        return False

if __name__ == "__main__":
    success = insert_test_embeddings()
    sys.exit(0 if success else 1)