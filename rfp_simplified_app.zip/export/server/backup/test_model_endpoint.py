#!/usr/bin/env python3
"""
Test the model-specific endpoint integration
This tests just our model_specific_test.py implementation with a minimal prompt
"""

import sys
import json
from model_specific_test import test_specific_model

def test_model_endpoint():
    """Test the model endpoint with a short prompt for faster testing"""
    
    print("\n=== TESTING MODEL-SPECIFIC ENDPOINT ===")
    
    # Use a very simple requirement for faster response
    requirement = "List 3 document management features. Keep it brief."
    
    # Test both OpenAI and MOA to verify integration
    for provider in ["openai", "moa"]:
        print(f"\nTesting provider: {provider}")
        result = test_specific_model(provider, requirement)
        
        if result["success"]:
            print(f"✅ {provider} test succeeded")
            
            # Show basic metrics
            if "processing_time" in result:
                print(f"Processing time: {result['processing_time']:.2f}s")
            
            if "metrics" in result:
                metrics = result["metrics"]
                print(f"Models succeeded: {metrics.get('models_succeeded', 'N/A')} of {metrics.get('models_attempted', 'N/A')}")
                print(f"Total time: {metrics.get('total_time', 'N/A'):.2f}s")
            
            # Show response sizes
            if provider == "moa":
                print("\nResponse sizes:")
                print(f"OpenAI: {len(result.get('openai_response', '')) if result.get('openai_response') else 'N/A'} chars")
                print(f"Anthropic: {len(result.get('anthropic_response', '')) if result.get('anthropic_response') else 'N/A'} chars")
                print(f"DeepSeek: {len(result.get('deepseek_response', '')) if result.get('deepseek_response') else 'N/A'} chars")
                print(f"MOA: {len(result.get('moa_response', '')) if result.get('moa_response') else 'N/A'} chars")
            else:
                print(f"\nResponse size: {len(result.get('generated_response', ''))} chars")
            
            # Show snippet of response
            response = result.get("generated_response", "No response")
            if response:
                print(f"\nResponse snippet: {response[:100]}...")
        else:
            print(f"❌ {provider} test failed: {result.get('error', 'Unknown error')}")
    
    print("\n=== MODEL-SPECIFIC ENDPOINT TEST COMPLETE ===")

if __name__ == "__main__":
    test_model_endpoint()