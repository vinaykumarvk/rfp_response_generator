#!/usr/bin/env python3
"""
Simple MOA Test 
This script tests just the core functionality of the MOA implementation with a minimal example
"""

import json
from rfp_response_generator_pg import prompt_gpt, create_rfp_prompt

def test_response_integrity():
    """Test that we can get responses from each model independently"""
    
    print("\n=== TESTING MODEL RESPONSE INTEGRITY ===")
    
    # Simple test prompt - kept minimal for faster responses
    test_prompt = [
        {"role": "system", "content": "You are an expert in wealth management software."},
        {"role": "user", "content": "List 3 key features of document management. Keep it brief."}
    ]
    
    # Test each model individually
    for model_name in ["openAI", "anthropic", "deepseek"]:
        print(f"\nTesting {model_name}...")
        
        try:
            # Get response
            response = prompt_gpt(test_prompt, llm=model_name)
            
            # Check for errors
            if response.startswith("Error:"):
                print(f"❌ {model_name} error: {response}")
            else:
                # Success
                print(f"✅ {model_name} response received ({len(response)} chars)")
                print(f"--- First 100 chars ---")
                print(response[:100])
                print("-------------------")
        
        except Exception as e:
            print(f"❌ {model_name} exception: {str(e)}")
    
    print("\n=== MODEL RESPONSE INTEGRITY TEST COMPLETE ===")

def test_create_rfp_prompt():
    """Test that the create_rfp_prompt function works correctly"""
    
    print("\n=== TESTING RFP PROMPT CREATION ===")
    
    # Test parameters
    requirement = "Describe the document management capabilities of your platform."
    category = "Wealth Management Software"
    
    # Generate prompt - include empty previous_responses
    prompt = create_rfp_prompt(requirement, category, "")
    
    # Check prompt structure
    print(f"Prompt has {len(prompt)} messages")
    print(f"System message: {prompt[0]['role']}")
    print(f"User message: {prompt[1]['role']}")
    
    # Check requirement is in prompt
    user_message = prompt[1]['content']
    if requirement in user_message:
        print(f"✅ Requirement found in prompt")
    else:
        print(f"❌ Requirement NOT found in prompt")
    
    print("\n=== RFP PROMPT CREATION TEST COMPLETE ===")

if __name__ == "__main__":
    # Run the tests
    test_create_rfp_prompt()
    test_response_integrity()