#!/usr/bin/env python3
"""Test script for API connectivity using hardcoded API keys"""

import os
import sys
import json
import time

def prompt_gpt(prompt, llm='openAI'):
    """
    Call a language model API with a prompt.
    
    Args:
        prompt: List of message dictionaries for OpenAI-style APIs, or converted format for Claude
        llm: The LLM provider to use ('openAI', 'anthropic', or 'deepseek')
        
    Returns:
        The generated text response
    """
    try:
        if llm == 'openAI':
            # Hardcoded OpenAI API key for reliable deployment
            openai_api_key = "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"
            
            import openai
            client = openai.OpenAI(api_key=openai_api_key)
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=prompt,
                temperature=0.7,
                timeout=30
            )
            return response.choices[0].message.content.strip()

        elif llm == 'deepseek':
            # Hardcoded DeepSeek API key for reliable deployment
            deepseek_api_key = "sk-83b923d8b26d42be934ecac1d0fef9ed"
            
            import openai
            client = openai.OpenAI(
                api_key=deepseek_api_key,
                base_url="https://api.deepseek.com/v1"
            )
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=prompt,
                temperature=0.7,
                timeout=30
            )
            return response.choices[0].message.content.strip()

        elif llm == 'anthropic':
            # Hardcoded Anthropic API key for reliable deployment
            anthropic_api_key = "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"
            
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_api_key)
            
            # Handle the different format for Claude messages
            claude_formatted = convert_promt_to_claude(prompt)
            
            # the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
            response = client.messages.create(
                model="claude-3-7-sonnet-20250219",
                max_tokens=1000,
                temperature=0.7,
                messages=claude_formatted["messages"],
                system=claude_formatted["system"]
            )
            return extract_text(response)
            
        else:
            return f"Error: Unsupported LLM provider '{llm}'"
            
    except Exception as e:
        print(f"Error in prompt_gpt with {llm}: {str(e)}")
        return f"Error calling {llm} API: {str(e)}"

def convert_promt_to_claude(prompt):
    """
    Convert a prompt formatted for OpenAI to one compatible with Claude.
    
    Args:
        prompt: List of message dictionaries formatted for OpenAI
        
    Returns:
        Dict with 'messages' (list of message dictionaries) and 'system' (system message)
    """
    claude_messages = []
    system_message = ""

    # Extract system message if present
    for msg in prompt:
        if msg['role'] == 'system':
            system_message = msg['content']
            break

    # Convert messages
    for msg in prompt:
        if msg['role'] == 'system':
            continue  # Skip system messages as they're handled differently
        
        claude_messages.append({
            'role': 'user' if msg['role'] == 'user' else 'assistant',
            'content': msg['content']
        })

    # For Claude 3 models, we can pass system message directly instead of inserting it
    return {
        "messages": claude_messages,
        "system": system_message if system_message else None
    }

def extract_text(response):
    """
    Extract clean text from Claude's response.

    Args:
        response: Response from Claude API

    Returns:
        str: Clean text content
    """
    # Handle different versions of the Claude API response format
    if hasattr(response, 'content') and isinstance(response.content, list):
        # Newer Claude API format
        for content_block in response.content:
            if hasattr(content_block, 'text') and content_block.text:
                return content_block.text
            if isinstance(content_block, dict) and 'text' in content_block:
                return content_block['text']
    
    # Fallback for string content or other formats
    if hasattr(response, 'content') and isinstance(response.content, str):
        return response.content
    
    # Last resort, try to convert the entire response to string
    try:
        return str(response)
    except Exception as e:
        return f"Failed to extract text from response: {str(e)}"

def test_all_models():
    """Test all three models one by one and print the results."""
    models = ["openAI", "anthropic", "deepseek"]
    results = {}
    
    print("\n" + "="*50)
    print("TESTING ALL MODELS WITH HARDCODED API KEYS")
    print("="*50)
    
    # Simple test prompt for all models
    test_prompt = [
        {"role": "system", "content": "You are a helpful assistant specialized in RFP responses."},
        {"role": "user", "content": "Please provide a brief description of multi-factor authentication for a banking application in 2-3 sentences."}
    ]
    
    # Test each model
    for model in models:
        print(f"\nTesting {model} API...")
        print("-"*30)
        
        try:
            # Test with our structured prompt
            print(f"Sending prompt to {model}...\n")
            start_time = time.time()
            response = prompt_gpt(test_prompt, llm=model)
            elapsed_time = time.time() - start_time
            
            # Print the result
            print(f"Response from {model} (in {elapsed_time:.2f} seconds):")
            print("-"*50)
            print(response[:300] + "..." if len(response) > 300 else response)
            print("-"*50)
            
            results[model] = {
                "status": "success" if not response.startswith("Error") else "error",
                "response": response, 
                "time": elapsed_time
            }
            
        except Exception as e:
            print(f"Error testing {model}: {str(e)}")
            results[model] = {"status": "error", "message": str(e)}
    
    # Print summary of results
    print("\n" + "="*50)
    print("TEST RESULTS SUMMARY")
    print("="*50)
    for model, result in results.items():
        status = "✅ SUCCESS" if result.get("status") == "success" else "❌ FAILED"
        details = f" - {result.get('time', 0):.2f}s" if result.get("status") == "success" else f" - {result.get('message', 'Unknown error')}"
        print(f"{model}: {status}{details}")
    
    return results

if __name__ == "__main__":
    test_all_models()