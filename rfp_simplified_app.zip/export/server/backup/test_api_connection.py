#!/usr/bin/env python3
"""
Simple test script to verify API connectivity with OpenAI and Anthropic.
Run this script directly from the command line to test LLM connections:
    python3 test_api_connection.py openai
    python3 test_api_connection.py anthropic
"""

import os
import sys
import json
import time

def test_openai_connection():
    """Test connection to OpenAI API"""
    try:
        from openai import OpenAI
        
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            return {
                "success": False,
                "error": "OPENAI_API_KEY environment variable not found"
            }
            
        # Start timing
        start_time = time.time()
        
        # Initialize client
        client = OpenAI(api_key=api_key)
        
        # Make a simple API call
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": "Please respond with 'OpenAI connection successful' and nothing else."}
            ],
            max_tokens=50
        )
        
        # End timing
        end_time = time.time()
        
        return {
            "success": True,
            "message": "OpenAI API connection successful",
            "response": response.choices[0].message.content,
            "response_time_ms": int((end_time - start_time) * 1000)
        }
    except ImportError as e:
        return {
            "success": False,
            "error": f"ImportError: {str(e)}. Please install the openai package with 'pip install openai'."
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Error connecting to OpenAI API: {str(e)}"
        }

def test_anthropic_connection():
    """Test connection to Anthropic API"""
    try:
        from anthropic import Anthropic
        
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return {
                "success": False,
                "error": "ANTHROPIC_API_KEY environment variable not found"
            }
            
        # Start timing
        start_time = time.time()
        
        # Initialize client
        client = Anthropic(api_key=api_key)
        
        # Make a simple API call
        response = client.messages.create(
            model="claude-3-7-sonnet-20250219",
            max_tokens=50,
            messages=[
                {"role": "user", "content": "Please respond with 'Anthropic connection successful' and nothing else."}
            ]
        )
        
        # End timing
        end_time = time.time()
        
        return {
            "success": True,
            "message": "Anthropic API connection successful",
            "response": response.content[0].text,
            "response_time_ms": int((end_time - start_time) * 1000)
        }
    except ImportError as e:
        return {
            "success": False,
            "error": f"ImportError: {str(e)}. Please install the anthropic package with 'pip install anthropic'."
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Error connecting to Anthropic API: {str(e)}"
        }

if __name__ == "__main__":
    provider = "openai"  # Default
    
    if len(sys.argv) > 1:
        provider = sys.argv[1].lower()
    
    if provider == "openai":
        result = test_openai_connection()
    elif provider == "anthropic":
        result = test_anthropic_connection()
    else:
        result = {
            "success": False,
            "error": f"Unknown provider: {provider}. Use 'openai' or 'anthropic'."
        }
    
    # Print the result in JSON format
    print(json.dumps(result, indent=2))
    
    # Also print a human-readable summary
    if result["success"]:
        print("\n✅ Connection test successful!")
        print(f"Response: {result.get('response', 'No response content')}")
        print(f"Response time: {result.get('response_time_ms', 'Unknown')}ms")
    else:
        print("\n❌ Connection test failed!")
        print(f"Error: {result.get('error', 'Unknown error')}")
    
    # Exit with appropriate code
    sys.exit(0 if result["success"] else 1)