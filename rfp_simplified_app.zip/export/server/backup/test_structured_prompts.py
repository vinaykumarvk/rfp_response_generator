#!/usr/bin/env python3
"""
Test script for the structured prompts in the RFP response generator
This script will test the API calls with the structured prompts for all three providers
"""
import os
import sys
import json
import time
from typing import List, Dict, Any

# Import from rfp_response_generator_pg.py
from rfp_response_generator_pg import (
    process_requirement,
    test_api_connection,
    OPENAI_API_KEY,
    ANTHROPIC_API_KEY,
    DEEPSEEK_API_KEY
)

# Check if API keys are set
def check_api_keys():
    """Check if the necessary API keys are set."""
    print("Checking API keys...")
    print(f"OpenAI API key available: {'Yes' if OPENAI_API_KEY else 'No'}")
    print(f"Anthropic API key available: {'Yes' if ANTHROPIC_API_KEY else 'No'}")
    print(f"DeepSeek API key available: {'Yes' if DEEPSEEK_API_KEY else 'No'}")
    
    if not (OPENAI_API_KEY and ANTHROPIC_API_KEY and DEEPSEEK_API_KEY):
        print("Warning: Not all API keys are available!")
    
    print("=" * 50)

# Test API connections
def test_all_api_connections():
    """Test connections to all supported API providers."""
    print("Testing API connections...")
    
    for provider in ["openai", "anthropic", "deepseek"]:
        print(f"\nTesting {provider} API connection:")
        
        if provider == "deepseek":
            # We don't have a test_api_connection for DeepSeek, so we'll skip it
            print("DeepSeek API connection test not implemented, skipping...")
            continue
        
        result = test_api_connection(provider)
        print(f"Status: {result.get('status', 'unknown')}")
        print(f"Message: {result.get('message', 'No message')}")
        if "response" in result:
            print(f"Response: {result['response']}")
    
    print("=" * 50)

# Test processing requirements with all providers
def test_all_providers():
    """Test processing a sample requirement with all providers."""
    print("Testing requirement processing with all providers...")
    
    sample_requirement = "Describe your system's ability to handle multi-factor authentication."
    
    for provider in ["openai", "anthropic", "deepseek"]:
        print(f"\nTesting {provider} provider:")
        print(f"Sample requirement: {sample_requirement}")
        
        start_time = time.time()
        result = process_requirement(sample_requirement, provider)
        elapsed_time = time.time() - start_time
        
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            response = result.get("generated_response", "No response")
            print(f"Response (first 200 chars): {response[:200]}...")
            print(f"Response length: {len(response)} characters")
            
            # Check for model-specific responses
            model_specific_field = f"{provider}_response"
            if model_specific_field in result:
                print(f"Model-specific response present in '{model_specific_field}' field: Yes")
            else:
                print(f"Model-specific response present: No")
        
        print(f"Processing time: {elapsed_time:.2f} seconds")
    
    print("=" * 50)

# Main function
def main():
    """Main function to run all tests."""
    print("=" * 50)
    print("STRUCTURED PROMPT API TESTING")
    print("=" * 50)
    
    # Check API keys
    check_api_keys()
    
    # Test API connections
    test_all_api_connections()
    
    # Test all providers
    test_all_providers()
    
    print("Tests completed!")

if __name__ == "__main__":
    main()