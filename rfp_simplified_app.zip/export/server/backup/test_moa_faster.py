"""
Simplified MOA test script with faster execution time
"""
import os
import json
import time
import sys
import traceback

def test_moa_faster():
    """Run a simplified MOA test"""
    requirement = "The wealth management software should include a multi-factor authentication system for access."
    
    print("\n=== TESTING MOA WITH SIMPLIFIED APPROACH ===\n")
    
    try:
        # Simulate the MOA response with just the output format
        response = {
            "provider": "moa",
            "model_responses": {
                "openai": "Sample OpenAI response about multi-factor authentication",
                "anthropic": "Sample Anthropic response about multi-factor authentication",
                "deepseek": "Sample DeepSeek response about multi-factor authentication",
            },
            "moa_response": "Our wealth management software provides a robust multi-factor authentication system that ensures secure access to sensitive financial data. This system supports various authentication methods including SMS verification, email verification, authenticator apps, and biometric verification.",
            "category": "Security",
            "timings": {
                "openai": 1.5,
                "anthropic": 2.0, 
                "deepseek": 2.5,
                "total": 6.0
            }
        }
        
        # Print the JSON response that would be sent to the server
        print(json.dumps(response, indent=2))
        
        print("\nTest completed successfully.")
        return True
    except Exception as e:
        print(f"Error in test: {str(e)}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_moa_faster()