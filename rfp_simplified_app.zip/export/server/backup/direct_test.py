#!/usr/bin/env python3
"""
Direct API testing script for use with our simple-direct-test endpoint.
This script contains a streamlined approach that outputs ONLY the JSON result.
"""

import os
import sys
import json
from rfp_response_generator_pg import prompt_gpt

def test_openai():
    """Test OpenAI API connectivity directly"""
    try:
        test_prompt = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Describe multi-factor authentication briefly for a banking app."}
        ]
        
        response = prompt_gpt(test_prompt, llm='openAI')
        
        result = {
            "status": "success" if not response.startswith("Error") else "error",
            "provider": "openai",
            "response": response
        }
        
        return result
    except Exception as e:
        return {
            "status": "error",
            "provider": "openai",
            "message": str(e)
        }

def test_anthropic():
    """Test Anthropic API connectivity directly"""
    try:
        test_prompt = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Describe multi-factor authentication briefly for a banking app."}
        ]
        
        response = prompt_gpt(test_prompt, llm='anthropic')
        
        result = {
            "status": "success" if not response.startswith("Error") else "error",
            "provider": "anthropic",
            "response": response
        }
        
        return result
    except Exception as e:
        return {
            "status": "error",
            "provider": "anthropic",
            "message": str(e)
        }

def test_deepseek():
    """Test DeepSeek API connectivity directly"""
    try:
        test_prompt = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Describe multi-factor authentication briefly for a banking app."}
        ]
        
        response = prompt_gpt(test_prompt, llm='deepseek')
        
        result = {
            "status": "success" if not response.startswith("Error") else "error",
            "provider": "deepseek",
            "response": response
        }
        
        return result
    except Exception as e:
        return {
            "status": "error",
            "provider": "deepseek",
            "message": str(e)
        }

# Execute all tests
if __name__ == "__main__":
    print("Testing OpenAI API...")
    openai_result = test_openai()
    print(f"OpenAI status: {openai_result['status']}")
    if openai_result['status'] == 'success':
        print(f"OpenAI response: {openai_result['response'][:200]}...")
    else:
        print(f"OpenAI error: {openai_result.get('message', 'Unknown error')}")
    
    print("\nTesting Anthropic API...")
    anthropic_result = test_anthropic()
    print(f"Anthropic status: {anthropic_result['status']}")
    if anthropic_result['status'] == 'success':
        print(f"Anthropic response: {anthropic_result['response'][:200]}...")
    else:
        print(f"Anthropic error: {anthropic_result.get('message', 'Unknown error')}")
    
    print("\nTesting DeepSeek API...")
    deepseek_result = test_deepseek()
    print(f"DeepSeek status: {deepseek_result['status']}")
    if deepseek_result['status'] == 'success':
        print(f"DeepSeek response: {deepseek_result['response'][:200]}...")
    else:
        print(f"DeepSeek error: {deepseek_result.get('message', 'Unknown error')}")