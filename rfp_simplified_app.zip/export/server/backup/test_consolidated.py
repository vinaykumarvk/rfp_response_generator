#!/usr/bin/env python3
"""
Consolidated Test Script for RFP Response Generator
This script runs multiple tests to ensure all components are working correctly:
1. Model-specific tests (OpenAI, Anthropic, DeepSeek)
2. MOA synthesis test
3. API endpoint integration test
"""

import json
import sys
import time
import requests

def test_direct_models():
    """Test direct calls to each model"""
    from direct_model_test import test_specific_model
    
    print("\n" + "="*80)
    print("TESTING DIRECT MODEL CALLS")
    print("="*80)
    
    requirement = "List 3 document management features. Keep it brief."
    
    # Test each model individually
    for model in ["openai", "anthropic", "deepseek"]:
        print(f"\nTesting {model.upper()}...")
        result = test_specific_model(model, requirement)
        
        if result["success"]:
            print(f"✅ {model.upper()} test successful")
            print(f"Processing time: {result.get('processing_time', 'N/A'):.2f}s")
            
            response = result.get("generated_response", "No response")
            if response:
                print(f"Response snippet: {response[:100]}...")
            else:
                print("No response generated")
        else:
            print(f"❌ {model.upper()} test failed: {result.get('error', 'Unknown error')}")
    
    print("\nDIRECT MODEL TESTS COMPLETE")

def test_moa_integration():
    """Test MOA integration"""
    from moa_final import generate_moa_response
    
    print("\n" + "="*80)
    print("TESTING MOA INTEGRATION")
    print("="*80)
    
    requirement = "List 3 document management features. Keep it brief."
    
    print(f"\nGenerating MOA response for: '{requirement}'")
    start_time = time.time()
    
    try:
        result = generate_moa_response(requirement)
        elapsed_time = time.time() - start_time
        
        if result["status"] == "success":
            print(f"✅ MOA integration test successful in {elapsed_time:.2f}s")
            
            # Print metrics
            metrics = result.get("metrics", {})
            print(f"\nMetrics:")
            for key, value in metrics.items():
                print(f"- {key}: {value}")
            
            # Print model response sizes
            model_responses = result.get("model_responses", {})
            print("\nResponse sizes:")
            for model, response in model_responses.items():
                if response:
                    print(f"- {model}: {len(response)} chars")
                else:
                    print(f"- {model}: Not available")
            
            # Print final response snippet
            final_response = result.get("final_response", "")
            if final_response:
                print(f"\nFinal response snippet:")
                print(f"{final_response[:200]}...")
            else:
                print("\nNo final response generated")
        else:
            print(f"❌ MOA integration test failed: {result.get('message', 'Unknown error')}")
    except Exception as e:
        print(f"❌ Exception during MOA integration test: {str(e)}")
    
    print("\nMOA INTEGRATION TEST COMPLETE")

def test_api_endpoint():
    """Test API endpoint integration"""
    print("\n" + "="*80)
    print("TESTING API ENDPOINT INTEGRATION")
    print("="*80)
    
    # Use the simple-model-test endpoint
    url = "http://localhost:5000/api/simple-model-test"
    
    # Use the test requirement ID that we already created
    payload = {
        "provider": "moa",
        "requirementId": 59  # This should be the test requirement ID
    }
    
    print(f"\nSending request to {url}...")
    start_time = time.time()
    
    try:
        response = requests.post(url, json=payload, timeout=60)
        elapsed_time = time.time() - start_time
        
        print(f"\nResponse received in {elapsed_time:.2f}s")
        print(f"Status code: {response.status_code}")
        
        if response.status_code == 200:
            try:
                result = response.json()
                print(f"Response body present: {bool(result)}")
                print(f"Success field: {result.get('success', 'Not present')}")
                
                # Print any message
                if "message" in result:
                    print(f"Message: {result['message']}")
                
                # Print response data summary if present
                if "data" in result:
                    data = result["data"]
                    print("\nResponse data summary:")
                    for key, value in data.items():
                        if isinstance(value, str):
                            print(f"- {key}: {len(value)} chars")
                        else:
                            print(f"- {key}: {type(value).__name__}")
            except ValueError:
                print(f"❌ Invalid JSON response: {response.text[:100]}...")
        else:
            print(f"❌ Request failed: {response.text[:100]}...")
    except Exception as e:
        print(f"❌ Exception during API endpoint test: {str(e)}")
    
    print("\nAPI ENDPOINT TEST COMPLETE")

def run_all_tests():
    """Run all tests"""
    print("\n" + "="*80)
    print("RUNNING COMPREHENSIVE TEST SUITE")
    print("="*80)
    
    # Record start time for the entire test suite
    total_start_time = time.time()
    
    # Run each test
    test_direct_models()
    test_moa_integration()
    test_api_endpoint()
    
    # Calculate total time
    total_time = time.time() - total_start_time
    
    print("\n" + "="*80)
    print(f"ALL TESTS COMPLETED IN {total_time:.2f}s")
    print("="*80)

if __name__ == "__main__":
    run_all_tests()