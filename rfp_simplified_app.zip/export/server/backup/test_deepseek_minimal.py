#!/usr/bin/env python3
"""
Test script for DeepSeek with a minimal prompt
"""

import sys
import time
from rfp_response_generator_pg import prompt_gpt

def test_deepseek_minimal():
    """Test DeepSeek with the simplest possible prompt"""
    print("\n" + "="*80)
    print("TESTING DEEPSEEK WITH MINIMAL PROMPT")
    print("="*80)
    
    # Extremely simple prompt
    prompt = [
        {"role": "user", "content": "What is document management? Answer in 1-2 sentences."}
    ]
    
    print(f"\nPrompt: {prompt[0]['content']}")
    print("\nSending to DeepSeek API...")
    
    # Set up a manual timer to track elapsed time
    start_time = time.time()
    
    try:
        # Call DeepSeek with timeout handling built into prompt_gpt
        response = prompt_gpt(prompt, llm='deepseek')
        elapsed_time = time.time() - start_time
        
        print(f"\nOperation completed in {elapsed_time:.2f} seconds")
        
        if response.startswith("Error:"):
            print(f"\nDeepSeek API error: {response}")
        else:
            print("\nDEEPSEEK RESPONSE:")
            print("-"*80)
            print(response)
            print("-"*80)
            
    except Exception as e:
        elapsed_time = time.time() - start_time
        print(f"\nException after {elapsed_time:.2f} seconds: {str(e)}")

# Main execution
if __name__ == "__main__":
    test_deepseek_minimal()