#!/usr/bin/env python3
"""
Test script for PostgreSQL vector search functionality
This script verifies that the PostgreSQL vector search is working correctly
"""
import os
import sys
import json
import datetime
import random
from pg_vector_search import find_similar_requirements_db, get_database_connection

def test_database_connection():
    """Test the database connection"""
    try:
        conn = get_database_connection()
        if conn:
            print("Database connection successful!")
            conn.close()
            return True
        else:
            print("Database connection failed!")
            return False
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        return False

def test_table_exists():
    """Test if the embeddings table exists"""
    try:
        conn = get_database_connection()
        if not conn:
            return False
            
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'embeddings';")
        count = cursor.fetchone()[0]
        
        if count > 0:
            print("Embeddings table exists!")
            
            # Check row count
            cursor.execute("SELECT COUNT(*) FROM embeddings;")
            row_count = cursor.fetchone()[0]
            print(f"Embeddings table has {row_count} rows")
            
            cursor.close()
            conn.close()
            return True
        else:
            print("Embeddings table does not exist!")
            cursor.close()
            conn.close()
            return False
    except Exception as e:
        print(f"Error checking if embeddings table exists: {str(e)}")
        return False

def test_random_vector_search():
    """Test vector search with a random vector"""
    try:
        # Generate a random test vector (1536 dimensions to match OpenAI embeddings)
        test_vector = [random.random() for _ in range(1536)]
        
        # Normalize the vector - this helps with cosine similarity
        # Simple normalization
        magnitude = sum(x*x for x in test_vector) ** 0.5
        if magnitude > 0:
            test_vector = [x/magnitude for x in test_vector]
        
        # Search for similar requirements with a very low threshold
        print("Searching for similar requirements with random vector...")
        print("Using a normalized random vector for better results")
        results = find_similar_requirements_db(test_vector, k=3, similarity_threshold=0.01)
        
        if results:
            print(f"Found {len(results)} similar requirements:")
            for i, result in enumerate(results, 1):
                print(f"{i}. {result['requirement'][:50]}... (score: {result['score']:.3f})")
            return True
        else:
            print("No similar requirements found.")
            return False
    except Exception as e:
        print(f"Error during random vector search: {str(e)}")
        return False

def test_vector_search_with_text(query_text="authentication"):
    """Test vector search with a specific text query"""
    try:
        # We would need OpenAI API for this, let's simulate with database queries
        print(f"Searching for requirements related to '{query_text}'...")
        
        conn = get_database_connection()
        if not conn:
            return False
            
        cursor = conn.cursor()
        
        # Use basic text search as a fallback
        cursor.execute("""
            SELECT category, requirement, response, '' as reference, 0.75 as similarity
            FROM embeddings 
            WHERE 
                requirement ILIKE %s OR 
                category ILIKE %s
            LIMIT 3;
        """, (f'%{query_text}%', f'%{query_text}%'))
        
        results = []
        for row in cursor.fetchall():
            result = {
                'category': row[0],
                'requirement': row[1],
                'response': row[2],
                'reference': row[3],
                'score': row[4]
            }
            results.append(result)
        
        cursor.close()
        conn.close()
        
        if results:
            print(f"Found {len(results)} requirements matching '{query_text}':")
            for i, result in enumerate(results, 1):
                print(f"{i}. {result['requirement'][:50]}... (score: {result['score']:.3f})")
            return True
        else:
            print(f"No requirements found matching '{query_text}'.")
            return False
    except Exception as e:
        print(f"Error during text search: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("=== POSTGRESQL VECTOR SEARCH TESTS ===")
    print(f"Timestamp: {datetime.datetime.now().isoformat()}")
    print(f"Python version: {sys.version}")
    print(f"DATABASE_URL available: {bool(os.environ.get('DATABASE_URL'))}")
    print()
    
    # Run tests
    tests = [
        ("Database Connection", test_database_connection),
        ("Embeddings Table Exists", test_table_exists),
        ("Random Vector Search", test_random_vector_search),
        ("Text Search", lambda: test_vector_search_with_text("authentication"))
    ]
    
    results = {}
    for name, func in tests:
        print(f"\n--- Testing: {name} ---")
        try:
            success = func()
            results[name] = success
        except Exception as e:
            print(f"Test failed with error: {str(e)}")
            results[name] = False
    
    # Print summary
    print("\n=== TEST SUMMARY ===")
    all_passed = True
    for name, success in results.items():
        status = "PASSED" if success else "FAILED"
        print(f"{name}: {status}")
        if not success:
            all_passed = False
    
    if all_passed:
        print("\nAll tests PASSED! PostgreSQL vector search is working correctly.")
        return 0
    else:
        print("\nSome tests FAILED. PostgreSQL vector search may not be working correctly.")
        return 1

if __name__ == "__main__":
    sys.exit(main())