#!/usr/bin/env python3
import os
import sys
import pickle
import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Any
import time
import json
import re
import requests
from sklearn.metrics.pairwise import cosine_similarity
from datetime import datetime
import gdown

# Constants
MODEL_EMBEDDINGS = "text-embedding-3-small"
MODEL_COMPLETION = "gpt-3.5-turbo"
# Use absolute paths for file access to ensure deployment compatibility
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EMBEDDING_FILE_PATH = os.path.join(BASE_DIR, "rfp_embeddings.pkl")
EXCEL_PATH = os.path.join(BASE_DIR, "attached_assets", "previous_responses.xlsx")

# Log paths for debugging
sys.stderr.write(f"BASE_DIR: {BASE_DIR}\n")
sys.stderr.write(f"EMBEDDING_FILE_PATH: {EMBEDDING_FILE_PATH}\n")
sys.stderr.write(f"EXCEL_PATH: {EXCEL_PATH}\n")

# Log basic environment information for debugging
sys.stderr.write("Starting RFP response generator with environment details:\n")
sys.stderr.write(f"Python version: {sys.version}\n")
sys.stderr.write(f"Current directory: {os.getcwd()}\n")

# PRODUCTION DEPLOYMENT: Hardcoded API keys 
# These will be used directly without relying on environment variables
OPENAI_API_KEY = "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"
ANTHROPIC_API_KEY = "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"
DEEPSEEK_API_KEY = "sk-831e97c2650c43c9b1336c48595e0941"

# Log API key availability
sys.stderr.write(f"Using hardcoded API keys in production deployment mode\n")
sys.stderr.write(f"OPENAI_API_KEY available: {'Yes' if OPENAI_API_KEY else 'No'}\n")
sys.stderr.write(f"ANTHROPIC_API_KEY available: {'Yes' if ANTHROPIC_API_KEY else 'No'}\n")
sys.stderr.write(f"DEEPSEEK_API_KEY available: {'Yes' if DEEPSEEK_API_KEY else 'No'}\n")

# Debug API key availability - use stderr to avoid JSON parsing issues
sys.stderr.write("=== PYTHON SCRIPT API KEY DEBUG ===\n")
sys.stderr.write(f"OPENAI_API_KEY available: {'Yes' if OPENAI_API_KEY else 'No'}\n")
if OPENAI_API_KEY:
    sys.stderr.write(f"OPENAI_API_KEY starts with: {OPENAI_API_KEY[:5]}...\n")
sys.stderr.write(f"ANTHROPIC_API_KEY available: {'Yes' if ANTHROPIC_API_KEY else 'No'}\n")
if ANTHROPIC_API_KEY:
    sys.stderr.write(f"ANTHROPIC_API_KEY starts with: {ANTHROPIC_API_KEY[:5]}...\n")
sys.stderr.write(f"DEEPSEEK_API_KEY available: {'Yes' if DEEPSEEK_API_KEY else 'No'}\n")
if DEEPSEEK_API_KEY:
    sys.stderr.write(f"DEEPSEEK_API_KEY starts with: {DEEPSEEK_API_KEY[:5]}...\n")
sys.stderr.write("=== PYTHON ENVIRONMENT ===\n")
sys.stderr.write(f"Python version: {sys.version}\n")
sys.stderr.write(f"Current working directory: {os.getcwd()}\n")
sys.stderr.write("====================================\n")

def download_embeddings():
    """Download the embeddings file from Google Drive."""
    try:
        # Google Drive file ID (extracted from the URL)
        file_id = "15hzeG0Lg0kyHSesJYROCgnC9VEQaOQ3I"
        
        # Destination path
        output_path = EMBEDDING_FILE_PATH
        
        # Check if file already exists
        if os.path.exists(output_path):
            # Use sys.stderr for logging to avoid messing with JSON output
            sys.stderr.write(f"Embeddings file already exists at {output_path}\n")
            return True
            
        sys.stderr.write(f"Downloading embeddings file from Google Drive...\n")
        
        # Direct download URL format
        url = f"https://drive.google.com/uc?id={file_id}"
        
        # Download the file
        gdown.download(url, output_path, quiet=False)
        
        if os.path.exists(output_path):
            sys.stderr.write(f"Successfully downloaded embeddings to {output_path}\n")
            return True
        else:
            sys.stderr.write("Failed to download embeddings file\n")
            return False
            
    except Exception as e:
        sys.stderr.write(f"Error downloading embeddings: {str(e)}\n")
        return False

def load_previous_responses():
    """Load previous responses from Excel file."""
    try:
        # Use the absolute path defined in constants 
        excel_path = EXCEL_PATH
        sys.stderr.write(f"Checking for Excel file at absolute path: {excel_path}\n")
        if os.path.exists(excel_path):
            sys.stderr.write(f"Loading previous responses from {excel_path}...\n")
            df = pd.read_excel(excel_path)
            sys.stderr.write(f"Excel columns: {list(df.columns)}\n")
            
            # Create a lookup dictionary with requirements as keys
            lookup = {}
            for _, row in df.iterrows():
                requirement = row.get('Requirement', '')
                reference = row.get('Reference', '')
                if requirement and isinstance(requirement, str):
                    lookup[requirement.strip()] = reference
            
            sys.stderr.write(f"Loaded {len(lookup)} reference mappings from Excel\n")
            return lookup
        else:
            sys.stderr.write(f"Previous responses file not found at {excel_path}\n")
            return {}
    except Exception as e:
        sys.stderr.write(f"Error loading previous responses: {str(e)}\n")
        return {}

def load_embeddings():
    """Load embeddings from the local file with enhanced error handling for production."""
    try:
        # First try the absolute path
        embedding_paths = [
            EMBEDDING_FILE_PATH,  # Try the absolute path first (new approach)
            "rfp_embeddings.pkl",  # Try root-relative path (original approach)
            os.path.join(os.getcwd(), "rfp_embeddings.pkl"),  # Try current working directory
            "/home/runner/workspace/rfp_embeddings.pkl"  # Try explicit Replit workspace path
        ]
        
        # Check if we're in production environment
        is_production = os.environ.get('NODE_ENV') == 'production' or os.environ.get('REPLIT_DEPLOYMENT') == 'true'
        
        # In production, prioritize downloading from Google Drive first
        if is_production:
            sys.stderr.write("Production environment detected. Prioritizing download from Google Drive...\n")
            # Always try to download a fresh copy in production
            if download_embeddings():
                try:
                    with open(EMBEDDING_FILE_PATH, 'rb') as f:
                        data = pickle.load(f)
                    sys.stderr.write(f"Embeddings loaded successfully from Google Drive in production!\n")
                    return data
                except Exception as e:
                    sys.stderr.write(f"Error loading downloaded embeddings: {str(e)}\n")
                    # Continue to normal flow if loading downloaded file fails
            else:
                sys.stderr.write("Failed to download embeddings in production, falling back to local paths.\n")
        
        # Log all potential paths for debugging
        sys.stderr.write(f"=== EMBEDDING FILE LOCATION CHECK ===\n")
        for path in embedding_paths:
            sys.stderr.write(f"Checking path: {path} - Exists: {os.path.exists(path)}\n")
            if os.path.exists(path):
                sys.stderr.write(f"File size: {os.path.getsize(path) / (1024*1024):.2f} MB\n")
                sys.stderr.write(f"File permissions: {oct(os.stat(path).st_mode)[-3:]}\n")
        sys.stderr.write(f"===================================\n")
        
        # Try each path in order
        for path in embedding_paths:
            if os.path.exists(path):
                sys.stderr.write(f"Found embeddings file at: {path}\n")
                try:
                    with open(path, 'rb') as f:
                        data = pickle.load(f)
                    sys.stderr.write(f"Embeddings loaded successfully from {path}!\n")
                    return data
                except Exception as e:
                    sys.stderr.write(f"Error loading embeddings from {path}: {str(e)}\n")
                    # Continue to the next path
        
        # If we get here, we couldn't load from any path, try downloading
        sys.stderr.write("Embeddings file not found in any location. Attempting to download...\n")
        if download_embeddings():
            # Try loading again after download
            with open(EMBEDDING_FILE_PATH, 'rb') as f:
                data = pickle.load(f)
            sys.stderr.write(f"Embeddings loaded successfully after download!\n")
            return data
        else:
            sys.stderr.write("Failed to download embeddings file.\n")
            # Create minimal embeddings data structure for fallback
            sys.stderr.write("Using minimal fallback embeddings.\n")
            return {"points": []}
    except Exception as e:
        sys.stderr.write(f"Critical error in load_embeddings: {str(e)}\n")
        # Return minimal data structure as fallback
        return {"points": []}

def get_embedding_from_openai(text: str, model="text-embedding-3-small"):
    """Get embedding for text using OpenAI API."""
    if not OPENAI_API_KEY:
        sys.stderr.write("OpenAI API key not found in environment variables\n")
        return None
        
    try:
        import openai
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        
        response = client.embeddings.create(
            model=model,
            input=text
        )
        
        return np.array(response.data[0].embedding)
    except Exception as e:
        sys.stderr.write(f"Error getting embedding from OpenAI: {str(e)}\n")
        return None

def find_similar_requirements(query_text: str, embeddings_data, k=5):
    """Find similar requirements based on the query text."""
    try:
        # Load reference lookup from Excel file
        reference_lookup = load_previous_responses()
        sys.stderr.write(f"Loaded reference lookup with {len(reference_lookup)} entries\n")
        
        # Get embedding for query text
        query_embedding = get_embedding_from_openai(query_text)
        if query_embedding is None:
            return []
            
        # Extract data from embeddings
        points = embeddings_data.get('points', [])
        
        # Prepare results
        results = []
        
        # Calculate similarity scores
        for point in points:
            point_vector = np.array(point['vector'])
            payload = point['payload']
            
            # Calculate cosine similarity
            similarity = cosine_similarity([query_embedding], [point_vector])[0][0]
            
            if similarity >= 0.3:  # Threshold
                # Debug payload keys
                sys.stderr.write(f"Payload keys: {list(payload.keys())}\n")
                
                # Get the requirement text
                requirement = payload.get('requirement', '')
                
                # Default reference text (fallback)
                reference_text = ""
                
                # First try to get reference from Excel lookup
                if requirement and requirement in reference_lookup:
                    reference_text = reference_lookup[requirement]
                    sys.stderr.write(f"Found reference in Excel for: {requirement[:30]}...\n")
                # If not found in Excel, try from payload
                elif 'reference' in payload:
                    reference_text = payload.get('reference', '')
                elif 'Reference' in payload:
                    reference_text = payload.get('Reference', '')
                # Last resort, generate from category and timestamp
                elif 'category' in payload and 'timestamp' in payload:
                    timestamp_str = payload.get('timestamp', '')
                    category_str = payload.get('category', '')
                    if timestamp_str and category_str:
                        # Use first 10 chars of timestamp for date
                        if len(timestamp_str) >= 10:
                            date_part = timestamp_str[:10]
                        else:
                            date_part = timestamp_str
                        reference_text = f"{category_str} response from {date_part}"
                
                result_item = {
                    'text': payload.get('text', 'No text available'),
                    'score': float(similarity),
                    'category': payload.get('category', ''),
                    'requirement': payload.get('requirement', ''),
                    'response': payload.get('response', ''),
                    'reference': reference_text  # Always add reference, even if empty
                }
                
                results.append(result_item)
        
        # Sort by similarity score
        results.sort(key=lambda x: x['score'], reverse=True)
        
        return results[:k]
    except Exception as e:
        sys.stderr.write(f"Error finding similar requirements: {str(e)}\n")
        return []

def generate_response_with_openai(query_text: str, similar_responses: List[Dict]):
    """Generate a response using OpenAI API."""
    # Enhanced API key debugging
    sys.stderr.write(f"\nDEBUG OPENAI KEY: OPENAI_API_KEY present: {bool(OPENAI_API_KEY)}\n")
    sys.stderr.write(f"OPENAI_API_KEY starts with: {OPENAI_API_KEY[:4] if OPENAI_API_KEY else 'None'}\n")
    sys.stderr.write(f"Using hardcoded key in production deployment mode\n")
    
    if not OPENAI_API_KEY:
        sys.stderr.write("OpenAI API key not found in environment variables or hardcoded value\n")
        return {"error": "OpenAI API key not found in environment variables or hardcoded value"}
        
    try:
        # Try importing the OpenAI library with detailed error handling
        try:
            import openai
            sys.stderr.write("Successfully imported OpenAI library\n")
        except ImportError as e:
            sys.stderr.write(f"Failed to import OpenAI library: {str(e)}\n")
            return {"error": f"Failed to import OpenAI library: {str(e)}"}
        
        # Try creating the client
        try:
            client = openai.OpenAI(api_key=OPENAI_API_KEY)
            sys.stderr.write("Successfully created OpenAI client\n")
        except Exception as e:
            sys.stderr.write(f"Failed to create OpenAI client: {str(e)}\n")
            return {"error": f"Failed to create OpenAI client: {str(e)}"}
        
        # Construct the prompt
        prompt = f"""You are an expert RFP response assistant. Your task is to generate a comprehensive response to the following requirement:

Requirement: {query_text}

Here are some examples of similar requirements and their responses that you can use as reference:

"""
        
        # Add similar responses to the prompt
        for i, resp in enumerate(similar_responses, 1):
            reference_info = f"- Reference: {resp['reference']}" if resp.get('reference') else ""
            prompt += f"""
Example {i}:
- Requirement: {resp['requirement']}
- Response: {resp['response']}
{reference_info}
            
"""
        
        prompt += """
Using the examples provided, generate a comprehensive response to the original requirement. 
The response should be professional, well-structured, and address all aspects of the requirement.
Do not include phrases like "Based on the examples" or "According to the references" in your response.

IMPORTANT FORMATTING GUIDELINES:
1. Use Markdown formatting for structure and emphasis
2. Use "### **Key Capabilities:**" as a header when listing main features or capabilities
3. Use bold formatting (**text**) for important product features, attributes, or modules
4. Use numbered or bulleted lists for sequential steps or feature lists
5. Organize the response with clear section headers and proper paragraph breaks
"""
        
        # Print the prompt for debugging
        sys.stderr.write(f"===== OPENAI PROMPT =====\n")
        sys.stderr.write(f"{prompt[:500]}...\n") # Show the first 500 chars
        sys.stderr.write(f"===== END OPENAI PROMPT =====\n")

        # Call the OpenAI API with detailed error handling
        try:
            sys.stderr.write("Calling OpenAI API with gpt-4o model...\n")
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert RFP response assistant. Format your response using Markdown with proper headers and emphasis."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1000,
                timeout=30  # 30 second timeout
            )
            
            sys.stderr.write("Successfully received response from OpenAI API\n")
            
            # Extract the response content safely
            try:
                content = response.choices[0].message.content
                sys.stderr.write(f"Response content extracted (first 100 chars): {content[:100]}...\n")
                
                return {
                    "generated_response": content,
                    "similar_responses": similar_responses,
                    "openai_response": content  # Store in the model-specific field too
                }
            except AttributeError as e:
                sys.stderr.write(f"Error extracting response content: {str(e)}\n")
                return {"error": f"Error extracting response content: {str(e)}"}
                
        except Exception as e:
            sys.stderr.write(f"Error calling OpenAI API: {str(e)}\n")
            return {"error": f"Error calling OpenAI API: {str(e)}"}
    except Exception as e:
        sys.stderr.write(f"Unexpected error generating response with OpenAI: {str(e)}\n")
        return {"error": f"Unexpected error: {str(e)}"}

def generate_response_with_anthropic(query_text: str, similar_responses: List[Dict]):
    """Generate a response using Anthropic API."""
    # Enhanced API key debugging
    sys.stderr.write(f"\nDEBUG ANTHROPIC KEY: ANTHROPIC_API_KEY present: {bool(ANTHROPIC_API_KEY)}\n")
    sys.stderr.write(f"ANTHROPIC_API_KEY starts with: {ANTHROPIC_API_KEY[:4] if ANTHROPIC_API_KEY else 'None'}\n")
    sys.stderr.write(f"Using hardcoded key in production deployment mode\n")
    
    if not ANTHROPIC_API_KEY:
        sys.stderr.write("Anthropic API key not found in environment variables or hardcoded value\n")
        return {"error": "Anthropic API key not found in environment variables or hardcoded value"}
        
    try:
        from anthropic import Anthropic
        client = Anthropic(api_key=ANTHROPIC_API_KEY)
        
        # Construct the prompt
        prompt = f"""You are an expert RFP response assistant. Your task is to generate a comprehensive response to the following requirement:

Requirement: {query_text}

Here are some examples of similar requirements and their responses that you can use as reference:

"""
        
        # Add similar responses to the prompt
        for i, resp in enumerate(similar_responses, 1):
            reference_info = f"- Reference: {resp['reference']}" if resp.get('reference') else ""
            prompt += f"""
Example {i}:
- Requirement: {resp['requirement']}
- Response: {resp['response']}
{reference_info}
            
"""
        
        prompt += """
Using the examples provided, generate a comprehensive response to the original requirement. 
The response should be professional, well-structured, and address all aspects of the requirement.
Do not include phrases like "Based on the examples" or "According to the references" in your response.

IMPORTANT FORMATTING GUIDELINES:
1. Use Markdown formatting for structure and emphasis
2. Use "### **Key Capabilities:**" as a header when listing main features or capabilities
3. Use bold formatting (**text**) for important product features, attributes, or modules
4. Use numbered or bulleted lists for sequential steps or feature lists
5. Organize the response with clear section headers and proper paragraph breaks
"""
        
        # Call the Anthropic API
        response = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=1000,
            system="You are an expert RFP response assistant. Format your response using Markdown with proper headers and emphasis.",
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        content = response.content[0].text
        return {
            "generated_response": content,
            "similar_responses": similar_responses,
            "anthropic_response": content  # Store in model-specific field
        }
    except Exception as e:
        sys.stderr.write(f"Error generating response with Anthropic: {str(e)}\n")
        return {"error": str(e)}

def generate_response_with_deepseek(query_text: str, similar_responses: List[Dict]):
    """Generate a response using Deepseek API."""
    # Enhanced API key debugging
    sys.stderr.write(f"\nDEBUG DEEPSEEK KEY: DEEPSEEK_API_KEY present: {bool(DEEPSEEK_API_KEY)}\n")
    sys.stderr.write(f"DEEPSEEK_API_KEY starts with: {DEEPSEEK_API_KEY[:4] if DEEPSEEK_API_KEY else 'None'}\n")
    sys.stderr.write(f"Using hardcoded key in production deployment mode\n")
    
    if not DEEPSEEK_API_KEY:
        sys.stderr.write("Deepseek API key not found in environment variables or hardcoded value\n")
        return {"error": "Deepseek API key not found in environment variables or hardcoded value"}
        
    try:
        import requests
        import json
        
        # Construct the prompt
        prompt = f"""You are an expert RFP response assistant. Your task is to generate a comprehensive response to the following requirement:

Requirement: {query_text}

Here are some examples of similar requirements and their responses that you can use as reference:

"""
        
        # Add similar responses to the prompt
        for i, resp in enumerate(similar_responses, 1):
            reference_info = f"- Reference: {resp['reference']}" if resp.get('reference') else ""
            prompt += f"""
Example {i}:
- Requirement: {resp['requirement']}
- Response: {resp['response']}
{reference_info}
            
"""
        
        prompt += """
Using the examples provided, generate a comprehensive response to the original requirement. 
The response should be professional, well-structured, and address all aspects of the requirement.
Do not include phrases like "Based on the examples" or "According to the references" in your response.

IMPORTANT FORMATTING GUIDELINES:
1. Use Markdown formatting for structure and emphasis
2. Use "### **Key Capabilities:**" as a header when listing main features or capabilities
3. Use bold formatting (**text**) for important product features, attributes, or modules
4. Use numbered or bulleted lists for sequential steps or feature lists
5. Organize the response with clear section headers and proper paragraph breaks
"""
        
        # API endpoint
        url = "https://api.deepseek.com/v1/chat/completions"
        
        # Headers and data
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "You are an expert RFP response assistant. Format your response using Markdown with proper headers and emphasis."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7,
            "max_tokens": 1000
        }
        
        # Make the request
        response = requests.post(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Raise exception if request failed
        
        # Parse the response
        result = response.json()
        generated_text = result['choices'][0]['message']['content']
        
        return {
            "generated_response": generated_text,
            "similar_responses": similar_responses,
            "deepseek_response": generated_text  # Store in model-specific field
        }
    except Exception as e:
        sys.stderr.write(f"Error generating response with Deepseek: {str(e)}\n")
        return {"error": str(e)}

def create_synthesized_response_prompt(requirement: str, responses: List[str]):
    """
    Generate a prompt to synthesize multiple RFP responses into a cohesive, impactful response.

    Args:
        requirement: The specific RFP requirement to address.
        responses: List of individual responses to evaluate and synthesize.

    Returns:
        str: The formatted prompt for synthesis
    """
    prompt = f"""You are a senior RFP specialist at a leading technology company with extensive experience in winning complex RFPs.

OBJECTIVE:
Synthesize multiple response versions into one optimal response that directly addresses the requirement: {requirement}

EVALUATION CRITERIA:
1. **Relevance & Impact**:
   - Direct alignment with the requirement.
   - Clear and compelling value proposition.
   - Focus on business benefits and measurable outcomes.
   - Practicality of implementation.

2. **Content Quality**:
   - Factual accuracy (use ONLY information from provided responses).
   - Specific examples, capabilities, and competitive differentiators.
   - Avoid abstract claims; focus on concrete, verifiable details.

3. **Writing Standards**:
   - Professional, concise, and accessible language.
   - Use active voice and avoid unnecessary technical jargon.
   - Ensure clarity and logical flow.

SYNTHESIS RULES:
1. **Structure**:
   - Begin with the strongest capability or feature.
   - Support with specific examples, features, or metrics.
   - Conclude with a clear statement of business impact or value proposition.

2. **Content Integration**:
   - Extract the strongest elements from each response.
   - Resolve contradictions by selecting the most supported claims.
   - Combine unique strengths while eliminating redundancy.

Here are the different model responses to synthesize:

"""
    
    for i, response in enumerate(responses, 1):
        prompt += f"RESPONSE {i}:\n{response}\n\n"
    
    prompt += """
YOUR TASK:
1. Analyze each response version for strengths and weaknesses.
2. Extract the most compelling points, examples, and differentiators.
3. Create a unified response that is better than any individual response.
4. Format appropriately for an RFP (professional tone, clear structure).
5. Do not introduce new information beyond what is contained in the provided responses.

FORMATTING GUIDELINES:
1. Use Markdown formatting for structure and emphasis
2. Include a "### **Key Capabilities:**" section when listing main capabilities
3. Use bold formatting (**text**) for important product features, attributes, or modules
4. Use numbered or bulleted lists for sequential steps or feature lists
5. Ensure proper paragraph breaks and section headers

SYNTHESIZED RESPONSE:
"""
    
    return prompt

def generate_moa_response(requirement_text: str, similar_responses: List[Dict]):
    """Generate a response using the Mixture of Agents (MOA) approach."""
    # Check required API keys
    required_keys = ["OpenAI API key", "Anthropic API key", "Deepseek API key"]
    missing_keys = []
    if not OPENAI_API_KEY:
        missing_keys.append("OpenAI API key")
    if not ANTHROPIC_API_KEY:
        missing_keys.append("Anthropic API key")
    if not DEEPSEEK_API_KEY:
        missing_keys.append("Deepseek API key")
    
    # We need at least 2 API keys for MOA
    if len(missing_keys) >= 2:
        return {"error": f"Missing required API keys for MOA: {', '.join(missing_keys)}"}
    
    try:
        # Phase 1: Generate and store individual model responses
        # These will be saved to the database without a synthesized response initially
        
        # Storage for individual model responses
        openai_response = None
        anthropic_response = None
        deepseek_response = None
        
        # Track which models succeeded
        successful_models = []
        
        # Get OpenAI response
        if OPENAI_API_KEY:
            try:
                openai_result = generate_response_with_openai(requirement_text, similar_responses)
                if "generated_response" in openai_result and openai_result["generated_response"]:
                    openai_response = openai_result["generated_response"]
                    successful_models.append("OpenAI")
                    sys.stderr.write(f"Successfully got OpenAI response\n")
            except Exception as e:
                sys.stderr.write(f"Error getting OpenAI response: {str(e)}\n")
        
        # Get Anthropic response
        if ANTHROPIC_API_KEY:
            try:
                anthropic_result = generate_response_with_anthropic(requirement_text, similar_responses)
                if "generated_response" in anthropic_result and anthropic_result["generated_response"]:
                    anthropic_response = anthropic_result["generated_response"]
                    successful_models.append("Anthropic")
                    sys.stderr.write(f"Successfully got Anthropic response\n")
            except Exception as e:
                sys.stderr.write(f"Error getting Anthropic response: {str(e)}\n")
        
        # Get Deepseek response
        if DEEPSEEK_API_KEY:
            try:
                deepseek_result = generate_response_with_deepseek(requirement_text, similar_responses)
                if "generated_response" in deepseek_result and deepseek_result["generated_response"]:
                    deepseek_response = deepseek_result["generated_response"]
                    successful_models.append("Deepseek")
                    sys.stderr.write(f"Successfully got Deepseek response\n")
            except Exception as e:
                sys.stderr.write(f"Error getting Deepseek response: {str(e)}\n")
        
        # Phase 1 result: Return individual model responses without synthesis
        # This allows storing the individual responses first
        return {
            "phase": 1,
            "openai_response": openai_response,
            "anthropic_response": anthropic_response,
            "deepseek_response": deepseek_response,
            "similar_responses": similar_responses,
            "successful_models": successful_models,
            "synthesis_ready": len(successful_models) >= 2
        }
        
    except Exception as e:
        sys.stderr.write(f"Error in MOA response generation (Phase 1): {str(e)}\n")
        return {"error": str(e)}

def generate_moa_synthesis(requirement_text: str, model_responses: Dict[str, str], similar_responses: List[Dict] = None):
    """
    Phase 2 of MOA: Generate synthesized response from individual model responses.
    
    Args:
        requirement_text: The requirement to address
        model_responses: Dictionary with keys 'openai_response', 'anthropic_response', 'deepseek_response'
        similar_responses: Optional list of similar responses
    
    Returns:
        Dictionary with synthesized response and metadata
    """
    try:
        # Extract valid responses from the dictionary
        valid_responses = []
        
        if model_responses.get('openai_response'):
            valid_responses.append(model_responses['openai_response'])
        
        if model_responses.get('anthropic_response'):
            valid_responses.append(model_responses['anthropic_response'])
        
        if model_responses.get('deepseek_response'):
            valid_responses.append(model_responses['deepseek_response'])
        
        # If we don't have at least two responses, we can't synthesize
        if len(valid_responses) < 2:
            if len(valid_responses) == 1:
                # If we have only one response, return it as the synthesized response
                return {
                    "generated_response": valid_responses[0],
                    "moa_response": valid_responses[0],
                    "moa_info": "Only one model response available; no synthesis performed",
                    "phase": 2
                }
            else:
                return {"error": "Failed to get responses from any models", "phase": 2}
                
        # Create synthesis prompt
        synthesis_prompt = create_synthesized_response_prompt(requirement_text, valid_responses)
        
        # Synthesize using OpenAI
        import openai
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        
        synthesis_response = client.chat.completions.create(
            model="gpt-4o",  # Using the newest model for synthesis
            messages=[
                {"role": "system", "content": "You are an expert RFP synthesis specialist. Format your response using Markdown with proper headers and emphasis. Use '### **Key Capabilities:**' as a header when listing main features, and bold formatting (**text**) for important product features."},
                {"role": "user", "content": synthesis_prompt}
            ],
            temperature=0.7,
            max_tokens=1200,
            timeout=30  # 30 second timeout
        )
        
        synthesized_response = synthesis_response.choices[0].message.content
        
        return {
            "generated_response": synthesized_response,
            "moa_response": synthesized_response,
            "moa_info": f"Synthesized from {len(valid_responses)} model responses",
            "phase": 2
        }
        
    except Exception as e:
        sys.stderr.write(f"Error in MOA synthesis (Phase 2): {str(e)}\n")
        return {"error": str(e), "phase": 2}

def test_api_connection(model_provider="openai"):
    """Test the API connection for the specified provider without loading embeddings."""
    try:
        sys.stderr.write(f"Testing {model_provider} API connection...\n")
        
        if model_provider.lower() == "openai":
            if not OPENAI_API_KEY:
                return {"error": "OpenAI API key not found in environment variables"}
                
            try:
                import openai
                client = openai.OpenAI(api_key=OPENAI_API_KEY)
                
                sys.stderr.write("Sending test request to OpenAI API...\n")
                response = client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": "Please respond with a short test message."}
                    ],
                    temperature=0.7,
                    max_tokens=50,
                    timeout=15  # 15 second timeout
                )
                
                return {
                    "success": True,
                    "message": "OpenAI API connection successful",
                    "response": response.choices[0].message.content
                }
            except Exception as e:
                return {"error": f"OpenAI API connection failed: {str(e)}"}
                
        elif model_provider.lower() == "anthropic":
            if not ANTHROPIC_API_KEY:
                return {"error": "Anthropic API key not found in environment variables"}
                
            try:
                from anthropic import Anthropic
                client = Anthropic(api_key=ANTHROPIC_API_KEY)
                
                sys.stderr.write("Sending test request to Anthropic API...\n")
                response = client.messages.create(
                    model="claude-3-7-sonnet-20250219",
                    max_tokens=100,
                    messages=[
                        {"role": "user", "content": "Please respond with a short test message."}
                    ]
                )
                
                return {
                    "success": True,
                    "message": "Anthropic API connection successful",
                    "response": response.content[0].text
                }
            except Exception as e:
                return {"error": f"Anthropic API connection failed: {str(e)}"}
        else:
            return {"error": f"Unsupported model provider for testing: {model_provider}"}
    
    except Exception as e:
        return {"error": f"Unexpected error testing API connection: {str(e)}"}
        
def process_requirement(requirement_text: str, model_provider="openai"):
    """Process a requirement and generate a response."""
    # If test mode is activated, only test the API connection
    if requirement_text.lower() == "test_connection_only":
        return test_api_connection(model_provider)
        
    # Load embeddings
    embeddings_data = load_embeddings()
    if embeddings_data is None:
        return {"error": "Failed to load embeddings data"}
    
    # Find similar requirements
    similar_requirements = find_similar_requirements(requirement_text, embeddings_data)
    
    if not similar_requirements:
        return {"error": "No similar requirements found"}
    
    # Generate response based on the provider
    if model_provider.lower() == "openai":
        return generate_response_with_openai(requirement_text, similar_requirements)
    elif model_provider.lower() == "anthropic":
        return generate_response_with_anthropic(requirement_text, similar_requirements)
    elif model_provider.lower() == "deepseek":
        return generate_response_with_deepseek(requirement_text, similar_requirements)
    elif model_provider.lower() == "moa":
        return generate_moa_response(requirement_text, similar_requirements)
    else:
        return {"error": f"Unsupported model provider: {model_provider}"}

# Command line interface for testing
if __name__ == "__main__":
    if len(sys.argv) > 1:
        requirement = sys.argv[1]
        provider = sys.argv[2] if len(sys.argv) > 2 else "openai"
        result = process_requirement(requirement, provider)
        # Always use print for JSON output to stdout
        print(json.dumps(result, indent=2))
    else:
        sys.stderr.write("Usage: python rfp_response_generator.py 'requirement text' [openai|anthropic|deepseek|moa]\n")