#!/usr/bin/env python3
"""
Test script for all models in the RFP response generator.
Tests OpenAI, Anthropic, and DeepSeek APIs with a simple hello-world query.
"""

import os
import sys
import json
import time
from rfp_response_generator_pg import prompt_gpt, test_api_connection

def test_all_models():
    """Test all three models one by one and print the results."""
    models = ["openai", "anthropic", "deepseek"]
    results = {}
    
    print("\n" + "="*50)
    print("TESTING ALL MODELS")
    print("="*50)
    
    # Simple test prompt for all models
    test_prompt = [
        {"role": "system", "content": "You are a helpful assistant specialized in RFP responses."},
        {"role": "user", "content": "Please provide a brief description of multi-factor authentication for a banking application."}
    ]
    
    # Test each model
    for model in models:
        print(f"\nTesting {model.upper()} API...")
        print("-"*30)
        
        try:
            # First test the API connection
            connection_test = test_api_connection(model)
            print(f"Connection test: {connection_test['status']}")
            if connection_test['status'] == 'error':
                print(f"Error details: {connection_test['message']}")
                results[model] = {"status": "error", "message": connection_test['message']}
                continue
            
            # Now test with our structured prompt
            print(f"Sending prompt to {model}...\n")
            start_time = time.time()
            response = prompt_gpt(test_prompt, llm=model)
            elapsed_time = time.time() - start_time
            
            # Print the result
            print(f"Response from {model.upper()} (in {elapsed_time:.2f} seconds):")
            print("-"*50)
            print(response[:300] + "..." if len(response) > 300 else response)
            print("-"*50)
            
            results[model] = {"status": "success", "response": response, "time": elapsed_time}
            
        except Exception as e:
            print(f"Error testing {model}: {str(e)}")
            results[model] = {"status": "error", "message": str(e)}
    
    # Print summary of results
    print("\n" + "="*50)
    print("TEST RESULTS SUMMARY")
    print("="*50)
    for model, result in results.items():
        status = "✅ SUCCESS" if result.get("status") == "success" else "❌ FAILED"
        details = f" - {result.get('time', 0):.2f}s" if result.get("status") == "success" else f" - {result.get('message', 'Unknown error')}"
        print(f"{model.upper()}: {status}{details}")
    
    return results

if __name__ == "__main__":
    test_all_models()