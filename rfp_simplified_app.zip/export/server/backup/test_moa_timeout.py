#!/usr/bin/env python3
"""
Test script for MOA implementation with 3-minute timeout for all models
"""

import sys
import time
import json
from moa_handler import moa_generate_response

def test_moa_with_timeouts():
    """Test the MOA implementation with the 3-minute timeout for each model"""
    print("\n" + "="*80)
    print("TESTING MOA WITH 3-MINUTE TIMEOUT FOR ALL MODELS")
    print("="*80)
    
    # Sample requirement (brief)
    sample_requirement = "Describe document management features for wealth management platforms"
    
    print(f"\nRequirement: {sample_requirement}")
    print("\nGenerating MOA response...")
    
    try:
        start_time = time.time()
        
        # Call the MOA response generator
        result = moa_generate_response(sample_requirement)
        
        elapsed_time = time.time() - start_time
        
        print(f"\nMOA process completed in {elapsed_time:.2f} seconds")
        print(f"Models attempted: {result['metrics']['models_attempted']}")
        print(f"Models succeeded: {result['metrics']['models_succeeded']}")
        
        print("\nFINAL RESPONSE:")
        print("-"*80)
        print(result['final_response'])
        print("-"*80)
        
        # Save the result to a file for inspection
        with open("moa_timeout_test_result.json", "w") as f:
            # Convert any non-serializable objects to strings
            serializable_result = {
                "requirement": sample_requirement,
                "final_response": result["final_response"],
                "metrics": result["metrics"],
                "model_responses": {}
            }
            
            # Handle model responses
            for model, response in result.get("model_responses", {}).items():
                if response:
                    serializable_result["model_responses"][model] = response
            
            json.dump(serializable_result, f, indent=2)
            
        print("\nResults saved to moa_timeout_test_result.json")
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")

if __name__ == "__main__":
    test_moa_with_timeouts()