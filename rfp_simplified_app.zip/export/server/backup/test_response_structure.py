#!/usr/bin/env python3
"""
Test the response structure from the RFP generator.
This script tests the response structure from rfp_response_generator_pg.py.
"""
import os
import sys
import json

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from rfp_response_generator_pg import process_requirement
    print("Successfully imported process_requirement function")
except ImportError as e:
    print(f"Failed to import process_requirement function: {e}")
    sys.exit(1)

def test_response_structure():
    """Test the response structure from process_requirement."""
    print("\n=== RESPONSE STRUCTURE TEST ===")
    
    # Test requirement
    test_query = "Describe the reporting capabilities for investment performance"
    print(f"Test query: '{test_query}'")
    
    # Test each model provider
    providers = ["openai", "anthropic", "deepseek"]
    
    for provider in providers:
        print(f"\nTesting provider: {provider}")
        
        # Process the requirement
        response = process_requirement(test_query, model_provider=provider)
        
        # Check if response is a dictionary
        if not isinstance(response, dict):
            print(f"ERROR: Response is not a dictionary: {type(response)}")
            continue
        
        # Check for error
        if "error" in response:
            print(f"ERROR: {response['error']}")
            continue
        
        # Check for generated_response
        if "generated_response" not in response:
            print("WARNING: No 'generated_response' in response")
        else:
            response_text = response["generated_response"]
            print(f"Response text: {response_text[:100]}...")
        
        # Check for similar_responses
        if "similar_responses" not in response:
            print("WARNING: No 'similar_responses' in response")
        else:
            similar = response["similar_responses"]
            if not similar:
                print("WARNING: 'similar_responses' is empty")
            else:
                print(f"Found {len(similar)} similar responses")
                for i, item in enumerate(similar[:3]):  # Show first 3
                    print(f"  Similar response {i+1}:")
                    if isinstance(item, dict):
                        for key in ["category", "requirement", "response", "score"]:
                            if key in item:
                                value = item[key]
                                if isinstance(value, str):
                                    value = value[:50] + "..." if len(value) > 50 else value
                                print(f"    {key}: {value}")
                    else:
                        print(f"    Not a dictionary: {type(item)}")
        
        # Check for model-specific response
        model_key = f"{provider.lower()}_response"
        if model_key not in response:
            print(f"WARNING: No '{model_key}' in response")
        else:
            model_response = response[model_key]
            print(f"{provider} response: {model_response[:100]}...")
        
        # Check for all keys
        print(f"All keys in response: {', '.join(response.keys())}")
        
    print("\nResponse structure test completed")
    return True

if __name__ == "__main__":
    success = test_response_structure()
    sys.exit(0 if success else 1)