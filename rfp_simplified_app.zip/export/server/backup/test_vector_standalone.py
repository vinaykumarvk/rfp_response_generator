#!/usr/bin/env python3
"""
Standalone test script for PostgreSQL vector search
This provides more detailed debugging information
"""
import os
import sys
import json
import psycopg2
from psycopg2.extras import RealDictCursor
import random

# Get database connection
def get_database_connection():
    """Get a connection to the PostgreSQL database."""
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        print("ERROR: DATABASE_URL environment variable not set")
        sys.exit(1)
    
    try:
        conn = psycopg2.connect(database_url)
        print("Successfully connected to PostgreSQL database")
        return conn
    except Exception as e:
        print(f"Error connecting to database: {str(e)}")
        sys.exit(1)

def test_basic_vector_query():
    """Test the most basic vector query possible"""
    conn = get_database_connection()
    cursor = conn.cursor()
    
    # First, check if there's any data
    cursor.execute("SELECT COUNT(*) FROM embeddings")
    count = cursor.fetchone()[0]
    print(f"Database has {count} embedding records")
    
    if count == 0:
        print("No data to query!")
        return
    
    # Get the first embedding as a reference
    cursor.execute("SELECT embedding FROM embeddings LIMIT 1")
    first_embedding = cursor.fetchone()[0]
    print(f"Got reference embedding with {len(first_embedding)} dimensions")
    
    # Now test a simple query with the first embedding
    print("\nTesting query with an existing embedding...")
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    cursor.execute("""
    SELECT 
        id, 
        category, 
        requirement,
        1 - (embedding <=> %s::vector) as similarity
    FROM 
        embeddings
    ORDER BY 
        embedding <=> %s::vector
    LIMIT 3
    """, (first_embedding, first_embedding))
    
    results = cursor.fetchall()
    print(f"Query returned {len(results)} results")
    
    for i, row in enumerate(results, 1):
        print(f"{i}. {row['category']} | {row['requirement'][:50]}... (score: {row['similarity']:.3f})")
    
    # Now try with a random vector
    print("\nTesting query with a random vector...")
    random_vector = [random.random() for _ in range(1536)]
    # Normalize
    magnitude = sum(x*x for x in random_vector) ** 0.5
    random_vector = [x/magnitude for x in random_vector]
    
    vector_str = f"[{','.join(str(x) for x in random_vector)}]"
    
    cursor.execute("""
    SELECT 
        id, 
        category, 
        requirement,
        1 - (embedding <=> %s::vector) as similarity
    FROM 
        embeddings
    ORDER BY 
        embedding <=> %s::vector
    LIMIT 3
    """, (vector_str, vector_str))
    
    results = cursor.fetchall()
    print(f"Random vector query returned {len(results)} results")
    
    for i, row in enumerate(results, 1):
        print(f"{i}. {row['category']} | {row['requirement'][:50]}... (score: {row['similarity']:.3f})")
    
    # Close connections
    cursor.close()
    conn.close()

if __name__ == "__main__":
    test_basic_vector_query()