#!/usr/bin/env python3
"""
Quick MOA test script for the RFP Response Generator
This provides a faster way to test MOA functionality
"""

import sys
import json
import time

def generate_mock_moa_response(requirement_text):
    """
    Generate a mock MOA response for testing
    
    Args:
        requirement_text: The requirement text to process
        
    Returns:
        Dict with mock MOA response data
    """
    # Start timing
    start_time = time.time()
    
    # Generate some mock model responses (faster than actual API calls)
    openai_response = f"OpenAI mock response for: {requirement_text}"
    anthropic_response = f"Anthropic mock response for: {requirement_text}"
    deepseek_response = f"DeepSeek mock response for: {requirement_text}"
    moa_response = f"MOA synthesized response combining insights from all models for: {requirement_text}"
    
    # Add a slight delay to simulate processing
    time.sleep(0.5)
    elapsed_time = time.time() - start_time
    
    # Return mock data structure matching the real MOA output
    return {
        "status": "success",
        "final_response": moa_response,
        "model_responses": {
            "openai_response": openai_response,
            "anthropic_response": anthropic_response,
            "deepseek_response": deepseek_response,
            "moa_response": moa_response
        },
        "metrics": {
            "total_time": elapsed_time,
            "models_succeeded": 3,
            "models_attempted": 3
        }
    }

if __name__ == "__main__":
    # Check command line arguments
    if len(sys.argv) != 2:
        print(json.dumps({
            "status": "error",
            "message": "Usage: python quick_moa_test.py <requirement_text>"
        }))
        sys.exit(1)
    
    # Get the requirement text
    requirement_text = sys.argv[1]
    
    # Generate the mock MOA response
    result = generate_mock_moa_response(requirement_text)
    
    # Output as JSON
    print(json.dumps(result))