#!/usr/bin/env python3
"""
Simple test script for DeepSeek API
"""

import os
import json
import time
import sys
import requests

# Get the DeepSeek API key from environment
DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY')

print(f"Testing DeepSeek API with key: {DEEPSEEK_API_KEY[:10]}...", file=sys.stderr)

# Try direct API call first
print("Trying direct API call with requests...", file=sys.stderr)
try:
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
    }
    
    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant. Respond only with 'DeepSeek connection successful'."},
            {"role": "user", "content": "Confirm the connection is working"}
        ],
        "max_tokens": 10
    }
    
    response = requests.post(
        "https://api.deepseek.com/v1/chat/completions",
        headers=headers,
        json=data
    )
    
    if response.status_code == 200:
        print("Success with direct API call!", file=sys.stderr)
        result = {
            "success": True,
            "message": "DeepSeek API connection successful (direct call)",
            "response": response.json()['choices'][0]['message']['content'],
            "response_time_ms": 0
        }
        print(json.dumps(result, indent=2))
        sys.exit(0)
    else:
        print(f"Failed with direct API call: {response.status_code} - {response.text}", file=sys.stderr)
except Exception as e:
    print(f"Error with direct API call: {str(e)}", file=sys.stderr)

# Try with OpenAI client
try:
    from openai import OpenAI
    
    # Log start time
    start_time = time.time()
    
    # Convert API key to lowercase if needed
    key_to_use = DEEPSEEK_API_KEY

    print(f"Using original key format", file=sys.stderr)
    
    # Try different base URL formats and models
    
    print(f"Trying with standard base URL...", file=sys.stderr)
    client = OpenAI(
        api_key=key_to_use,
        base_url="https://api.deepseek.com/v1"
    )
    
    # Make a simple API call with different model options
    models_to_try = ["deepseek-chat", "deepseek-coder", "deepseek-llm-67b-chat"]
    
    for model in models_to_try:
        print(f"Trying with model: {model}...", file=sys.stderr)
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant. Respond only with 'DeepSeek connection successful' and nothing else."},
                    {"role": "user", "content": "Confirm the connection is working"}
                ],
                max_tokens=10
            )
            print(f"Success with model: {model}", file=sys.stderr)
            break
        except Exception as e:
            print(f"Failed with model {model}: {str(e)}", file=sys.stderr)
            if model == models_to_try[-1]:  # Last model to try
                raise
    
    end_time = time.time()
    response_time_ms = int((end_time - start_time) * 1000)
    
    result = {
        "success": True,
        "message": "DeepSeek API connection successful",
        "response": response.choices[0].message.content,
        "response_time_ms": response_time_ms
    }

except ImportError as e:
    result = {
        "success": False,
        "error": f"ImportError: {e}. Please install the openai package with 'pip install openai'."
    }
except Exception as e:
    result = {
        "success": False,
        "error": f"Error connecting to DeepSeek API: {str(e)}"
    }

# Print the result as JSON
print(json.dumps(result, indent=2))