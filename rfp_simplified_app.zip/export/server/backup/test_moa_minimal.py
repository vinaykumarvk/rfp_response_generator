#!/usr/bin/env python3
"""
Minimal MOA Test 
This script tests the MOA implementation with a very simple requirement
"""

import json
from moa_final import generate_moa_response

def test_moa_minimal():
    """Test the MOA implementation with a minimal requirement"""
    
    print("\n=== TESTING MOA WITH MINIMAL REQUIREMENT ===")
    
    # Use a very simple requirement for faster testing
    requirement = "List 3 document management features. Keep it brief."
    
    try:
        # Generate MOA response
        print("\nGenerating MOA response...")
        result = generate_moa_response(requirement)
        
        if result["status"] == "success":
            print("✅ MOA generation succeeded")
            
            # Print metrics
            metrics = result.get("metrics", {})
            print(f"\nMetrics:")
            print(f"Total time: {metrics.get('total_time', 0):.2f}s")
            print(f"Models succeeded: {metrics.get('models_succeeded', 0)} of {metrics.get('models_attempted', 0)}")
            
            # Print model response sizes
            model_responses = result.get("model_responses", {})
            print("\nResponse sizes:")
            print(f"OpenAI: {len(model_responses.get('openai_response', ''))} chars")
            print(f"Anthropic: {len(model_responses.get('anthropic_response', ''))} chars")
            print(f"DeepSeek: {len(model_responses.get('deepseek_response', ''))} chars")
            print(f"MOA: {len(model_responses.get('moa_response', ''))} chars")
            
            # Print a snippet of the final response
            final_response = result.get("final_response", "")
            if final_response:
                print(f"\nFinal response snippet:")
                print(f"{final_response[:200]}...")
            else:
                print("\nNo final response generated")
        else:
            print(f"❌ MOA generation failed: {result.get('message', 'Unknown error')}")
    
    except Exception as e:
        print(f"❌ Exception during testing: {str(e)}")
    
    print("\n=== MOA MINIMAL TEST COMPLETE ===")

if __name__ == "__main__":
    test_moa_minimal()