#!/usr/bin/env python3
"""
API testing module for use with the Express server.
This module provides simplified API connectivity testing functions.
"""

import os
import sys
import json
import time

def test_openai_connection():
    """Test connection to OpenAI API"""
    try:
        from openai import OpenAI
        
        # Use hardcoded API key for production deployment
        api_key = "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"
        
        # Start timing
        start_time = time.time()
        
        # Initialize client
        client = OpenAI(api_key=api_key)
        
        # Make a simple API call
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Respond only with 'OpenAI connection successful' and nothing else."},
                {"role": "user", "content": "Confirm the connection is working"}
            ],
            max_tokens=10
        )
        
        # End timing
        end_time = time.time()
        
        return {
            "success": True,
            "message": "OpenAI API connection successful",
            "response": response.choices[0].message.content,
            "response_time_ms": int((end_time - start_time) * 1000)
        }
    except ImportError as e:
        return {
            "success": False,
            "error": f"ImportError: {str(e)}. Please install the openai package with 'pip install openai'."
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Error connecting to OpenAI API: {str(e)}"
        }

def test_anthropic_connection():
    """Test connection to Anthropic API"""
    try:
        from anthropic import Anthropic
        
        # Use hardcoded API key for production deployment
        api_key = "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"
        
        # Start timing
        start_time = time.time()
        
        # Initialize client
        client = Anthropic(api_key=api_key)
        
        # Make a simple API call
        response = client.messages.create(
            model="claude-3-7-sonnet-20250219",
            max_tokens=10,
            messages=[
                {"role": "user", "content": "Respond only with 'Anthropic connection successful' and nothing else."}
            ]
        )
        
        # End timing
        end_time = time.time()
        
        return {
            "success": True,
            "message": "Anthropic API connection successful",
            "response": response.content[0].text,
            "response_time_ms": int((end_time - start_time) * 1000)
        }
    except ImportError as e:
        return {
            "success": False,
            "error": f"ImportError: {str(e)}. Please install the anthropic package with 'pip install anthropic'."
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Error connecting to Anthropic API: {str(e)}"
        }

if __name__ == "__main__":
    # If run directly, process command line arguments
    provider = "openai"  # Default
    
    if len(sys.argv) > 1:
        provider = sys.argv[1].lower()
    
    if provider == "openai":
        result = test_openai_connection()
    elif provider == "anthropic":
        result = test_anthropic_connection()
    else:
        result = {
            "success": False,
            "error": f"Unknown provider: {provider}. Use 'openai' or 'anthropic'."
        }
    
    # Print ONLY the result in JSON format with no other output
    # This is critical for proper parsing on the server side
    sys.stdout.write(json.dumps(result))
    sys.stdout.flush()